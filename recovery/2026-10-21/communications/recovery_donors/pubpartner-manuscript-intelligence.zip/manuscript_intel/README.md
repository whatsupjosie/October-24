# Manuscript Intelligence — PubPartner

**Built:** September 11, 2026
**Status:** Production. 105 tests passing. No placeholders.
**Runs on:** Python 3.10+, stdlib only. FastAPI optional (HTTP layer only).

The intelligence layer v20 was missing. 2i owns the manuscript. This owns
what was learned from it.

---

## Install

```
modules/manuscript/          -> your PubPartner modules/ directory
tests/test_manuscript.py     -> your tests/
client/2i_intelligence_patch.js -> paste into 2i, see file header
```

Verify before wiring anything:

```bash
python3 tests/test_manuscript.py     # expect: PASSED: 105  FAILED: 0
python3 demo_end_to_end.py           # full loop, no model, no network
```

## Wire into PubPartner

```python
from pathlib import Path
from modules.manuscript import (
    ManuscriptStore, ManuscriptPipeline, CallableProvider,
    build_manuscript_router,
)

store = ManuscriptStore(Path("data/pubpartner/manuscript_intelligence.db"))

async def provider(system: str, user: str, max_tokens: int = 400) -> str:
    return await inference_manager.generate(
        system=system, prompt=user, max_tokens=max_tokens, provider="local")

pipeline = ManuscriptPipeline(
    store,
    provider=CallableProvider(provider),
    use_model_indexer=False,   # rules-first; turn on when you want depth
)
app.include_router(build_manuscript_router(pipeline))
```

That is the whole integration. No changes to CricketKeeper, the Vessel,
Alex Core, the governance engine, or the 99 existing routes.

## Endpoints

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/pubpartner/manuscript/commit` | Text in, intelligence updated |
| POST | `/api/pubpartner/manuscript/generate` | Prose out, informed by intelligence |
| POST | `/api/pubpartner/manuscript/voice-signal` | Accept/reject/rewrite learning |
| GET | `/api/pubpartner/manuscript/{pid}/intelligence` | Everything known |
| POST | `/api/pubpartner/manuscript/{pid}/correct` | Writer overrides inference |
| POST | `/api/pubpartner/manuscript/{pid}/merge` | Declare two records one person |
| POST | `/api/pubpartner/manuscript/{pid}/flags/{fid}/resolve` | Dismiss a note |
| GET | `/api/pubpartner/manuscript/{pid}/health` | Stats and audit trail |

---

## The four rules this enforces

**1. The hash gate.** `djb2_hash` is byte-verified against 2i's JavaScript
across eight cases including emoji and CJK. Unchanged chapters are never
re-read. In the demo, the second commit of an unchanged manuscript takes
**0 ms** and makes zero model calls. On a 2015 i7 this is the difference
between usable and unusable.

**2. Commit never fails on intelligence.** A model that explodes, returns
garbage, or is absent entirely still produces a successful commit with
rules-tier results. Tested explicitly. The writer's text is never held
hostage by the learning layer.

**3. Authority is real.** `user > corrected > pub_manager > inference >
system`. A correction survives `force_reindex`. Superseded records are kept,
never deleted. Tested explicitly.

**4. Local-first.** Default path is deterministic rules — no model, no
network, no GPU. The model is escalation for depth, off by default
(`use_model_indexer=False`).

---

## What it actually does

From six lines of prose, with no model involved:

```
character:
  Ana Reyes (aka Ana)   x4  conf 0.65  [inference]
  Marcus Vane (aka Marcus) — hotel clerk  [user]
location:
  Blackwood Hotel, Ravensbourne
timeline_event:
  the next morning
```

Then generation stops being "continue this text" and becomes:

```
Characters in this manuscript:
  Ana Reyes (also: Ana)
  Marcus Vane (also: Marcus) — hotel clerk

Locations: Ravensbourne, Blackwood Hotel

Voice notes for this manuscript:
- Short sentences — around 3 words on average.
- Very little dialogue; narration carries the scene.

Prose the writer kept: "She went out. The street was empty."
Prose the writer rejected — do not write like this: "It was a dark and stormy night…"
```

That difference is the entire point of the layer.

---

## Continuity: observations, not corrections

Four checks, all phrased as questions a writer can dismiss without arguing:

- **Name drift** — "Anna Reyes is very close to Ana Reyes. Same person, or two
  different characters?" Catches single-occurrence typos, which entity-level
  comparison would miss. Stable across re-indexes; resolves when you merge.
- **Character returns after an exit** — flags a reappearance after the text
  indicated someone died or left.
- **Attribute conflicts** — and when your correction is the thing being
  contradicted, it says *"Keeping yours."*
- **In-chapter numeric drift** — "the crew is given as 7 and also 9."

Nothing auto-edits. Ever.

---

## Voice training

Accept/reject/rewrite were already being clicked. Now they are labelled
training data. Pure arithmetic — no embeddings, no GPU, runs in milliseconds.

A **rewrite is weighted 3×** an accept: it is a matched pair showing exactly
what was wrong and what right looked like.

Below 8 weighted samples the profile returns **empty guidance**. Steering a
model on two clicks produces confident nonsense, which is worse than no
steering. Verified by test.

---

## Honest gaps

Things this does **not** do, so nobody discovers them at a demo:

1. **Cross-chapter numeric tracking.** Only in-chapter contradictions.
   Real fact tracking needs units and context — Phase 2.
2. **Pronoun resolution.** "He walked in" attaches to nobody. Rules tier
   cannot do coreference; the model tier partially covers it.
3. **Relationship graphs.** Captured as text from the model tier, not
   traversable structure.
4. **Semantic retrieval.** Keyword and metadata only. The schema has room
   for an embedding column; the architecture calls this Phase 2.
5. **Scene-level segmentation.** Chapters only.
6. **Rules-tier precision on unusual prose.** Heuristics tuned on
   conventional narrative. Second-person, heavy dialect, or experimental
   formatting will produce noisier extraction. Enable the model tier there.
7. **No auth on the endpoints.** They inherit whatever PubPartner's
   middleware provides. Do not expose publicly without it.

---

## Test coverage

```
hashing (JS parity, unicode, astral)      6
name normalization                         4
rules extraction                           6
commit + hash gate                         8
project isolation                          3
authority chain                            9
continuity (drift, dedupe, resolve, merge) 12
voice training                            13
generation prompt assembly                 10
model resilience (explode, garbage)         3
model enrichment                            3
defensive JSON parsing                      9
intelligence retrieval                      6
audit ledger                                3
edge cases (empty, unicode, bad input)      6
concurrency                                 2
                                        -----
                                          105
```

---

## Next, in order

1. Run the tests. Run the demo. See it work before wiring anything.
2. Mount the router in PubPartner. Hit `/health` with curl.
3. Apply the four call-site edits in `client/2i_intelligence_patch.js`.
4. Write three chapters in 2i. Watch characters appear in the sidebar.
5. Only then turn on `use_model_indexer=True` and compare depth.

*Feic Mo Chroí — See my heart. See my art.*
