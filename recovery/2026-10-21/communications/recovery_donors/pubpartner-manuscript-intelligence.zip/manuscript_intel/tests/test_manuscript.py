"""
Manuscript intelligence tests. Stdlib only — runs anywhere Python runs.

    python3 tests/test_manuscript.py
"""
from __future__ import annotations

import asyncio
import sys
import tempfile
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from modules.manuscript import (  # noqa: E402
    Authority,
    CallableProvider,
    EntityKind,
    ManuscriptPipeline,
    ManuscriptStore,
    djb2_hash,
    parse_json_object,
)
from modules.manuscript.indexer import extract_rules  # noqa: E402
from modules.manuscript.models import (  # noqa: E402
    Entity,
    Provenance,
    VoiceSignal,
    VoiceSignalType,
    normalize_name,
)
from modules.manuscript.voice import build_profile, profile_to_guidance  # noqa: E402

_PASS = 0
_FAIL = 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global _PASS, _FAIL
    if condition:
        _PASS += 1
        print(f"  ok   {label}")
    else:
        _FAIL += 1
        print(f"  FAIL {label}" + (f" — {detail}" if detail else ""))


def section(name: str) -> None:
    print(f"\n{name}")


def new_pipeline(provider=None, use_model=False):
    tmp = tempfile.mkdtemp()
    store = ManuscriptStore(Path(tmp) / "t.db")
    return ManuscriptPipeline(store, provider=provider, use_model_indexer=use_model)


CH1 = [
    'Ana Reyes pushed open the door of the Blackwood Hotel and shook the rain from her coat.',
    '"You are late," said Marcus. He did not look up from the ledger.',
    '"The bridge was out," Ana replied. "I walked."',
    'The lobby smelled of wet wool and old money. Marcus closed the ledger.',
    '"Then you will want the room at the back," he said. "It is the only one left."',
    'Ana counted the keys on the board behind him. There were seven keys.',
]

CH2 = [
    'The next morning Ana found the ledger open on the desk.',
    'Marcus was nowhere in the lobby. The rain had stopped.',
    '"He left before dawn," said the porter. "He took the road to Ravensbourne."',
    'Ana read the last entry twice. The handwriting was not Marcus handwriting.',
]


def test_hashing() -> None:
    section("hashing — must match 2i's JavaScript djb2")
    check("seed value 5381 in base36", djb2_hash("") == "45h", djb2_hash(""))
    check("'a' is stable", djb2_hash("a") == djb2_hash("a"))
    check("differs on change", djb2_hash("hello") != djb2_hash("hellp"))
    check("base36 charset",
          all(c in "0123456789abcdefghijklmnopqrstuvwxyz" for c in djb2_hash("The quick brown fox")))
    check("unicode does not crash", isinstance(djb2_hash("café — naïve 日本語"), str))
    check("astral plane handled", isinstance(djb2_hash("emoji \U0001F600 here"), str))


def test_normalize() -> None:
    section("name normalization")
    check("honorific stripped", normalize_name("Det. Humphrey Bogart") == "humphrey bogart")
    check("case folded", normalize_name("ANA REYES") == "ana reyes")
    check("punctuation stripped", normalize_name("O'Brien,") == "o brien")
    check("first/last kept distinct", normalize_name("Ana") != normalize_name("Ana Reyes"))


def test_rules_extraction() -> None:
    section("rules extraction — no model required")
    ents = extract_rules(CH1, 0)
    names = {e.name for e in ents if e.kind == EntityKind.CHARACTER}
    check("found Ana", any("Ana" in n for n in names), str(names))
    check("found Marcus", any("Marcus" in n for n in names), str(names))
    check("dialogue attribution boosts confidence",
          any(e.provenance.confidence >= 0.65
              for e in ents if e.kind == EntityKind.CHARACTER))
    check("no stopword characters",
          not any(n.lower() in {"the", "then", "you"} for n in names), str(names))
    locs = {e.name for e in ents if e.kind == EntityKind.LOCATION}
    check("location detected", len(locs) >= 1, str(locs))
    ents2 = extract_rules(CH2, 1)
    times = {e.name for e in ents2 if e.kind == EntityKind.TIMELINE_EVENT}
    check("timeline marker found", "the next morning" in times, str(times))
    check("empty chapter is safe", extract_rules([], 0) == [])


def test_commit_and_hash_gate() -> None:
    section("commit + hash gate")
    p = new_pipeline()

    r1 = asyncio.run(p.commit("proj", [
        {"index": 0, "title": "One", "lines": CH1},
        {"index": 1, "title": "Two", "lines": CH2},
    ]))
    check("both chapters indexed", r1.chapters_indexed == [0, 1], str(r1.chapters_indexed))
    check("entities created", r1.entities_created > 0, str(r1.entities_created))
    check("no errors", not r1.errors, str(r1.errors))

    r2 = asyncio.run(p.commit("proj", [
        {"index": 0, "title": "One", "lines": CH1},
        {"index": 1, "title": "Two", "lines": CH2},
    ]))
    check("unchanged chapters skipped", r2.chapters_skipped == [0, 1], str(r2.chapters_skipped))
    check("nothing re-indexed", r2.chapters_indexed == [], str(r2.chapters_indexed))

    changed = CH2 + ['Ana put the ledger in her bag and left.']
    r3 = asyncio.run(p.commit("proj", [
        {"index": 0, "title": "One", "lines": CH1},
        {"index": 1, "title": "Two", "lines": changed},
    ]))
    check("only changed chapter re-indexed", r3.chapters_indexed == [1], str(r3.chapters_indexed))
    check("unchanged still skipped", r3.chapters_skipped == [0], str(r3.chapters_skipped))

    r4 = asyncio.run(p.commit("proj", [{"index": 0, "lines": CH1}], force_reindex=True))
    check("force_reindex overrides gate", r4.chapters_indexed == [0], str(r4.chapters_indexed))


def test_project_isolation() -> None:
    section("project isolation")
    p = new_pipeline()
    asyncio.run(p.commit("alpha", [{"index": 0, "lines": CH1}]))
    asyncio.run(p.commit("beta", [{"index": 0, "lines": CH2}]))
    a = {e.name for e in p.store.list_entities("alpha", EntityKind.CHARACTER)}
    b = {e.name for e in p.store.list_entities("beta", EntityKind.CHARACTER)}
    check("alpha has Marcus", any("Marcus" in n for n in a), str(a))
    check("beta does not leak alpha", not any("Blackwood" in n for n in b), str(b))
    check("stats are scoped",
          p.store.project_stats("alpha")["entities"] > 0
          and p.store.project_stats("gamma")["entities"] == 0)


def test_authority_chain() -> None:
    section("authority chain — user corrections are never overwritten")
    p = new_pipeline()
    asyncio.run(p.commit("proj", [{"index": 0, "lines": CH1}]))

    marcus = next(e for e in p.store.list_entities("proj", EntityKind.CHARACTER)
                  if "Marcus" in e.name)
    corrected = p.store.correct_entity(
        "proj", marcus.entity_id,
        name="Marcus Vane",
        attributes={"role": "hotel clerk"},
        authority=Authority.USER,
    )
    check("correction applied", corrected is not None and corrected.name == "Marcus Vane")
    check("correction carries USER authority",
          corrected.provenance.authority is Authority.USER)
    check("old name kept as alias", "Marcus" in corrected.aliases, str(corrected.aliases))

    old = [e for e in p.store.list_entities("proj", EntityKind.CHARACTER)
           if e.entity_id == marcus.entity_id]
    check("superseded record hidden from live list", not old)
    check("superseded record retained in db",
          p.store.project_stats("proj")["entities_superseded"] >= 1)

    # Re-index the same text: inference must not clobber the correction.
    asyncio.run(p.commit("proj", [{"index": 0, "lines": CH1}], force_reindex=True))
    after = next(e for e in p.store.list_entities("proj", EntityKind.CHARACTER)
                 if e.entity_id == corrected.entity_id)
    check("user name survives re-index", after.name == "Marcus Vane", after.name)
    check("user attribute survives re-index",
          after.attributes.get("role") == "hotel clerk", str(after.attributes))
    check("authority still USER", after.provenance.authority is Authority.USER)


def test_authority_ranking() -> None:
    section("authority ranking")
    check("user outranks inference", Authority.USER.outranks(Authority.INFERENCE))
    check("corrected outranks inference", Authority.CORRECTED.outranks(Authority.INFERENCE))
    check("inference outranks system", Authority.INFERENCE.outranks(Authority.SYSTEM))
    check("user does not outrank itself", not Authority.USER.outranks(Authority.USER))


def test_continuity() -> None:
    section("continuity — observations, deduped, auto-resolving")
    p = new_pipeline()
    asyncio.run(p.commit("proj", [{"index": 0, "lines": CH1}]))

    drift = [
        'Anna Reyes opened the ledger again.',
        '"You came back," said Marcus.',
        'Anna Reyes said nothing at all.',
    ]
    r = asyncio.run(p.commit("proj", [{"index": 1, "lines": drift}]))
    flags = p.store.list_flags("proj")
    check("name drift flagged", any("Anna" in f.message or "Ana" in f.message for f in flags),
          str([f.message for f in flags]))
    check("flag is an observation not an assertion",
          all("?" in f.message or "worth" in f.message.lower()
              or "reads as" in f.message.lower() or "given as" in f.message.lower()
              or "keeping yours" in f.message.lower()
              for f in flags),
          str([f.message for f in flags]))

    before = len(p.store.list_flags("proj"))
    asyncio.run(p.commit("proj", [{"index": 1, "lines": drift}], force_reindex=True))
    check("re-index does not duplicate flags",
          len(p.store.list_flags("proj")) == before,
          f"{before} -> {len(p.store.list_flags('proj'))}")

    # Fixing the text is not enough on its own: both spellings are still
    # recorded as characters, so the question is still open.
    fixed = [
        'Ana Reyes opened the ledger again.',
        '"You came back," said Marcus.',
        'Ana Reyes said nothing at all.',
    ]
    asyncio.run(p.commit("proj", [{"index": 1, "lines": fixed}]))
    check("flag persists while both names exist as entities",
          any("very close" in f.message for f in p.store.list_flags("proj")))

    chars = p.store.list_entities("proj", EntityKind.CHARACTER)
    ana = next(e for e in chars if e.name == "Ana Reyes")
    anna = next(e for e in chars if e.name == "Anna Reyes")
    merged = p.store.merge_entities("proj", ana.entity_id, anna.entity_id)
    check("merge succeeds", merged is not None and merged.name == "Ana Reyes")
    check("absorbed name kept as alias", "Anna Reyes" in merged.aliases,
          str(merged.aliases))
    check("merge is a user act", merged.provenance.authority is Authority.USER)

    asyncio.run(p.commit("proj", [{"index": 1, "lines": fixed}], force_reindex=True))
    open_flags = [f for f in p.store.list_flags("proj")
                  if "very close" in f.message]
    check("flag auto-resolves after merge", not open_flags,
          str([f.message for f in open_flags]))

    all_flags = p.store.list_flags("proj", include_resolved=True)
    check("resolved flags retained for audit", len(all_flags) >= before)

    check("merging unrelated ids refused",
          p.store.merge_entities("proj", ana.entity_id, ana.entity_id) is None)


def test_numeric_drift() -> None:
    section("continuity — in-chapter numeric contradiction")
    p = new_pipeline()
    lines = [
        'The crew was 7 strong when they left the harbor.',
        'By evening the crew was 9 and nobody could say why.',
    ]
    asyncio.run(p.commit("proj", [{"index": 0, "lines": lines}]))
    msgs = [f.message for f in p.store.list_flags("proj")]
    check("numeric drift observed", any("7" in m and "9" in m for m in msgs), str(msgs))


def test_voice() -> None:
    section("voice training")
    p = new_pipeline()

    for i in range(6):
        p.record_voice_signal(
            "proj", "accepted",
            f'She walked out into the rain. The street was empty. Nothing moved on it at all, number {i}.',
        )
    profile = p.record_voice_signal(
        "proj", "rewritten",
        ai_text='The protagonist, feeling a profound and overwhelming sense of melancholy, ventured forth.',
        human_text='She went out. It was cold.',
    )
    check("rewrite counted", profile.rewritten_count == 1)
    check("accepts counted", profile.accepted_count == 6)
    check("rewrites weighted heavier", profile.sample_count > 7, str(profile.sample_count))
    check("profile becomes meaningful", profile.is_meaningful())
    check("sentence length measured", profile.mean_sentence_words > 0)
    check("exemplars captured", len(profile.exemplars) > 0)

    p.record_voice_signal("proj", "rejected",
                          'It was a dark and stormy night, and the wind howled interminably.')
    profile = p.store.get_style_profile("proj")
    check("rejects stored", profile.rejected_count == 1)

    guidance = profile_to_guidance(profile)
    check("guidance produced", len(guidance) > 0)
    check("guidance mentions rejected prose", "reject" in guidance.lower(), guidance[:200])

    thin = build_profile("empty", [VoiceSignal(
        project_id="empty", signal_type=VoiceSignalType.ACCEPTED, ai_text="Short.")])
    check("thin profile not meaningful", not thin.is_meaningful())
    check("thin profile yields no guidance", profile_to_guidance(thin) == "")

    try:
        p.record_voice_signal("proj", "nonsense", "x")
        check("bad signal type rejected", False, "no exception raised")
    except ValueError:
        check("bad signal type rejected", True)


def test_generation_prompt() -> None:
    section("generation prompt assembly")
    p = new_pipeline()
    asyncio.run(p.commit("proj", [{"index": 0, "lines": CH1}, {"index": 1, "lines": CH2}]))
    for _ in range(9):
        p.record_voice_signal("proj", "accepted",
                              'She walked out. The street was empty. Nothing moved.')

    system, user = p.build_generation_prompt("proj", CH2[-2:], current_chapter=1)
    check("characters injected", "Ana" in system or "Marcus" in system, system[:300])
    check("voice notes injected", "Voice notes" in system, system[:400])
    check("output discipline stated", "ONLY the new prose" in system)
    check("context in user message", CH2[-1] in user)

    system2, user2 = p.build_generation_prompt(
        "proj", CH2[-2:], current_chapter=1, instruction="Ana finds a second ledger.")
    check("instruction passed through", "second ledger" in user2)


def test_generation_with_model() -> None:
    section("generation with a provider")
    captured: dict = {}

    async def fake(system: str, user: str, max_tokens: int = 400) -> str:
        captured["system"] = system
        return "She turned the page.\nThe ink was still wet.\n"

    p = new_pipeline(provider=CallableProvider(fake))
    asyncio.run(p.commit("proj", [{"index": 0, "lines": CH1}]))
    out = asyncio.run(p.generate("proj", CH1[-2:], current_chapter=0))
    check("generation ok", out["ok"], str(out))
    check("lines split", out["lines"] == ["She turned the page.", "The ink was still wet."],
          str(out["lines"]))
    check("intelligence was used", out["intelligence_used"])
    check("entity context reached the model", "Ana" in captured.get("system", ""))

    p2 = new_pipeline()
    out2 = asyncio.run(p2.generate("proj", ["something"]))
    check("no provider reports cleanly", not out2["ok"] and "no inference provider" in out2["error"])


def test_model_indexer_resilience() -> None:
    section("resilience — model failures must not break commits")

    async def explode(system: str, user: str, max_tokens: int = 400) -> str:
        raise RuntimeError("model is on fire")

    p = new_pipeline(provider=CallableProvider(explode), use_model=True)
    r = asyncio.run(p.commit("proj", [{"index": 0, "lines": CH1}]))
    check("commit survives model explosion", r.chapters_indexed == [0], str(r.errors))
    check("rules results still stored", r.entities_created > 0)

    async def garbage(system: str, user: str, max_tokens: int = 400) -> str:
        return "Sure! Here is the JSON you asked for: {not json at all,,,}"

    p2 = new_pipeline(provider=CallableProvider(garbage), use_model=True)
    r2 = asyncio.run(p2.commit("proj", [{"index": 0, "lines": CH1}]))
    check("commit survives unparseable output", r2.chapters_indexed == [0])


def test_model_indexer_enrichment() -> None:
    section("model enrichment merges with rules")

    async def good(system: str, user: str, max_tokens: int = 400) -> str:
        return """```json
        {"characters":[{"name":"Ana Reyes","aliases":["Ana"],"role":"investigator",
                        "traits":["stubborn","soaked"],"confidence":0.9}],
         "plot_threads":[{"name":"The missing ledger","summary":"Marcus guards it",
                          "status":"open","confidence":0.8}],}
        ```"""

    p = new_pipeline(provider=CallableProvider(good), use_model=True)
    asyncio.run(p.commit("proj", [{"index": 0, "lines": CH1}]))
    ana = next((e for e in p.store.list_entities("proj", EntityKind.CHARACTER)
                if "Ana" in e.name), None)
    check("model attributes merged", ana is not None and ana.attributes.get("role") == "investigator",
          str(ana.attributes if ana else None))
    threads = p.store.list_entities("proj", EntityKind.PLOT_THREAD)
    check("plot thread captured", len(threads) == 1, str([t.name for t in threads]))
    check("thread status parsed", threads[0].attributes.get("status") == "open")


def test_json_parsing() -> None:
    section("defensive JSON parsing")
    check("fenced json", parse_json_object('```json\n{"a":1}\n```') == {"a": 1})
    check("preamble ignored", parse_json_object('Sure thing! {"a":1}') == {"a": 1})
    check("trailing comma repaired", parse_json_object('{"a":1,}') == {"a": 1})
    check("smart quotes repaired", parse_json_object('{\u201ca\u201d:1}') == {"a": 1})
    check("bare array wrapped", parse_json_object('[1,2]') == {"items": [1, 2]})
    check("nested braces survive", parse_json_object('{"a":{"b":[1,2]}}')["a"]["b"] == [1, 2])
    check("braces inside strings survive",
          parse_json_object('{"a":"a } brace"}')["a"] == "a } brace")
    check("garbage returns None", parse_json_object("no json here") is None)
    check("empty returns None", parse_json_object("") is None)


def test_intelligence_payload() -> None:
    section("intelligence retrieval")
    p = new_pipeline()
    asyncio.run(p.commit("proj", [{"index": 0, "title": "One", "lines": CH1}]))
    intel = p.intelligence("proj")
    check("cache source marked", intel["cache_source"] == "pubpartner")
    check("chapters reported", len(intel["chapters"]) == 1)
    check("characters present", "character" in intel["entities"])
    check("stats present", intel["stats"]["entities"] > 0)
    check("provenance travels with entities",
          "provenance" in intel["entities"]["character"][0])
    check("style profile null when untrained", intel["style_profile"] is None)


def test_ledger() -> None:
    section("audit ledger")
    p = new_pipeline()
    asyncio.run(p.commit("proj", [{"index": 0, "lines": CH1}]))
    p.record_voice_signal("proj", "accepted", "A line.")
    events = [e["event"] for e in p.store.read_ledger("proj")]
    check("commit recorded", "manuscript_committed" in events, str(events))
    check("voice signal recorded", "voice_signal" in events, str(events))
    check("entity creation recorded", "entity_created" in events, str(events))


def test_edge_cases() -> None:
    section("edge cases")
    p = new_pipeline()

    r = asyncio.run(p.commit("proj", [{"index": 0, "lines": []}]))
    check("empty chapter commits", r.chapters_indexed == [0], str(r.errors))

    r = asyncio.run(p.commit("proj", [{"index": "bad", "lines": ["x"]}]))
    check("bad index reported not raised", len(r.errors) == 1, str(r.errors))

    try:
        asyncio.run(p.commit("", [{"index": 0, "lines": ["x"]}]))
        check("empty project_id rejected", False)
    except ValueError:
        check("empty project_id rejected", True)

    r = asyncio.run(p.commit("proj", [{"index": 5, "lines": ["Solo chapter here."]}]))
    check("non-contiguous chapter index accepted", 5 in r.chapters_indexed)

    big = ["Ana walked. " * 20] * 50
    r = asyncio.run(p.commit("proj", [{"index": 9, "lines": big}]))
    check("large chapter handled", 9 in r.chapters_indexed and not r.errors, str(r.errors))

    unicode_lines = ['"Café," said José. He looked at the naïve sign — 日本語.']
    r = asyncio.run(p.commit("proj", [{"index": 10, "lines": unicode_lines}]))
    check("unicode chapter handled", 10 in r.chapters_indexed, str(r.errors))


def test_concurrent_commits() -> None:
    section("concurrency — commits to one project serialize")
    p = new_pipeline()

    async def run() -> list:
        return await asyncio.gather(*[
            p.commit("proj", [{"index": i, "lines": CH1}]) for i in range(4)
        ])

    results = asyncio.run(run())
    indexed = sorted(i for r in results for i in r.chapters_indexed)
    check("all four chapters indexed exactly once", indexed == [0, 1, 2, 3], str(indexed))
    check("no errors under concurrency", not any(r.errors for r in results))


def main() -> int:
    print("=" * 66)
    print("MANUSCRIPT INTELLIGENCE — TEST SUITE")
    print("=" * 66)
    for fn in [
        test_hashing, test_normalize, test_rules_extraction,
        test_commit_and_hash_gate, test_project_isolation,
        test_authority_chain, test_authority_ranking,
        test_continuity, test_numeric_drift, test_voice,
        test_generation_prompt, test_generation_with_model,
        test_model_indexer_resilience, test_model_indexer_enrichment,
        test_json_parsing, test_intelligence_payload, test_ledger,
        test_edge_cases, test_concurrent_commits,
    ]:
        try:
            fn()
        except Exception:  # noqa: BLE001
            global _FAIL
            _FAIL += 1
            print(f"  FAIL {fn.__name__} raised:")
            traceback.print_exc()
    print("\n" + "=" * 66)
    print(f"PASSED: {_PASS}    FAILED: {_FAIL}")
    print("=" * 66)
    return 1 if _FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
