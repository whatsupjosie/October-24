/* ══════════════════════════════════════════════════════════════════════
   PUBCAST 2i — MANUSCRIPT INTELLIGENCE CLIENT
   Drop-in patch for pubcast-2i-writers-room.html (v20)

   Paste this block immediately BEFORE the closing </script> tag.
   Then apply the four call-site edits listed at the bottom of this file.

   DESIGN CONTRACT — do not violate these when editing:
     1. The manuscript is never held hostage. Every call here is
        fire-and-forget. If PubPartner is down, writing continues exactly
        as it does today. No await in any editing path.
     2. 2i remains the owner of the text. This sends derived state only.
     3. Intelligence is additive. Nothing here changes the manuscript,
        moves the cursor, or alters what the writer typed.
   ══════════════════════════════════════════════════════════════════════ */

const PP = {
  base: null,              // set from the PubPartner URL field
  projectId: null,
  userId: null,
  online: false,
  lastCommit: 0,
  intelligence: null,      // local cache of server-side intelligence
  inflight: false,
  pending: false,
};

/* ── identity ──────────────────────────────────────────────────────── */

function ppIdentity() {
  let uid = localStorage.getItem('2i_user_id');
  if (!uid) {
    uid = 'user_' + Math.random().toString(36).slice(2, 14);
    localStorage.setItem('2i_user_id', uid);
  }
  PP.userId = uid;

  // Project identity follows the document, not the browser session, so
  // intelligence stays attached to the manuscript across machines.
  let pid = (typeof docMeta === 'object' && docMeta && docMeta.projectId) || null;
  if (!pid) {
    pid = localStorage.getItem('2i_project_' + (docTitle || 'untitled'));
    if (!pid) {
      pid = 'proj_' + Math.random().toString(36).slice(2, 14);
      localStorage.setItem('2i_project_' + (docTitle || 'untitled'), pid);
    }
  }
  PP.projectId = pid;
  return pid;
}

function ppBase() {
  const el = document.getElementById('llmPPEndpoint');
  const raw = (el && el.value ? el.value : 'http://localhost:8000').trim();
  return raw.replace(/\/+$/, '');
}

/* ── chapter segmentation ──────────────────────────────────────────── */

function ppChapters() {
  // Mirrors 2i's own chapter model: chapters[] hold startLine offsets into
  // committed[]. A manuscript with no chapter breaks is one chapter.
  const out = [];
  if (!chapters.length) {
    out.push({ index: 0, title: docTitle || 'Untitled', lines: committed.slice() });
    return out;
  }
  const sorted = chapters
    .map((c, i) => ({ ...c, _i: i }))
    .sort((a, b) => a.startLine - b.startLine);

  if (sorted[0].startLine > 0) {
    out.push({ index: 0, title: 'Opening', lines: committed.slice(0, sorted[0].startLine) });
  }
  sorted.forEach((ch, i) => {
    const start = ch.startLine;
    const end = i + 1 < sorted.length ? sorted[i + 1].startLine : committed.length;
    out.push({
      index: out.length,
      title: ch.title || ('Chapter ' + (i + 1)),
      lines: committed.slice(start, end),
    });
  });
  return out;
}

function ppCurrentChapterIndex() {
  const chs = ppChapters();
  const pos = committed.length;
  let acc = 0;
  for (let i = 0; i < chs.length; i++) {
    acc += chs[i].lines.length;
    if (pos <= acc) return i;
  }
  return Math.max(0, chs.length - 1);
}

/* ── transport ─────────────────────────────────────────────────────── */

async function ppFetch(path, options = {}, timeoutMs = 15000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(ppBase() + path, {
      ...options,
      signal: ctrl.signal,
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    });
    if (!r.ok) throw new Error('PubPartner ' + r.status);
    return await r.json();
  } finally {
    clearTimeout(timer);
  }
}

/* ── commit ────────────────────────────────────────────────────────── */

async function ppCommit({ force = false } = {}) {
  if (!committed.length) return;

  // Coalesce: one commit in flight at a time. A second request while one
  // is running sets a flag and re-fires once, instead of queueing a burst
  // of indexing work behind a fast typist.
  if (PP.inflight) { PP.pending = true; return; }
  PP.inflight = true;

  try {
    ppIdentity();
    const res = await ppFetch('/api/pubpartner/manuscript/commit', {
      method: 'POST',
      body: JSON.stringify({
        protocol_version: 1,
        user_id: PP.userId,
        project_id: PP.projectId,
        chapters: ppChapters(),
        force_reindex: force,
        metadata: { title: docTitle || 'Untitled', words: countWords() },
      }),
    }, 30000);

    PP.online = true;
    PP.lastCommit = Date.now();
    ppSetStatus(
      res.chapters_indexed.length
        ? 'indexed ch ' + res.chapters_indexed.join(', ')
        : 'up to date'
    );
    if (res.chapters_indexed.length) ppLoadIntelligence();
    if (res.errors && res.errors.length) {
      console.warn('[2i] commit reported issues:', res.errors);
    }
  } catch (e) {
    PP.online = false;
    ppSetStatus('offline');
    console.debug('[2i] commit skipped:', e.message);
  } finally {
    PP.inflight = false;
    if (PP.pending) { PP.pending = false; setTimeout(() => ppCommit(), 400); }
  }
}

/* ── intelligence ──────────────────────────────────────────────────── */

async function ppLoadIntelligence() {
  try {
    ppIdentity();
    const res = await ppFetch(
      '/api/pubpartner/manuscript/' + encodeURIComponent(PP.projectId) + '/intelligence'
    );
    PP.intelligence = res;
    PP.online = true;
    ppRenderFlags();
    ppRenderCast();
  } catch (e) {
    PP.online = false;
    console.debug('[2i] intelligence unavailable:', e.message);
  }
}

function ppRenderFlags() {
  const host = document.getElementById('ppFlags');
  if (!host) return;
  const flags = (PP.intelligence && PP.intelligence.flags) || [];
  if (!flags.length) { host.innerHTML = ''; host.style.display = 'none'; return; }
  host.style.display = '';
  host.innerHTML = flags.slice(0, 6).map(f =>
    '<div class="pp-flag pp-' + f.severity + '">' +
      '<span class="pp-flag-msg">' + escHtml(f.message) + '</span>' +
      '<button class="pp-flag-x" title="Dismiss" ' +
              'onclick="ppResolveFlag(\'' + f.flag_id + '\')">✕</button>' +
    '</div>'
  ).join('');
}

function ppRenderCast() {
  const host = document.getElementById('ppCast');
  if (!host) return;
  const ents = (PP.intelligence && PP.intelligence.entities) || {};
  const chars = ents.character || [];
  const locs = ents.location || [];
  if (!chars.length && !locs.length) { host.innerHTML = ''; return; }

  let html = '';
  if (chars.length) {
    html += '<div class="pp-cast-head">Characters</div>';
    html += chars.slice(0, 12).map(c => {
      const aka = c.aliases && c.aliases.length
        ? ' <span class="pp-aka">(' + escHtml(c.aliases.slice(0, 2).join(', ')) + ')</span>'
        : '';
      const conf = Math.round((c.provenance.confidence || 0) * 100);
      const userSet = c.provenance.authority === 'user';
      return '<div class="pp-cast-row" title="' +
             (userSet ? 'you set this' : 'inferred, ' + conf + '% confidence') + '">' +
             '<span class="pp-dot' + (userSet ? ' pp-user' : '') + '"></span>' +
             escHtml(c.name) + aka + '</div>';
    }).join('');
  }
  if (locs.length) {
    html += '<div class="pp-cast-head">Places</div>';
    html += locs.slice(0, 8).map(l =>
      '<div class="pp-cast-row"><span class="pp-dot"></span>' + escHtml(l.name) + '</div>'
    ).join('');
  }
  host.innerHTML = html;
}

async function ppResolveFlag(flagId) {
  try {
    await ppFetch('/api/pubpartner/manuscript/' +
      encodeURIComponent(PP.projectId) + '/flags/' + encodeURIComponent(flagId) +
      '/resolve', { method: 'POST' });
    if (PP.intelligence) {
      PP.intelligence.flags = PP.intelligence.flags.filter(f => f.flag_id !== flagId);
      ppRenderFlags();
    }
  } catch (e) {
    addChat('pp', 'Could not dismiss that note: ' + e.message);
  }
}

/* ── generation ────────────────────────────────────────────────────── */

async function ppGenerate(instruction) {
  ppIdentity();
  const res = await ppFetch('/api/pubpartner/manuscript/generate', {
    method: 'POST',
    body: JSON.stringify({
      user_id: PP.userId,
      project_id: PP.projectId,
      context_lines: committed.slice(-8).concat(buffer),
      current_chapter: ppCurrentChapterIndex(),
      instruction: instruction || null,
      max_tokens: 400,
    }),
  }, 60000);
  if (!res.ok) throw new Error(res.error || 'generation returned nothing');
  return res.lines || [];
}

/* ── voice signals ─────────────────────────────────────────────────── */

function ppVoiceSignal(type, aiText, humanText) {
  if (!aiText || !aiText.trim()) return;
  ppIdentity();
  // Fire-and-forget by design. A failed signal costs one training sample;
  // a blocked UI costs the writer their momentum.
  ppFetch('/api/pubpartner/manuscript/voice-signal', {
    method: 'POST',
    body: JSON.stringify({
      user_id: PP.userId,
      project_id: PP.projectId,
      type: type,
      ai_text: aiText,
      human_text: humanText || null,
      chapter_index: ppCurrentChapterIndex(),
    }),
  }, 8000).catch(e => console.debug('[2i] voice signal dropped:', e.message));
}

/* ── status ────────────────────────────────────────────────────────── */

function ppSetStatus(text) {
  const el = document.getElementById('ppStatus');
  if (!el) return;
  el.textContent = 'PubPartner: ' + text;
  el.className = 'pp-status ' + (PP.online ? 'ok' : 'off');
}

async function ppHealthCheck() {
  try {
    ppIdentity();
    const res = await ppFetch('/api/pubpartner/manuscript/' +
      encodeURIComponent(PP.projectId) + '/health', {}, 5000);
    PP.online = true;
    ppSetStatus(res.stats.entities + ' known');
    ppLoadIntelligence();
  } catch (e) {
    PP.online = false;
    ppSetStatus('offline');
  }
}

/* ── boot ──────────────────────────────────────────────────────────── */

window.addEventListener('load', () => {
  setTimeout(ppHealthCheck, 1200);
  // Periodic commit catches work that never passed through approveBuffer,
  // such as a long solo-mode session.
  setInterval(() => {
    if (committed.length && Date.now() - PP.lastCommit > 120000) ppCommit();
  }, 60000);
});

/* ══════════════════════════════════════════════════════════════════════
   CALL-SITE EDITS — apply these four by hand in the v20 file
   ══════════════════════════════════════════════════════════════════════

   [1] approveBuffer()  — commit after the writer accepts a draft
   ----------------------------------------------------------------------
   function approveBuffer() {
     if (!buffer.length) return;
     snapshot();
     const approved = buffer.slice();          // ADD
     committed.push(...buffer);
     buffer = []; draftArea.value = '';
     selectedIdx = null; editingIdx = null;
     markDirty(); render();
     closeMenu();
     approved.forEach(t => ppVoiceSignal('accepted', t));   // ADD
     ppCommit();                                            // ADD
   }

   [2] generateMore()  — route through PubPartner when it is available
   ----------------------------------------------------------------------
   Insert at the top of the try block, before the existing callLLM path:

     if (PP.online) {
       try {
         const lines = await ppGenerate();
         if (lines.length) { pool = pool.concat(lines); return true; }
       } catch (e) {
         console.debug('[2i] falling back to direct LLM:', e.message);
       }
     }

   Leave the existing direct-LLM code in place underneath. It is the
   fallback when PubPartner is unreachable.

   [3] reject button  — record what the writer threw away
   ----------------------------------------------------------------------
   Wherever the reject handler drops a generated line, add:

     ppVoiceSignal('rejected', rejectedText);

   [4] line edit commit  — record rewrites, the richest signal of all
   ----------------------------------------------------------------------
   In the handler that saves an edited line, if the line originally came
   from generation:

     ppVoiceSignal('rewritten', originalAiText, newText);

   ══════════════════════════════════════════════════════════════════════
   MARKUP — add to the sidebar, inside the PubPartner chat section
   ══════════════════════════════════════════════════════════════════════

   <div id="ppStatus" class="pp-status off">PubPartner: offline</div>
   <div id="ppFlags"></div>
   <div id="ppCast"></div>

   ══════════════════════════════════════════════════════════════════════
   CSS — append to the existing stylesheet
   ══════════════════════════════════════════════════════════════════════

   .pp-status { font-size:10px; letter-spacing:.04em; padding:3px 6px;
                border-radius:3px; margin-bottom:6px; }
   .pp-status.ok  { color:var(--gold); background:rgba(205,163,73,.10); }
   .pp-status.off { color:var(--parchment-soft); background:rgba(0,0,0,.18); }

   .pp-flag { display:flex; align-items:flex-start; gap:6px; font-size:11px;
              line-height:1.35; padding:5px 6px; margin-bottom:4px;
              border-left:2px solid var(--parchment-soft);
              background:rgba(0,0,0,.16); border-radius:0 3px 3px 0; }
   .pp-flag.pp-attention { border-left-color:var(--gold); }
   .pp-flag.pp-concern   { border-left-color:var(--danger); }
   .pp-flag-msg { flex:1; }
   .pp-flag-x { background:none; border:none; color:var(--parchment-soft);
                cursor:pointer; font-size:10px; padding:0 2px; }
   .pp-flag-x:hover { color:var(--parchment); }

   .pp-cast-head { font-size:9px; letter-spacing:.12em; text-transform:uppercase;
                   color:var(--parchment-soft); margin:8px 0 3px; }
   .pp-cast-row { font-size:11px; padding:2px 0; display:flex;
                  align-items:center; gap:5px; }
   .pp-dot { width:4px; height:4px; border-radius:50%;
             background:var(--parchment-soft); flex:0 0 auto; }
   .pp-dot.pp-user { background:var(--gold); }
   .pp-aka { color:var(--parchment-soft); font-size:10px; }
   ══════════════════════════════════════════════════════════════════════ */
