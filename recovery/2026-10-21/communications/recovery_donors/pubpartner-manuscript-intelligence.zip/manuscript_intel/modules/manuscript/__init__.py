"""
Manuscript intelligence for PubPartner.

2i owns the manuscript. This owns what was learned from it.

    store    = ManuscriptStore(Path("data/pubpartner/manuscript_intelligence.db"))
    pipeline = ManuscriptPipeline(store, provider=my_provider)
    app.include_router(build_manuscript_router(pipeline))
"""
from .models import (
    Authority,
    CommitResult,
    ContinuityFlag,
    Entity,
    EntityKind,
    FlagSeverity,
    MemoryType,
    Provenance,
    StyleProfile,
    VoiceSignal,
    VoiceSignalType,
    normalize_name,
)
from .hashing import djb2_hash, hash_chapter
from .inference import (
    CallableProvider,
    InferenceProvider,
    NullProvider,
    parse_json_object,
)
from .store import ManuscriptStore
from .pipeline import ManuscriptPipeline
from .voice import build_profile, profile_to_guidance
from .routes import build_manuscript_router, FASTAPI_AVAILABLE

__version__ = "1.0.0"

__all__ = [
    "Authority", "CommitResult", "ContinuityFlag", "Entity", "EntityKind",
    "FlagSeverity", "MemoryType", "Provenance", "StyleProfile", "VoiceSignal",
    "VoiceSignalType", "normalize_name",
    "djb2_hash", "hash_chapter",
    "CallableProvider", "InferenceProvider", "NullProvider", "parse_json_object",
    "ManuscriptStore", "ManuscriptPipeline",
    "build_profile", "profile_to_guidance",
    "build_manuscript_router", "FASTAPI_AVAILABLE",
]
