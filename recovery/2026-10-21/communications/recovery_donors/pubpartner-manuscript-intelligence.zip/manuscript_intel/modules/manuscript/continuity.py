"""
Continuity watchdog.

Produces OBSERVATIONS. Never assertions, never edits, never auto-fixes.
Every flag is phrased so a writer can dismiss it without arguing with
the software. The writer is the authority on their own book.

Each flag carries a stable fingerprint so that re-indexing the same text
does not stack duplicates, and so a flag whose condition disappears can
be auto-resolved.
"""
from __future__ import annotations

import difflib
import logging
import re
from typing import Dict, List, Optional, Sequence, Tuple

from .hashing import djb2_hash
from .models import (
    Authority,
    ContinuityFlag,
    Entity,
    EntityKind,
    FlagSeverity,
    Provenance,
    normalize_name,
)

logger = logging.getLogger(__name__)

# Words that suggest a character has left the story in a way that makes a
# later casual appearance worth a second look.
_EXIT_MARKERS = re.compile(
    r"\b(died|dies|dead|killed|murdered|buried|funeral|corpse|body of|"
    r"left for good|never returned|never came back|disappeared|vanished|"
    r"moved away|gone for good)\b",
    re.IGNORECASE,
)

_NUMBER_RE = re.compile(r"\b(\d{1,4})\b")


def fingerprint(*parts: object) -> str:
    return djb2_hash("|".join(str(p) for p in parts))


def _flag(
    project_id: str,
    message: str,
    *,
    severity: FlagSeverity,
    chapter_index: Optional[int],
    entity_id: Optional[str] = None,
    evidence: Optional[List[str]] = None,
    confidence: float = 0.5,
    revision_id: Optional[str] = None,
) -> ContinuityFlag:
    return ContinuityFlag(
        project_id=project_id,
        message=message,
        severity=severity,
        entity_id=entity_id,
        chapter_index=chapter_index,
        evidence=evidence or [],
        provenance=Provenance(
            source="continuity_watchdog",
            authority=Authority.INFERENCE,
            confidence=confidence,
            revision_id=revision_id,
        ),
    )


def check_chapter(
    project_id: str,
    chapter_index: int,
    lines: Sequence[str],
    new_entities: Sequence[Entity],
    known_entities: Sequence[Entity],
    *,
    revision_id: Optional[str] = None,
    name_candidates: Optional[Dict[str, str]] = None,
) -> List[Tuple[ContinuityFlag, str]]:
    """
    Run all checks for one chapter.

    Returns (flag, fingerprint) pairs. The caller decides what to persist.
    """
    flags: List[Tuple[ContinuityFlag, str]] = []
    text = "\n".join(lines)

    flags.extend(_check_name_drift(project_id, chapter_index, new_entities,
                                   known_entities, revision_id,
                                   name_candidates or {}))
    flags.extend(_check_exited_characters(project_id, chapter_index, text,
                                          new_entities, known_entities, revision_id))
    flags.extend(_check_attribute_conflicts(project_id, chapter_index,
                                            new_entities, known_entities, revision_id))
    flags.extend(_check_numeric_drift(project_id, chapter_index, lines, revision_id))

    logger.debug("continuity ch%d: %d observations", chapter_index, len(flags))
    return flags


# ──────────────────────────────────────────────────────────────────────
# CHECK: near-identical names
# ──────────────────────────────────────────────────────────────────────

def _check_name_drift(
    project_id: str,
    chapter_index: int,
    new_entities: Sequence[Entity],
    known_entities: Sequence[Entity],
    revision_id: Optional[str],
    name_candidates: Dict[str, str],
) -> List[Tuple[ContinuityFlag, str]]:
    """
    'Kaitlyn' in chapter 1, 'Katelyn' in chapter 4.

    Either a typo or two people. The software cannot tell. It asks.
    """
    out: List[Tuple[ContinuityFlag, str]] = []
    known_chars = [e for e in known_entities if e.kind == EntityKind.CHARACTER]
    known_by_key = {normalize_name(e.name): e for e in known_chars}

    # Compare the pair, not the novelty of the name. Once a misspelling has
    # itself been recorded as an entity, a "is this name new?" check stops
    # seeing the problem and the flag would wrongly auto-resolve while both
    # spellings are still sitting in the manuscript.
    seen_pairs: set[frozenset] = set()

    # Candidates include names too weak to have become entities. A typo
    # usually appears exactly once, which is precisely the case an
    # entity-only comparison would never see.
    subjects: Dict[str, Tuple[str, Optional[Entity]]] = {}
    for ent in new_entities:
        if ent.kind == EntityKind.CHARACTER:
            k = normalize_name(ent.name)
            if k:
                subjects[k] = (ent.name, ent)
    for key, surface in name_candidates.items():
        subjects.setdefault(key, (surface, None))

    for key, (surface, ent) in subjects.items():
        ent_aliases = {normalize_name(a) for a in (ent.aliases if ent else [])}

        for other_key, other in known_by_key.items():
            if other_key == key:
                continue
            pair = frozenset((key, other_key))
            if pair in seen_pairs:
                continue
            # Already linked as the same person — nothing to ask about.
            if other_key in ent_aliases:
                continue
            if key in {normalize_name(a) for a in other.aliases}:
                continue
            if difflib.SequenceMatcher(None, key, other_key).ratio() < 0.86:
                continue
            seen_pairs.add(pair)
            fp = fingerprint("name_drift", project_id, *sorted(pair))
            out.append((_flag(
                project_id,
                f"“{surface}” is very close to “{other.name}”. "
                f"Same person, or two different characters?",
                severity=FlagSeverity.ATTENTION,
                chapter_index=chapter_index,
                entity_id=other.entity_id,
                evidence=[f"chapter {chapter_index}: {surface}",
                          f"also in manuscript: {other.name}"],
                confidence=0.55,
                revision_id=revision_id,
            ), fp))
    return out


# ──────────────────────────────────────────────────────────────────────
# CHECK: character returns after an exit
# ──────────────────────────────────────────────────────────────────────

def _check_exited_characters(
    project_id: str,
    chapter_index: int,
    text: str,
    new_entities: Sequence[Entity],
    known_entities: Sequence[Entity],
    revision_id: Optional[str],
) -> List[Tuple[ContinuityFlag, str]]:
    out: List[Tuple[ContinuityFlag, str]] = []
    for known in known_entities:
        if known.kind != EntityKind.CHARACTER:
            continue
        exit_ch = known.attributes.get("exited_chapter")
        if exit_ch is None or chapter_index <= int(exit_ch):
            continue
        key = normalize_name(known.name)
        appears = any(normalize_name(e.name) == key for e in new_entities)
        if not appears:
            continue
        fp = fingerprint("exit_return", project_id, key, chapter_index)
        out.append((_flag(
            project_id,
            f"“{known.name}” appears in chapter {chapter_index}, after chapter "
            f"{exit_ch} suggested they had left the story. Worth a look if that "
            f"was not intentional.",
            severity=FlagSeverity.ATTENTION,
            chapter_index=chapter_index,
            entity_id=known.entity_id,
            evidence=[str(known.attributes.get("exit_evidence", ""))[:200]],
            confidence=0.5,
            revision_id=revision_id,
        ), fp))

    # Record exits found in THIS chapter for future passes.
    for ent in new_entities:
        if ent.kind != EntityKind.CHARACTER:
            continue
        pattern = re.compile(
            rf"[^.!?]*\b{re.escape(ent.name.split()[0])}\b[^.!?]*[.!?]", re.IGNORECASE
        )
        for sent in pattern.findall(text)[:6]:
            if _EXIT_MARKERS.search(sent):
                ent.attributes["exited_chapter"] = chapter_index
                ent.attributes["exit_evidence"] = sent.strip()[:200]
                break
    return out


# ──────────────────────────────────────────────────────────────────────
# CHECK: conflicting attributes
# ──────────────────────────────────────────────────────────────────────

_WATCHED_ATTRS = ("role", "occupation", "age", "eye_color", "hair", "hometown")


def _check_attribute_conflicts(
    project_id: str,
    chapter_index: int,
    new_entities: Sequence[Entity],
    known_entities: Sequence[Entity],
    revision_id: Optional[str],
) -> List[Tuple[ContinuityFlag, str]]:
    out: List[Tuple[ContinuityFlag, str]] = []
    known_by_key = {normalize_name(e.name): e for e in known_entities}
    for ent in new_entities:
        known = known_by_key.get(normalize_name(ent.name))
        if known is None:
            continue
        for attr in _WATCHED_ATTRS:
            new_val = ent.attributes.get(attr)
            old_val = known.attributes.get(attr)
            if not new_val or not old_val:
                continue
            if str(new_val).strip().lower() == str(old_val).strip().lower():
                continue
            # A USER-authored value is the truth; an inference disagreeing
            # with it is the inference's problem, not the manuscript's.
            if known.provenance.authority.outranks(ent.provenance.authority):
                severity = FlagSeverity.NOTE
                msg = (
                    f"The text in chapter {chapter_index} reads as "
                    f"{attr.replace('_', ' ')} “{new_val}” for {known.name}, but "
                    f"you set that to “{old_val}”. Keeping yours."
                )
            else:
                severity = FlagSeverity.ATTENTION
                msg = (
                    f"{known.name}: {attr.replace('_', ' ')} reads as “{new_val}” "
                    f"in chapter {chapter_index} but “{old_val}” earlier."
                )
            fp = fingerprint("attr_conflict", project_id,
                             normalize_name(ent.name), attr, str(new_val), str(old_val))
            out.append((_flag(
                project_id, msg,
                severity=severity,
                chapter_index=chapter_index,
                entity_id=known.entity_id,
                evidence=[f"earlier: {old_val}", f"chapter {chapter_index}: {new_val}"],
                confidence=0.6,
                revision_id=revision_id,
            ), fp))
    return out


# ──────────────────────────────────────────────────────────────────────
# CHECK: numbers that move
# ──────────────────────────────────────────────────────────────────────

_COUNT_CONTEXT = re.compile(
    r"\b([A-Za-z][\w'’\-]*)\s+(?:was|were|had|has|is|are)\s+(\d{1,4})\b",
    re.IGNORECASE,
)


def _check_numeric_drift(
    project_id: str,
    chapter_index: int,
    lines: Sequence[str],
    revision_id: Optional[str],
) -> List[Tuple[ContinuityFlag, str]]:
    """
    Within one chapter: the same subject given two different numbers.

    Deliberately narrow. Cross-chapter numeric tracking needs a real
    fact store with units and context; that is Phase 2. This catches the
    obvious in-chapter contradiction and nothing more.
    """
    out: List[Tuple[ContinuityFlag, str]] = []
    seen: Dict[str, Tuple[str, str]] = {}
    for line in lines:
        for m in _COUNT_CONTEXT.finditer(line):
            subject = m.group(1).strip().lower()
            value = m.group(2)
            if subject in seen and seen[subject][0] != value:
                prev_val, prev_line = seen[subject]
                fp = fingerprint("num_drift", project_id, chapter_index,
                                 subject, prev_val, value)
                out.append((_flag(
                    project_id,
                    f"“{subject}” is given as {prev_val} and also {value} in "
                    f"chapter {chapter_index}.",
                    severity=FlagSeverity.NOTE,
                    chapter_index=chapter_index,
                    evidence=[prev_line[:160], line[:160]],
                    confidence=0.45,
                    revision_id=revision_id,
                ), fp))
            else:
                seen[subject] = (value, line)
    return out
