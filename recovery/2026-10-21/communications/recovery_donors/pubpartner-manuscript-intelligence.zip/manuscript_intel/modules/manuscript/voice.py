"""
Voice training.

The accept/reject/rewrite buttons in 2i are not just editorial controls.
They are labelled training data, and they are free — the writer was going
to press them anyway.

This module turns those signals into a style profile using arithmetic
only. No model, no embeddings, no GPU. It runs in milliseconds on a
2015 i7 and it is honest about when it does not yet know enough.

What the profile measures:
  - sentence length (mean and median — median resists one long sentence)
  - dialogue ratio
  - paragraph rhythm
  - punctuation density (commas, semicolons, em dashes)
  - exemplars: what the writer kept, and what they threw away

A REWRITTEN signal is the most valuable of the three: it is a matched
pair showing exactly what the AI got wrong and what right looked like.
Rewrites are weighted accordingly.
"""
from __future__ import annotations

import logging
import re
import statistics
from typing import Dict, List, Optional, Sequence, Tuple

from .models import StyleProfile, VoiceSignal, VoiceSignalType

logger = logging.getLogger(__name__)

_SENTENCE_RE = re.compile(r"([.!?]+[\"'”’)\]]*)\s+")
_DIALOGUE_RE = re.compile(r"[\"“][^\"”]{1,600}[\"”]")
_WORD_RE = re.compile(r"[A-Za-z'’\-]+")

REWRITE_WEIGHT = 3
ACCEPT_WEIGHT = 1
MIN_SAMPLES = 8


def _sentences(text: str) -> List[str]:
    text = text.strip()
    if not text:
        return []
    parts = _SENTENCE_RE.split(text)
    out: List[str] = []
    for i in range(0, len(parts) - 1, 2):
        s = (parts[i] + parts[i + 1]).strip()
        if s:
            out.append(s)
    tail = parts[-1].strip() if len(parts) % 2 else ""
    if tail:
        out.append(tail)
    return out


def _words(text: str) -> List[str]:
    return _WORD_RE.findall(text)


def measure(text: str) -> Optional[Dict[str, float]]:
    """Per-sample measurements. None if there is nothing to measure."""
    sents = _sentences(text)
    words = _words(text)
    if not sents or not words:
        return None
    lengths = [len(_words(s)) for s in sents if _words(s)]
    if not lengths:
        return None
    dialogue_chars = sum(len(m.group(0)) for m in _DIALOGUE_RE.finditer(text))
    total_chars = max(len(text), 1)
    word_count = max(len(words), 1)
    return {
        "mean_sentence_words": statistics.fmean(lengths),
        "median_sentence_words": float(statistics.median(lengths)),
        "sentence_count": float(len(lengths)),
        "dialogue_ratio": dialogue_chars / total_chars,
        "comma_density": text.count(",") / word_count,
        "semicolon_density": text.count(";") / word_count,
        "em_dash_density": (text.count("—") + text.count("--")) / word_count,
    }


def build_profile(
    project_id: str, signals: Sequence[VoiceSignal]
) -> StyleProfile:
    """
    Build a style profile from signals.

    Target text selection:
      ACCEPTED  -> the AI text (the writer kept it, so it was right)
      REWRITTEN -> the HUMAN text (what right actually looked like)
      REJECTED  -> nothing positive; goes to avoid_exemplars
    """
    profile = StyleProfile(project_id=project_id)

    weighted: List[Tuple[Dict[str, float], int]] = []
    accepted_texts: List[str] = []
    rejected_texts: List[str] = []
    paragraph_sentence_counts: List[float] = []

    for sig in signals:
        if sig.signal_type is VoiceSignalType.ACCEPTED:
            profile.accepted_count += 1
            target, weight = sig.ai_text, ACCEPT_WEIGHT
        elif sig.signal_type is VoiceSignalType.REWRITTEN:
            profile.rewritten_count += 1
            target, weight = (sig.human_text or ""), REWRITE_WEIGHT
        else:
            profile.rejected_count += 1
            if sig.ai_text.strip():
                rejected_texts.append(sig.ai_text.strip())
            continue

        target = (target or "").strip()
        if not target:
            continue
        m = measure(target)
        if m is None:
            continue
        weighted.append((m, weight))
        accepted_texts.append(target)
        paragraph_sentence_counts.append(m["sentence_count"])

    profile.sample_count = sum(w for _, w in weighted)

    if weighted:
        total_w = sum(w for _, w in weighted)

        def wmean(key: str) -> float:
            return sum(m[key] * w for m, w in weighted) / total_w

        profile.mean_sentence_words = round(wmean("mean_sentence_words"), 2)
        profile.dialogue_ratio = round(wmean("dialogue_ratio"), 4)
        profile.comma_density = round(wmean("comma_density"), 4)
        profile.semicolon_density = round(wmean("semicolon_density"), 4)
        profile.em_dash_density = round(wmean("em_dash_density"), 4)
        medians = [m["median_sentence_words"] for m, _ in weighted]
        profile.median_sentence_words = round(float(statistics.median(medians)), 2)

    if paragraph_sentence_counts:
        profile.mean_paragraph_sentences = round(
            statistics.fmean(paragraph_sentence_counts), 2
        )

    # Exemplars: most recent first, capped. Long enough to show rhythm,
    # short enough not to eat the generation context window.
    profile.exemplars = [t for t in accepted_texts if 40 <= len(t) <= 400][:6]
    profile.avoid_exemplars = [t for t in rejected_texts if 40 <= len(t) <= 400][:4]

    logger.debug(
        "style profile %s: %d weighted samples (a=%d r=%d w=%d)",
        project_id, profile.sample_count, profile.accepted_count,
        profile.rejected_count, profile.rewritten_count,
    )
    return profile


def profile_to_guidance(profile: StyleProfile) -> str:
    """
    Render the profile as prompt guidance.

    Returns "" when the sample count is too low. Steering a model with a
    profile built from two clicks produces confident nonsense, which is
    worse than no steering at all.
    """
    if not profile.is_meaningful():
        return ""

    parts: List[str] = []
    msw = profile.mean_sentence_words
    if msw:
        if msw < 11:
            parts.append(f"Short sentences — around {msw:.0f} words on average.")
        elif msw > 22:
            parts.append(f"Long, flowing sentences — around {msw:.0f} words on average.")
        else:
            parts.append(f"Sentences average about {msw:.0f} words.")

    if profile.dialogue_ratio > 0.45:
        parts.append("Dialogue-heavy; let characters carry the scene.")
    elif profile.dialogue_ratio < 0.08:
        parts.append("Very little dialogue; narration carries the scene.")

    if profile.semicolon_density > 0.006:
        parts.append("Semicolons are part of this voice.")
    elif profile.semicolon_density == 0.0 and profile.sample_count >= 12:
        parts.append("No semicolons.")

    if profile.em_dash_density > 0.012:
        parts.append("Em dashes are used freely.")
    elif profile.em_dash_density < 0.001 and profile.sample_count >= 12:
        parts.append("Avoid em dashes.")

    if profile.comma_density > 0.12:
        parts.append("Commas are used generously.")
    elif profile.comma_density < 0.04:
        parts.append("Sparse comma use; clauses run clean.")

    if profile.mean_paragraph_sentences:
        parts.append(
            f"Passages run about {profile.mean_paragraph_sentences:.0f} sentences."
        )

    guidance = "Voice notes for this manuscript:\n- " + "\n- ".join(parts)

    if profile.exemplars:
        guidance += "\n\nProse the writer kept:\n"
        guidance += "\n".join(f'  "{t}"' for t in profile.exemplars[:3])
    if profile.avoid_exemplars:
        guidance += "\n\nProse the writer rejected — do not write like this:\n"
        guidance += "\n".join(f'  "{t}"' for t in profile.avoid_exemplars[:2])

    return guidance
