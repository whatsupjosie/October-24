"""
Manuscript indexer.

Reads chapter text and produces entities: characters, locations, plot
threads, timeline events.

Two tiers, in this order:

  TIER 1 — RULES (always runs, no model, no network)
    Deterministic extraction from capitalization, dialogue attribution,
    and locative prepositions. Cheap enough to run on every commit of
    every changed chapter. Confidence caps at 0.65 because heuristics
    are heuristics.

  TIER 2 — MODEL (opt-in, only when a provider is configured)
    Enriches tier-1 output with relationships, traits, and plot threads
    that rules cannot see. Failure here is not an error — the commit
    still returns tier-1 results.

The hash gate lives in the caller (pipeline.py). This module indexes
whatever chapter it is handed.
"""
from __future__ import annotations

import logging
import re
from collections import Counter
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .inference import (
    InferenceProvider,
    coerce_float,
    coerce_str_list,
    parse_json_object,
)
from .models import (
    Authority,
    Entity,
    EntityKind,
    Provenance,
    normalize_name,
)

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────────────
# STOPWORDS — capitalized tokens that are not names
# ──────────────────────────────────────────────────────────────────────

_SENTENCE_START_NOISE = {
    "the", "a", "an", "and", "but", "or", "so", "for", "nor", "yet",
    "i", "it", "he", "she", "they", "we", "you", "this", "that", "these",
    "those", "there", "here", "then", "when", "where", "what", "why",
    "how", "who", "if", "as", "at", "by", "in", "on", "to", "up", "of",
    "his", "her", "their", "its", "my", "our", "your", "not", "no",
    "yes", "well", "still", "just", "once", "after", "before", "now",
    "later", "outside", "inside", "somewhere", "nothing", "something",
    "everything", "anyone", "someone", "everyone", "nobody", "maybe",
    "perhaps", "even", "only", "all", "both", "each", "every", "some",
    "any", "another", "other", "same", "such", "than", "too", "very",
    "can", "will", "would", "could", "should", "may", "might", "must",
    "do", "does", "did", "have", "has", "had", "be", "been", "being",
    "am", "is", "are", "was", "were", "let", "get", "got", "go", "went",
    "come", "came", "said", "says", "like", "one", "two", "three",
    "chapter", "part", "book", "prologue", "epilogue",
}

_MONTHS_DAYS = {
    "january", "february", "march", "april", "may", "june", "july",
    "august", "september", "october", "november", "december",
    "monday", "tuesday", "wednesday", "thursday", "friday", "saturday",
    "sunday",
}

_SPEECH_VERBS = {
    "said", "asked", "replied", "answered", "shouted", "whispered",
    "muttered", "murmured", "yelled", "called", "cried", "growled",
    "snapped", "sighed", "laughed", "added", "continued", "insisted",
    "offered", "admitted", "confessed", "warned", "explained", "repeated",
    "breathed", "hissed", "barked", "observed", "noted", "countered",
}

_LOCATION_HEADS = {
    "street", "road", "avenue", "lane", "alley", "boulevard", "highway",
    "bridge", "river", "lake", "mountain", "valley", "forest", "woods",
    "beach", "harbor", "harbour", "port", "station", "airport", "hotel",
    "motel", "inn", "tavern", "bar", "pub", "cafe", "restaurant", "diner",
    "office", "building", "tower", "hall", "house", "manor", "cottage",
    "cabin", "apartment", "church", "cathedral", "temple", "school",
    "university", "college", "library", "museum", "hospital", "clinic",
    "prison", "jail", "precinct", "market", "square", "park", "garden",
    "cemetery", "graveyard", "warehouse", "factory", "mill", "farm",
    "ranch", "castle", "fortress", "camp", "base", "city", "town",
    "village", "county", "district", "quarter", "island", "desert",
    "canyon", "cliff", "trail", "path", "room", "kitchen", "basement",
    "attic", "hallway", "corridor", "studio", "theater", "theatre",
    "lobby", "bedroom", "bathroom", "office", "cellar", "porch", "yard",
    "gate", "door", "stairwell", "landing", "deck", "platform",
}

_TIME_MARKERS = [
    "the next morning", "the next day", "the following day", "that night",
    "that evening", "that afternoon", "the next evening", "hours later",
    "days later", "weeks later", "months later", "years later",
    "a week later", "a month later", "a year later", "the day before",
    "the night before", "earlier that", "later that", "by morning",
    "by nightfall", "at dawn", "at dusk", "at midnight", "at noon",
    "three days later", "two days later", "the previous night",
]

_NAME_RE = re.compile(r"\b([A-Z][a-z'’\-]{1,20}(?:\s+[A-Z][a-z'’\-]{1,20}){0,2})\b")
# Python's re does not allow variable-width lookbehind, so the terminator is
# captured and stitched back onto the preceding sentence.
_SENTENCE_SPLIT_RE = re.compile(r"([.!?]+[\"'”’)\]]*)\s+")
_DIALOGUE_RE = re.compile(r"[\"“]([^\"”]{1,400})[\"”]")


def split_sentences(text: str) -> List[str]:
    text = text.strip()
    if not text:
        return []
    parts = _SENTENCE_SPLIT_RE.split(text)
    out: List[str] = []
    # parts alternates: body, terminator, body, terminator, ..., tail
    for i in range(0, len(parts) - 1, 2):
        sentence = (parts[i] + parts[i + 1]).strip()
        if sentence:
            out.append(sentence)
    tail = parts[-1].strip() if len(parts) % 2 else ""
    if tail:
        out.append(tail)
    return out


def _is_plausible_name(candidate: str, *, at_sentence_start: bool) -> bool:
    tokens = candidate.split()
    low = candidate.lower()
    if low in _MONTHS_DAYS:
        return False
    if len(tokens) == 1:
        t = tokens[0].lower()
        if t in _SENTENCE_START_NOISE or t in _MONTHS_DAYS:
            return False
        if len(t) < 2:
            return False
        # A lone capitalized word starting a sentence is usually not a name.
        if at_sentence_start:
            return False
        return True
    if tokens[0].lower() in _SENTENCE_START_NOISE:
        return False
    return True


def _candidate_names(sentence: str) -> List[str]:
    out: List[str] = []
    for m in _NAME_RE.finditer(sentence):
        cand = m.group(1).strip()
        at_start = m.start() == 0
        if _is_plausible_name(cand, at_sentence_start=at_start):
            out.append(cand)
    return out


def _dialogue_attributions(sentence: str) -> List[str]:
    """Find 'X said' / 'said X' patterns — the strongest character signal."""
    found: List[str] = []
    verbs = "|".join(sorted(_SPEECH_VERBS))
    for pat in (
        rf"\b([A-Z][a-z'’\-]+(?:\s+[A-Z][a-z'’\-]+)?)\s+(?:{verbs})\b",
        rf"\b(?:{verbs})\s+([A-Z][a-z'’\-]+(?:\s+[A-Z][a-z'’\-]+)?)\b",
    ):
        for m in re.finditer(pat, sentence):
            cand = m.group(1).strip()
            if _is_plausible_name(cand, at_sentence_start=False):
                found.append(cand)
    return found


def _location_candidates(sentence: str) -> List[str]:
    out: List[str] = []
    # "at the Blackwood Hotel", "in Ravensbourne"
    for m in re.finditer(
        r"\b(?:at|in|to|of|from|near|inside|outside|toward|towards|through|across|behind)\s+"
        r"(?:the\s+)?([A-Z][a-z'’\-]+(?:\s+[A-Z][a-z'’\-]+){0,3})\b",
        sentence,
    ):
        cand = m.group(1).strip()
        if _is_plausible_name(cand, at_sentence_start=False):
            out.append(cand)
    # "the old mill", "the precinct" — common-noun places
    for m in re.finditer(r"\bthe\s+((?:[a-z'’\-]+\s+){0,2}[a-z'’\-]+)\b", sentence):
        phrase = m.group(1).strip()
        head = phrase.split()[-1]
        if head in _LOCATION_HEADS:
            out.append("the " + phrase)
    return out


def _time_markers(sentence: str) -> List[str]:
    low = sentence.lower()
    return [marker for marker in _TIME_MARKERS if marker in low]


# ──────────────────────────────────────────────────────────────────────
# NAME CONSOLIDATION
# ──────────────────────────────────────────────────────────────────────

def _consolidate_names(
    counts: Counter,
    surfaces: Dict[str, str],
    attributed: set,
) -> Tuple[Counter, Dict[str, str], set, Dict[str, set]]:
    """
    Fold single-token names into the multi-token names that contain them.

    'Ana' + 'Ana Reyes'          -> 'Ana Reyes'  (alias: Ana)
    'Reyes' + 'Ana Reyes'        -> 'Ana Reyes'  (alias: Reyes)
    'Ana' + 'Ana Reyes' + 'Ana Vane' -> left alone; ambiguous, and guessing
                                     here would merge two different people.
    """
    multi = [k for k in counts if " " in k]
    single = [k for k in counts if " " not in k]

    absorb: Dict[str, str] = {}
    for s in single:
        hosts = [m for m in multi if s in m.split()]
        if len(hosts) == 1:
            absorb[s] = hosts[0]

    if not absorb:
        return counts, surfaces, attributed, {}

    new_counts: Counter = Counter()
    new_surfaces: Dict[str, str] = {}
    new_attributed: set = set()
    aliases: Dict[str, set] = {}

    for key, count in counts.items():
        target = absorb.get(key, key)
        new_counts[target] += count
        surface = surfaces.get(key, key)
        if target not in new_surfaces or len(surface) > len(new_surfaces[target]):
            if target == key:
                new_surfaces[target] = surface
            else:
                new_surfaces.setdefault(target, surfaces.get(target, target))
        if key in attributed:
            new_attributed.add(target)
        if target != key:
            aliases.setdefault(target, set()).add(surfaces.get(key, key))

    for target in new_counts:
        new_surfaces.setdefault(target, surfaces.get(target, target))

    return new_counts, new_surfaces, new_attributed, aliases


# ──────────────────────────────────────────────────────────────────────
# TIER 1 — RULES
# ──────────────────────────────────────────────────────────────────────

def scan_name_candidates(lines: Sequence[str]) -> Dict[str, str]:
    """
    Every capitalized name-shaped token in the chapter, including ones too
    weak to become entities.

    A misspelling usually appears once. If drift detection only sees names
    that cleared the entity threshold, the single-occurrence typo — the
    most common kind — is exactly what it misses.
    """
    found: Dict[str, str] = {}
    for line in lines:
        for sent in split_sentences(line):
            for cand in _candidate_names(sent) + _dialogue_attributions(sent):
                key = normalize_name(cand)
                if not key:
                    continue
                if key not in found or len(cand) > len(found[key]):
                    found[key] = cand
    return found


def extract_rules(
    lines: Sequence[str], chapter_index: int, *, revision_id: Optional[str] = None
) -> List[Entity]:
    """
    Deterministic extraction. No model, no network, no failure mode.

    Confidence model:
      0.65  name carried a dialogue attribution (strong)
      0.50  name appeared 3+ times
      0.35  name appeared once or twice (weak — kept, but marked weak)
    """
    text = "\n".join(lines)
    sentences: List[str] = []
    for line in lines:
        sentences.extend(split_sentences(line))

    name_counts: Counter[str] = Counter()
    name_surface: Dict[str, str] = {}
    attributed: set[str] = set()
    loc_counts: Counter[str] = Counter()
    loc_surface: Dict[str, str] = {}
    time_events: List[Tuple[str, str]] = []

    for sent in sentences:
        for cand in _candidate_names(sent):
            key = normalize_name(cand)
            if not key:
                continue
            name_counts[key] += 1
            # Prefer the longest surface form seen ("Ana" -> "Ana Reyes")
            if key not in name_surface or len(cand) > len(name_surface[key]):
                name_surface[key] = cand
        for cand in _dialogue_attributions(sent):
            key = normalize_name(cand)
            if key:
                attributed.add(key)
                name_counts[key] += 2
                name_surface.setdefault(key, cand)
        for cand in _location_candidates(sent):
            key = normalize_name(cand)
            if not key:
                continue
            loc_counts[key] += 1
            if key not in loc_surface or len(cand) > len(loc_surface[key]):
                loc_surface[key] = cand
        for marker in _time_markers(sent):
            time_events.append((marker, sent[:180]))

    # Fold short forms into full names before thresholding.
    # A full name often appears once ("Ana Reyes pushed open the door")
    # while the short form carries the chapter ("Ana replied", "Ana counted").
    # Counted separately, the full name falls below threshold and is lost,
    # which then breaks drift detection and splits one person into two.
    name_counts, name_surface, attributed, alias_map = _consolidate_names(
        name_counts, name_surface, attributed
    )

    entities: List[Entity] = []

    # Locations claim a key first; a name in both buckets resolves to
    # whichever saw it more often, which keeps "Ravensbourne" out of the
    # character list when it is only ever a place.
    location_keys = {
        k for k, c in loc_counts.items()
        if c > name_counts.get(k, 0) * 0.5
    }

    for key, count in name_counts.items():
        if key in location_keys:
            continue
        if count < 2 and key not in attributed:
            continue  # single stray capital — too weak to assert
        if key in attributed:
            conf = 0.65
        elif count >= 3:
            conf = 0.50
        else:
            conf = 0.35
        entities.append(Entity(
            project_id="",  # filled by pipeline
            kind=EntityKind.CHARACTER,
            name=name_surface.get(key, key),
            aliases=sorted(alias_map.get(key, set())),
            mention_count=count,
            first_chapter=chapter_index,
            last_chapter=chapter_index,
            attributes={
                "speaks": key in attributed,
                "extraction": "rules",
            },
            provenance=Provenance(
                source="indexer_rules",
                authority=Authority.INFERENCE,
                confidence=conf,
                revision_id=revision_id,
            ),
        ))

    for key, count in loc_counts.items():
        surface = loc_surface.get(key, key)
        # A named place ("the Blackwood Hotel") is evidence on one mention.
        # A generic one ("the lobby") needs repetition before it is a place
        # worth tracking rather than incidental scenery.
        proper = surface[:1].isupper()
        if count < (1 if proper else 2):
            continue
        entities.append(Entity(
            project_id="",
            kind=EntityKind.LOCATION,
            name=surface,
            mention_count=count,
            first_chapter=chapter_index,
            last_chapter=chapter_index,
            attributes={"extraction": "rules", "named": proper},
            provenance=Provenance(
                source="indexer_rules",
                authority=Authority.INFERENCE,
                confidence=(0.50 if proper else 0.35) + (0.10 if count >= 3 else 0.0),
                revision_id=revision_id,
            ),
        ))

    seen_markers: set[str] = set()
    for marker, evidence in time_events:
        if marker in seen_markers:
            continue
        seen_markers.add(marker)
        entities.append(Entity(
            project_id="",
            kind=EntityKind.TIMELINE_EVENT,
            name=marker,
            mention_count=1,
            first_chapter=chapter_index,
            last_chapter=chapter_index,
            attributes={"evidence": evidence, "extraction": "rules"},
            provenance=Provenance(
                source="indexer_rules",
                authority=Authority.INFERENCE,
                confidence=0.40,
                revision_id=revision_id,
            ),
        ))

    logger.debug(
        "rules extraction ch%d: %d entities from %d sentences",
        chapter_index, len(entities), len(sentences),
    )
    return entities


# ──────────────────────────────────────────────────────────────────────
# TIER 2 — MODEL ENRICHMENT
# ──────────────────────────────────────────────────────────────────────

INDEXER_SYSTEM_PROMPT = (
    "You extract structured story facts from manuscript prose.\n"
    "Return ONLY a JSON object. No preamble, no markdown fences, no commentary.\n"
    "Report only what the text states or directly implies. Do not invent. "
    "If a field is unknown, omit it or use an empty list.\n"
    "Schema:\n"
    "{\n"
    '  "characters": [{"name": str, "aliases": [str], "role": str,\n'
    '                  "traits": [str], "relationships": [str], "confidence": 0..1}],\n'
    '  "locations":  [{"name": str, "description": str, "confidence": 0..1}],\n'
    '  "plot_threads":[{"name": str, "summary": str, "status": "open"|"advanced"|"resolved",\n'
    '                   "confidence": 0..1}],\n'
    '  "timeline":   [{"label": str, "summary": str, "confidence": 0..1}]\n'
    "}"
)

_MAX_CHARS_PER_PASS = 6000


def _chunk_text(text: str, limit: int = _MAX_CHARS_PER_PASS) -> List[str]:
    """Split on paragraph boundaries so a chapter fits a small context window."""
    if len(text) <= limit:
        return [text]
    chunks: List[str] = []
    current: List[str] = []
    size = 0
    for para in text.split("\n"):
        plen = len(para) + 1
        if size + plen > limit and current:
            chunks.append("\n".join(current))
            current, size = [], 0
        current.append(para)
        size += plen
    if current:
        chunks.append("\n".join(current))
    return chunks


async def extract_with_model(
    provider: InferenceProvider,
    lines: Sequence[str],
    chapter_index: int,
    *,
    revision_id: Optional[str] = None,
    known_names: Optional[Sequence[str]] = None,
) -> List[Entity]:
    """
    Model-assisted extraction. Returns [] on any failure — never raises.

    Known names are passed in so the model links to existing entities
    instead of inventing near-duplicates.
    """
    text = "\n".join(lines).strip()
    if not text:
        return []

    hint = ""
    if known_names:
        hint = (
            "\n\nCharacters already known in this manuscript (reuse these exact "
            "spellings when they appear): " + ", ".join(list(known_names)[:40])
        )

    entities: List[Entity] = []
    for chunk in _chunk_text(text):
        user = f"Chapter {chapter_index} text:\n\n{chunk}{hint}"
        try:
            raw = await provider.complete(
                INDEXER_SYSTEM_PROMPT, user, max_tokens=1400
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("indexer model call failed ch%d: %s", chapter_index, exc)
            return entities
        parsed = parse_json_object(raw)
        if not parsed:
            continue
        entities.extend(
            _entities_from_payload(parsed, chapter_index, revision_id)
        )
    return entities


def _entities_from_payload(
    payload: Dict[str, Any], chapter_index: int, revision_id: Optional[str]
) -> List[Entity]:
    out: List[Entity] = []

    def prov(conf: Any) -> Provenance:
        return Provenance(
            source="indexer_model",
            authority=Authority.INFERENCE,
            confidence=coerce_float(conf, 0.6),
            revision_id=revision_id,
        )

    for item in payload.get("characters") or []:
        if not isinstance(item, dict):
            continue
        name = (item.get("name") or "").strip()
        if not name or not normalize_name(name):
            continue
        attrs: Dict[str, Any] = {"extraction": "model"}
        if item.get("role"):
            attrs["role"] = str(item["role"])[:200]
        traits = coerce_str_list(item.get("traits"))
        if traits:
            attrs["traits"] = traits
        rels = coerce_str_list(item.get("relationships"))
        if rels:
            attrs["relationships"] = rels
        out.append(Entity(
            project_id="",
            kind=EntityKind.CHARACTER,
            name=name,
            aliases=coerce_str_list(item.get("aliases"), limit=8),
            attributes=attrs,
            mention_count=1,
            first_chapter=chapter_index,
            last_chapter=chapter_index,
            provenance=prov(item.get("confidence")),
        ))

    for item in payload.get("locations") or []:
        if not isinstance(item, dict):
            continue
        name = (item.get("name") or "").strip()
        if not name or not normalize_name(name):
            continue
        attrs = {"extraction": "model"}
        if item.get("description"):
            attrs["description"] = str(item["description"])[:400]
        out.append(Entity(
            project_id="",
            kind=EntityKind.LOCATION,
            name=name,
            attributes=attrs,
            mention_count=1,
            first_chapter=chapter_index,
            last_chapter=chapter_index,
            provenance=prov(item.get("confidence")),
        ))

    for item in payload.get("plot_threads") or []:
        if not isinstance(item, dict):
            continue
        name = (item.get("name") or "").strip()
        if not name:
            continue
        status = str(item.get("status") or "open").lower()
        if status not in {"open", "advanced", "resolved"}:
            status = "open"
        attrs = {"status": status, "extraction": "model"}
        if item.get("summary"):
            attrs["summary"] = str(item["summary"])[:600]
        out.append(Entity(
            project_id="",
            kind=EntityKind.PLOT_THREAD,
            name=name,
            attributes=attrs,
            mention_count=1,
            first_chapter=chapter_index,
            last_chapter=chapter_index,
            provenance=prov(item.get("confidence")),
        ))

    for item in payload.get("timeline") or []:
        if not isinstance(item, dict):
            continue
        label = (item.get("label") or "").strip()
        if not label:
            continue
        attrs = {"extraction": "model"}
        if item.get("summary"):
            attrs["summary"] = str(item["summary"])[:400]
        out.append(Entity(
            project_id="",
            kind=EntityKind.TIMELINE_EVENT,
            name=label,
            attributes=attrs,
            mention_count=1,
            first_chapter=chapter_index,
            last_chapter=chapter_index,
            provenance=prov(item.get("confidence")),
        ))

    return out
