"""
Manuscript intelligence pipeline.

This is the layer 2i talks to. Three operations:

    commit(...)    text in  -> intelligence updated
    generate(...)  request  -> prose out, informed by intelligence
    voice(...)     signal   -> style profile updated

Hard rules enforced here:

  1. THE HASH GATE. Unchanged chapters are never re-indexed. On a machine
     where an LLM call is the scarcest resource, this is the difference
     between a usable tool and an unusable one.

  2. COMMIT NEVER FAILS ON INTELLIGENCE. If the indexer dies, the
     continuity checker throws, or the model returns garbage, the commit
     still succeeds and reports the error. The writer's text is never
     held hostage by the intelligence layer.

  3. 2i OWNS THE MANUSCRIPT. Nothing here stores prose. It stores what
     was learned from prose. If this database is deleted, no writing is
     lost — only the learning, which can be rebuilt by re-committing.
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Dict, List, Optional, Sequence

from . import continuity as continuity_mod
from . import indexer as indexer_mod
from . import voice as voice_mod
from .hashing import hash_chapter
from .inference import InferenceProvider, NullProvider
from .models import (
    Authority,
    CommitResult,
    Entity,
    EntityKind,
    StyleProfile,
    VoiceSignal,
    VoiceSignalType,
    _new_id,
)
from .store import ManuscriptStore

logger = logging.getLogger(__name__)

MAX_CHAPTERS_PER_COMMIT = 200
MAX_LINES_PER_CHAPTER = 20000


class ManuscriptPipeline:
    """
    Orchestrates manuscript intelligence.

    `use_model_indexer` defaults to False. Rules-first is not a fallback
    here, it is the default path; the model is escalation for depth the
    rules cannot reach.
    """

    def __init__(
        self,
        store: ManuscriptStore,
        provider: Optional[InferenceProvider] = None,
        *,
        use_model_indexer: bool = False,
    ):
        self.store = store
        self.provider: InferenceProvider = provider or NullProvider()
        self.use_model_indexer = use_model_indexer
        self._project_locks: Dict[str, asyncio.Lock] = {}

    def _lock_for(self, project_id: str) -> asyncio.Lock:
        """One in-flight commit per project. Two commits racing the hash
        gate would double-index and double-flag."""
        lock = self._project_locks.get(project_id)
        if lock is None:
            lock = asyncio.Lock()
            self._project_locks[project_id] = lock
        return lock

    @property
    def model_available(self) -> bool:
        return not isinstance(self.provider, NullProvider)

    # ── COMMIT ───────────────────────────────────────────────────────

    async def commit(
        self,
        project_id: str,
        chapters: Sequence[Dict[str, Any]],
        *,
        revision_id: Optional[str] = None,
        force_reindex: bool = False,
    ) -> CommitResult:
        """
        Commit manuscript state.

        Each chapter dict: {"index": int, "title": str|None, "lines": [str]}
        """
        started = time.monotonic()
        revision_id = revision_id or _new_id("rev")
        errors: List[str] = []

        if not project_id:
            raise ValueError("project_id is required")
        if len(chapters) > MAX_CHAPTERS_PER_COMMIT:
            raise ValueError(
                f"too many chapters in one commit ({len(chapters)} > "
                f"{MAX_CHAPTERS_PER_COMMIT})"
            )

        async with self._lock_for(project_id):
            known_hashes = self.store.get_chapter_hashes(project_id)
            indexed: List[int] = []
            skipped: List[int] = []
            created = updated = 0
            flags_opened = flags_resolved = 0

            for raw in chapters:
                try:
                    ch_index = int(raw.get("index"))
                except (TypeError, ValueError):
                    errors.append(f"chapter with invalid index skipped: {raw.get('index')!r}")
                    continue

                lines = [str(l) for l in (raw.get("lines") or [])]
                if len(lines) > MAX_LINES_PER_CHAPTER:
                    errors.append(f"chapter {ch_index} truncated at {MAX_LINES_PER_CHAPTER} lines")
                    lines = lines[:MAX_LINES_PER_CHAPTER]
                title = raw.get("title")
                ch_hash = hash_chapter(lines)
                word_count = sum(len(l.split()) for l in lines)

                # ── THE HASH GATE ────────────────────────────────────
                if not force_reindex and known_hashes.get(ch_index) == ch_hash:
                    skipped.append(ch_index)
                    self.store.record_chapter(
                        project_id, ch_index, ch_hash, title=title,
                        line_count=len(lines), word_count=word_count,
                        indexed=False, revision_id=revision_id,
                    )
                    continue

                try:
                    c, u, fo, fr = await self._index_chapter(
                        project_id, ch_index, lines, revision_id
                    )
                    created += c
                    updated += u
                    flags_opened += fo
                    flags_resolved += fr
                    indexed.append(ch_index)
                    self.store.record_chapter(
                        project_id, ch_index, ch_hash, title=title,
                        line_count=len(lines), word_count=word_count,
                        indexed=True, revision_id=revision_id,
                    )
                except Exception as exc:  # noqa: BLE001
                    # Rule 2: the commit survives. Record the hash as seen
                    # but NOT indexed, so the next commit retries it.
                    logger.exception("indexing failed for chapter %d", ch_index)
                    errors.append(f"chapter {ch_index}: {type(exc).__name__}: {exc}")
                    self.store.record_chapter(
                        project_id, ch_index, "", title=title,
                        line_count=len(lines), word_count=word_count,
                        indexed=False, revision_id=revision_id,
                    )

            duration_ms = int((time.monotonic() - started) * 1000)
            result = CommitResult(
                revision_id=revision_id,
                project_id=project_id,
                chapters_received=len(chapters),
                chapters_indexed=indexed,
                chapters_skipped=skipped,
                entities_created=created,
                entities_updated=updated,
                flags_opened=flags_opened,
                flags_auto_resolved=flags_resolved,
                duration_ms=duration_ms,
                indexer_available=self.model_available,
                errors=errors,
            )
            self.store.append_ledger(
                project_id, "manuscript_committed", result.to_dict(), Authority.USER
            )
            logger.info(
                "commit %s: %d indexed, %d skipped, %dms",
                project_id, len(indexed), len(skipped), duration_ms,
            )
            return result

    async def _index_chapter(
        self,
        project_id: str,
        ch_index: int,
        lines: Sequence[str],
        revision_id: str,
    ) -> tuple[int, int, int, int]:
        known = self.store.list_entities(project_id)

        entities = indexer_mod.extract_rules(lines, ch_index, revision_id=revision_id)

        if self.use_model_indexer and self.model_available:
            known_names = [e.name for e in known if e.kind == EntityKind.CHARACTER]
            try:
                entities.extend(await indexer_mod.extract_with_model(
                    self.provider, lines, ch_index,
                    revision_id=revision_id, known_names=known_names,
                ))
            except Exception as exc:  # noqa: BLE001
                logger.warning("model indexer failed ch%d: %s", ch_index, exc)

        for e in entities:
            e.project_id = project_id

        flag_pairs = continuity_mod.check_chapter(
            project_id, ch_index, lines, entities, known,
            revision_id=revision_id,
            name_candidates=indexer_mod.scan_name_candidates(lines),
        )

        created = updated = 0
        for e in entities:
            _, was_created = self.store.upsert_entity(e)
            if was_created:
                created += 1
            else:
                updated += 1

        opened = 0
        live_fps: List[str] = []
        for flag, fp in flag_pairs:
            live_fps.append(fp)
            if self.store.open_flag(flag, fp):
                opened += 1
        resolved = self.store.resolve_flags_not_in(project_id, live_fps, ch_index)

        return created, updated, opened, resolved

    # ── INTELLIGENCE READ ────────────────────────────────────────────

    def intelligence(self, project_id: str) -> Dict[str, Any]:
        """Everything known about a project. This is what 2i caches locally."""
        by_kind: Dict[str, List[Dict[str, Any]]] = {}
        for kind in EntityKind:
            ents = self.store.list_entities(project_id, kind)
            if ents:
                by_kind[kind.value] = [e.to_dict() for e in ents]
        profile = self.store.get_style_profile(project_id)
        return {
            "project_id": project_id,
            "cache_source": "pubpartner",
            "cache_timestamp": time.time(),
            "chapters": self.store.chapter_summaries(project_id),
            "entities": by_kind,
            "flags": [f.to_dict() for f in self.store.list_flags(project_id)],
            "style_profile": profile.to_dict() if profile else None,
            "style_profile_active": bool(profile and profile.is_meaningful()),
            "stats": self.store.project_stats(project_id),
        }

    # ── VOICE ────────────────────────────────────────────────────────

    def record_voice_signal(
        self,
        project_id: str,
        signal_type: str,
        ai_text: str,
        *,
        human_text: Optional[str] = None,
        chapter_index: Optional[int] = None,
    ) -> StyleProfile:
        try:
            kind = VoiceSignalType(signal_type)
        except ValueError as exc:
            raise ValueError(
                f"unknown signal type {signal_type!r}; expected one of "
                f"{[t.value for t in VoiceSignalType]}"
            ) from exc

        self.store.add_voice_signal(VoiceSignal(
            project_id=project_id,
            signal_type=kind,
            ai_text=ai_text,
            human_text=human_text,
            chapter_index=chapter_index,
        ))
        signals = self.store.list_voice_signals(project_id)
        profile = voice_mod.build_profile(project_id, signals)
        self.store.save_style_profile(profile)
        self.store.append_ledger(
            project_id, "voice_signal",
            {"type": kind.value, "samples": profile.sample_count},
            Authority.USER,
        )
        return profile

    # ── GENERATION ───────────────────────────────────────────────────

    def build_generation_prompt(
        self,
        project_id: str,
        context_lines: Sequence[str],
        *,
        current_chapter: Optional[int] = None,
        instruction: Optional[str] = None,
        max_entities: int = 12,
    ) -> tuple[str, str]:
        """
        Build (system, user) for generation.

        This is the payoff for everything else in this package. A generic
        request says "continue this text." This one says "continue this
        text, these are the people in it, this is where they are, these
        threads are open, and this is how the writer sounds."
        """
        parts: List[str] = [
            "You are a co-writer continuing a manuscript. Match the existing "
            "prose exactly in voice, tense, and point of view.",
            "Return ONLY the new prose. No preamble, no commentary, no "
            "explanation. Put each sentence on its own line.",
        ]

        chars = self.store.list_entities(project_id, EntityKind.CHARACTER)[:max_entities]
        if chars:
            lines_out = []
            for c in chars:
                bits = [c.name]
                if c.aliases:
                    bits.append(f"(also: {', '.join(c.aliases[:3])})")
                role = c.attributes.get("role")
                if role:
                    bits.append(f"— {role}")
                traits = c.attributes.get("traits")
                if isinstance(traits, list) and traits:
                    bits.append(f"[{', '.join(traits[:4])}]")
                lines_out.append("  " + " ".join(bits))
            parts.append("Characters in this manuscript:\n" + "\n".join(lines_out))

        locs = self.store.list_entities(project_id, EntityKind.LOCATION)[:6]
        if locs:
            parts.append("Locations: " + ", ".join(l.name for l in locs))

        threads = [
            t for t in self.store.list_entities(project_id, EntityKind.PLOT_THREAD)[:8]
            if t.attributes.get("status") != "resolved"
        ]
        if threads:
            rendered = []
            for t in threads:
                summary = t.attributes.get("summary")
                rendered.append(f"  {t.name}" + (f" — {summary}" if summary else ""))
            parts.append("Open plot threads:\n" + "\n".join(rendered))

        profile = self.store.get_style_profile(project_id)
        if profile:
            guidance = voice_mod.profile_to_guidance(profile)
            if guidance:
                parts.append(guidance)

        open_flags = [
            f for f in self.store.list_flags(project_id)
            if f.chapter_index == current_chapter
        ][:3]
        if open_flags:
            parts.append(
                "Unresolved continuity notes for this chapter — do not "
                "compound these:\n"
                + "\n".join(f"  {f.message}" for f in open_flags)
            )

        system = "\n\n".join(parts)

        user_parts = ["Preceding text:\n" + "\n".join(context_lines)]
        if instruction:
            user_parts.append("Direction for what comes next: " + instruction)
        user_parts.append("Continue with the next 2-4 sentences of prose.")
        return system, "\n\n".join(user_parts)

    async def generate(
        self,
        project_id: str,
        context_lines: Sequence[str],
        *,
        current_chapter: Optional[int] = None,
        instruction: Optional[str] = None,
        max_tokens: int = 400,
    ) -> Dict[str, Any]:
        if not self.model_available:
            return {
                "ok": False,
                "lines": [],
                "error": "no inference provider configured",
                "intelligence_used": False,
            }

        system, user = self.build_generation_prompt(
            project_id, context_lines,
            current_chapter=current_chapter, instruction=instruction,
        )
        try:
            raw = await self.provider.complete(system, user, max_tokens=max_tokens)
        except Exception as exc:  # noqa: BLE001
            logger.warning("generation failed for %s: %s", project_id, exc)
            return {"ok": False, "lines": [], "error": str(exc),
                    "intelligence_used": True}

        lines = [l.strip() for l in (raw or "").split("\n")]
        lines = [l for l in lines if l and not l.startswith(("#", "```"))]

        stats = self.store.project_stats(project_id)
        return {
            "ok": bool(lines),
            "lines": lines,
            "intelligence_used": True,
            "context": {
                "entities_known": stats["entities"],
                "flags_open": stats["flags_open"],
                "style_profile_active": bool(
                    (p := self.store.get_style_profile(project_id)) and p.is_meaningful()
                ),
            },
        }
