"""
Chapter hashing.

MUST match 2i's JavaScript djb2 exactly, or every commit looks changed
and the indexer re-runs on unchanged chapters. That is the whole point
of the hash gate: LLM calls are the expensive resource on this machine.

JS reference:
    function djb2Hash(str) {
      let h = 5381;
      for (let i = 0; i < str.length; i++) {
        h = ((h << 5) + h + str.charCodeAt(i)) | 0;
      }
      return (h >>> 0).toString(36);
    }

`| 0` is a signed 32-bit truncation. `>>> 0` reinterprets as unsigned.
charCodeAt returns UTF-16 code units, so we iterate UTF-16, not codepoints.
"""
from __future__ import annotations

from typing import Iterable, List

_MASK32 = 0xFFFFFFFF
_B36 = "0123456789abcdefghijklmnopqrstuvwxyz"


def _utf16_units(s: str) -> Iterable[int]:
    """Yield UTF-16 code units, matching JS charCodeAt semantics."""
    for ch in s:
        cp = ord(ch)
        if cp < 0x10000:
            yield cp
        else:
            cp -= 0x10000
            yield 0xD800 + (cp >> 10)
            yield 0xDC00 + (cp & 0x3FF)


def _to_int32(n: int) -> int:
    n &= _MASK32
    return n - 0x100000000 if n >= 0x80000000 else n


def _to_base36(n: int) -> str:
    if n == 0:
        return "0"
    out: List[str] = []
    while n:
        n, r = divmod(n, 36)
        out.append(_B36[r])
    return "".join(reversed(out))


def djb2_hash(text: str) -> str:
    """Port of 2i's djb2Hash. Returns unsigned 32-bit value in base36."""
    h = 5381
    for unit in _utf16_units(text):
        h = _to_int32((h << 5) + h + unit)
    return _to_base36(h & _MASK32)


def hash_chapter(lines: List[str]) -> str:
    """Hash a chapter's lines. Joined with \\n, exactly as 2i does."""
    return djb2_hash("\n".join(lines))
