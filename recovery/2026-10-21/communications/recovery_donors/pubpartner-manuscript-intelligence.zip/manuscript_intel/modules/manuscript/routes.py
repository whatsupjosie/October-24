"""
FastAPI routes for manuscript intelligence.

Mount into PubPartner:

    from modules.manuscript import build_manuscript_router, ManuscriptStore, ManuscriptPipeline

    store = ManuscriptStore(Path("data/pubpartner/manuscript_intelligence.db"))
    pipeline = ManuscriptPipeline(store, provider=my_provider)
    app.include_router(build_manuscript_router(pipeline))

Endpoints:
    POST /api/pubpartner/manuscript/commit
    POST /api/pubpartner/manuscript/generate
    POST /api/pubpartner/manuscript/voice-signal
    GET  /api/pubpartner/manuscript/{project_id}/intelligence
    POST /api/pubpartner/manuscript/{project_id}/correct
    POST /api/pubpartner/manuscript/{project_id}/flags/{flag_id}/resolve
    GET  /api/pubpartner/manuscript/{project_id}/health
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from .models import EntityKind

logger = logging.getLogger(__name__)

try:
    from fastapi import APIRouter, HTTPException
    from pydantic import BaseModel, Field
    FASTAPI_AVAILABLE = True
except ImportError:  # pragma: no cover - pipeline works without the web layer
    FASTAPI_AVAILABLE = False
    APIRouter = object  # type: ignore
    BaseModel = object  # type: ignore

    def Field(*a: Any, **k: Any) -> Any:  # type: ignore
        return None

    class HTTPException(Exception):  # type: ignore
        def __init__(self, status_code: int, detail: str):
            super().__init__(detail)
            self.status_code = status_code
            self.detail = detail


if FASTAPI_AVAILABLE:

    class ChapterPayload(BaseModel):
        index: int = Field(..., description="Zero-based chapter index")
        title: Optional[str] = None
        lines: List[str] = Field(default_factory=list)

    class CommitRequest(BaseModel):
        protocol_version: int = 1
        user_id: str
        project_id: str
        revision_id: Optional[str] = None
        chapters: List[ChapterPayload] = Field(default_factory=list)
        force_reindex: bool = False
        metadata: Dict[str, Any] = Field(default_factory=dict)

    class GenerateRequest(BaseModel):
        user_id: str
        project_id: str
        context_lines: List[str] = Field(default_factory=list)
        current_chapter: Optional[int] = None
        instruction: Optional[str] = None
        max_tokens: int = 400

    class VoiceSignalRequest(BaseModel):
        user_id: str
        project_id: str
        type: str = Field(..., description="accepted | rejected | rewritten")
        ai_text: str
        human_text: Optional[str] = None
        chapter_index: Optional[int] = None

    class CorrectionRequest(BaseModel):
        user_id: str
        entity_id: str
        name: Optional[str] = None
        attributes: Dict[str, Any] = Field(default_factory=dict)

    class MergeRequest(BaseModel):
        user_id: str
        survivor_id: str
        absorbed_id: str


def build_manuscript_router(pipeline: Any, prefix: str = "/api/pubpartner/manuscript"):
    """Build the router. Raises if FastAPI is unavailable."""
    if not FASTAPI_AVAILABLE:
        raise RuntimeError(
            "FastAPI is not installed. The pipeline works standalone; "
            "install fastapi to expose HTTP endpoints."
        )

    router = APIRouter(prefix=prefix, tags=["manuscript"])

    @router.post("/commit")
    async def commit(req: CommitRequest) -> Dict[str, Any]:
        if not req.chapters:
            raise HTTPException(400, "no chapters supplied")
        try:
            result = await pipeline.commit(
                req.project_id,
                [c.model_dump() for c in req.chapters],
                revision_id=req.revision_id,
                force_reindex=req.force_reindex,
            )
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        except Exception as exc:  # noqa: BLE001
            logger.exception("commit failed")
            raise HTTPException(500, f"commit failed: {exc}") from exc
        return {"ok": True, **result.to_dict()}

    @router.post("/generate")
    async def generate(req: GenerateRequest) -> Dict[str, Any]:
        if not req.context_lines:
            raise HTTPException(400, "context_lines is required")
        return await pipeline.generate(
            req.project_id,
            req.context_lines,
            current_chapter=req.current_chapter,
            instruction=req.instruction,
            max_tokens=req.max_tokens,
        )

    @router.post("/voice-signal")
    async def voice_signal(req: VoiceSignalRequest) -> Dict[str, Any]:
        try:
            profile = pipeline.record_voice_signal(
                req.project_id,
                req.type,
                req.ai_text,
                human_text=req.human_text,
                chapter_index=req.chapter_index,
            )
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        return {
            "ok": True,
            "sample_count": profile.sample_count,
            "profile_active": profile.is_meaningful(),
            "profile": profile.to_dict(),
        }

    @router.get("/{project_id}/intelligence")
    async def intelligence(project_id: str) -> Dict[str, Any]:
        return {"ok": True, **pipeline.intelligence(project_id)}

    @router.post("/{project_id}/correct")
    async def correct(project_id: str, req: CorrectionRequest) -> Dict[str, Any]:
        entity = pipeline.store.correct_entity(
            project_id,
            req.entity_id,
            name=req.name,
            attributes=req.attributes or None,
        )
        if entity is None:
            raise HTTPException(404, f"entity {req.entity_id} not found")
        return {"ok": True, "entity": entity.to_dict()}

    @router.post("/{project_id}/merge")
    async def merge(project_id: str, req: MergeRequest) -> Dict[str, Any]:
        entity = pipeline.store.merge_entities(
            project_id, req.survivor_id, req.absorbed_id
        )
        if entity is None:
            raise HTTPException(
                400, "merge failed: ids must be two distinct live entities of the same kind"
            )
        return {"ok": True, "entity": entity.to_dict()}

    @router.post("/{project_id}/flags/{flag_id}/resolve")
    async def resolve_flag(project_id: str, flag_id: str) -> Dict[str, Any]:
        ok = pipeline.store.resolve_flag(project_id, flag_id)
        if not ok:
            raise HTTPException(404, f"open flag {flag_id} not found")
        return {"ok": True, "flag_id": flag_id}

    @router.get("/{project_id}/health")
    async def health(project_id: str) -> Dict[str, Any]:
        return {
            "ok": True,
            "project_id": project_id,
            "model_available": pipeline.model_available,
            "model_indexer_enabled": pipeline.use_model_indexer,
            "stats": pipeline.store.project_stats(project_id),
            "recent_events": pipeline.store.read_ledger(project_id, limit=20),
        }

    return router
