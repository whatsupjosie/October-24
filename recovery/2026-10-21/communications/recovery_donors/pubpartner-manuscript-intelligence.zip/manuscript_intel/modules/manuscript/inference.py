"""
Inference adapter for manuscript intelligence.

Rules from the architecture, enforced here:
  - Default is LOCAL. AI is opt-in escalation, never the hot path.
  - The pipeline must complete with NO model available. Extraction
    degrades to deterministic rules; it does not fail.
  - JSON from a model is never trusted. Parse defensively or discard.

Small models return fenced blocks, prose preambles, trailing commentary,
and single quotes. `parse_json_object` handles all of that and returns
None rather than raising, because a bad extraction must never take down
a commit.
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, List, Optional, Protocol, runtime_checkable

logger = logging.getLogger(__name__)


@runtime_checkable
class InferenceProvider(Protocol):
    """
    Minimal contract. PubPartner's InferenceManager already satisfies this
    shape; wrap anything else in a small adapter.
    """

    async def complete(
        self, system: str, user: str, *, max_tokens: int = 1024
    ) -> str: ...


class NullProvider:
    """No model available. Always returns empty; callers fall back to rules."""

    async def complete(self, system: str, user: str, *, max_tokens: int = 1024) -> str:
        return ""


class CallableProvider:
    """Wrap any async callable(system, user, max_tokens) -> str."""

    def __init__(self, fn: Any):
        self._fn = fn

    async def complete(self, system: str, user: str, *, max_tokens: int = 1024) -> str:
        try:
            result = self._fn(system=system, user=user, max_tokens=max_tokens)
            if hasattr(result, "__await__"):
                result = await result
            return str(result or "")
        except Exception as exc:  # noqa: BLE001 - inference must never crash a commit
            logger.warning("inference provider failed: %s", exc)
            return ""


_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)


def _balanced_slice(text: str, open_ch: str, close_ch: str) -> Optional[str]:
    """Extract the first balanced {...} or [...] span, ignoring braces in strings."""
    start = text.find(open_ch)
    if start < 0:
        return None
    depth = 0
    in_str = False
    escape = False
    for i in range(start, len(text)):
        c = text[i]
        if escape:
            escape = False
            continue
        if c == "\\":
            escape = True
            continue
        if c == '"':
            in_str = not in_str
            continue
        if in_str:
            continue
        if c == open_ch:
            depth += 1
        elif c == close_ch:
            depth -= 1
            if depth == 0:
                return text[start:i + 1]
    return None


def _repair(candidate: str) -> str:
    """Common small-model damage: trailing commas, smart quotes."""
    s = candidate.strip()
    s = s.replace("\u201c", '"').replace("\u201d", '"')
    s = s.replace("\u2018", "'").replace("\u2019", "'")
    s = re.sub(r",(\s*[}\]])", r"\1", s)
    return s


def parse_json_object(raw: str) -> Optional[Dict[str, Any]]:
    """Best-effort JSON object extraction. Returns None instead of raising."""
    if not raw or not raw.strip():
        return None

    candidates: List[str] = []
    fenced = _FENCE_RE.search(raw)
    if fenced:
        candidates.append(fenced.group(1))
    candidates.append(raw)
    for c in list(candidates):
        span = _balanced_slice(c, "{", "}")
        if span:
            candidates.append(span)

    for cand in candidates:
        for attempt in (cand, _repair(cand)):
            try:
                parsed = json.loads(attempt)
            except (json.JSONDecodeError, TypeError):
                continue
            if isinstance(parsed, dict):
                return parsed
            if isinstance(parsed, list):
                return {"items": parsed}
    logger.debug("could not parse JSON from model output (%d chars)", len(raw))
    return None


def coerce_str_list(value: Any, *, limit: int = 24) -> List[str]:
    """Models return strings, lists, dicts, or None where a list was asked for."""
    out: List[str] = []
    if value is None:
        return out
    if isinstance(value, str):
        parts = [p.strip() for p in re.split(r"[;\n]|,\s", value)]
        out = [p for p in parts if p]
    elif isinstance(value, (list, tuple, set)):
        for item in value:
            if isinstance(item, str) and item.strip():
                out.append(item.strip())
            elif isinstance(item, dict):
                for key in ("name", "text", "value", "title", "description"):
                    v = item.get(key)
                    if isinstance(v, str) and v.strip():
                        out.append(v.strip())
                        break
    elif isinstance(value, dict):
        for key in ("name", "text", "value", "title"):
            v = value.get(key)
            if isinstance(v, str) and v.strip():
                out.append(v.strip())
                break
    seen: set[str] = set()
    deduped: List[str] = []
    for s in out:
        k = s.lower()
        if k not in seen:
            seen.add(k)
            deduped.append(s)
    return deduped[:limit]


def coerce_float(value: Any, default: float = 0.5) -> float:
    try:
        f = float(value)
    except (TypeError, ValueError):
        return default
    return max(0.0, min(1.0, f))
