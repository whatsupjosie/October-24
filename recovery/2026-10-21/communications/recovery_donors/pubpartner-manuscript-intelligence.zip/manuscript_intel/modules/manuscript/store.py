"""
Manuscript intelligence store.

SQLite. One file. No server, no ORM, no migrations framework.
Runs on a 2015 i7 with 16GB and a spinning-rust-replacement SSD.

Design rules enforced here:
  1. Nothing is deleted. Supersede and keep the trail.
  2. Every write carries authority. Lower authority never overwrites higher.
  3. Manuscript text is NOT stored here. Only derived intelligence.
     2i owns the manuscript. This owns what was learned from it.
  4. All queries are project-scoped. Cross-project leakage is a bug.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from .models import (
    Authority,
    ContinuityFlag,
    Entity,
    EntityKind,
    FlagSeverity,
    MemoryType,
    Provenance,
    StyleProfile,
    VoiceSignal,
    VoiceSignalType,
    normalize_name,
    _now,
)

SCHEMA_VERSION = 1

_SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS schema_meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- Per-chapter hash gate. The reason we don't re-index unchanged text.
CREATE TABLE IF NOT EXISTS chapter_state (
    project_id     TEXT NOT NULL,
    chapter_index  INTEGER NOT NULL,
    chapter_hash   TEXT NOT NULL,
    title          TEXT,
    line_count     INTEGER NOT NULL DEFAULT 0,
    word_count     INTEGER NOT NULL DEFAULT 0,
    indexed_at     REAL,
    last_seen_at   REAL NOT NULL,
    revision_id    TEXT,
    PRIMARY KEY (project_id, chapter_index)
);

CREATE TABLE IF NOT EXISTS entities (
    entity_id       TEXT PRIMARY KEY,
    project_id      TEXT NOT NULL,
    kind            TEXT NOT NULL,
    name            TEXT NOT NULL,
    canonical_name  TEXT NOT NULL,
    aliases         TEXT NOT NULL DEFAULT '[]',
    attributes      TEXT NOT NULL DEFAULT '{}',
    first_chapter   INTEGER,
    last_chapter    INTEGER,
    mention_count   INTEGER NOT NULL DEFAULT 0,
    memory_type     TEXT NOT NULL DEFAULT 'creative',
    source          TEXT NOT NULL,
    authority       TEXT NOT NULL,
    confidence      REAL NOT NULL,
    created_at      REAL NOT NULL,
    updated_at      REAL NOT NULL,
    last_confirmed  REAL,
    superseded_by   TEXT,
    privacy         TEXT NOT NULL DEFAULT 'project',
    revision_id     TEXT
);
CREATE INDEX IF NOT EXISTS idx_entities_project
    ON entities(project_id, kind, superseded_by);
CREATE INDEX IF NOT EXISTS idx_entities_canon
    ON entities(project_id, kind, canonical_name);

CREATE TABLE IF NOT EXISTS continuity_flags (
    flag_id        TEXT PRIMARY KEY,
    project_id     TEXT NOT NULL,
    severity       TEXT NOT NULL,
    message        TEXT NOT NULL,
    entity_id      TEXT,
    chapter_index  INTEGER,
    line_index     INTEGER,
    evidence       TEXT NOT NULL DEFAULT '[]',
    fingerprint    TEXT NOT NULL,
    resolved       INTEGER NOT NULL DEFAULT 0,
    resolved_at    REAL,
    resolution     TEXT,
    source         TEXT NOT NULL,
    authority      TEXT NOT NULL,
    confidence     REAL NOT NULL,
    created_at     REAL NOT NULL,
    updated_at     REAL NOT NULL,
    revision_id    TEXT
);
CREATE INDEX IF NOT EXISTS idx_flags_project
    ON continuity_flags(project_id, resolved);
CREATE UNIQUE INDEX IF NOT EXISTS idx_flags_fingerprint
    ON continuity_flags(project_id, fingerprint);

CREATE TABLE IF NOT EXISTS voice_signals (
    signal_id      TEXT PRIMARY KEY,
    project_id     TEXT NOT NULL,
    signal_type    TEXT NOT NULL,
    ai_text        TEXT NOT NULL,
    human_text     TEXT,
    chapter_index  INTEGER,
    created_at     REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_voice_project
    ON voice_signals(project_id, created_at);

CREATE TABLE IF NOT EXISTS style_profiles (
    project_id  TEXT PRIMARY KEY,
    payload     TEXT NOT NULL,
    updated_at  REAL NOT NULL
);

-- Append-only. Mirrors the Event Agency ledger discipline.
CREATE TABLE IF NOT EXISTS intelligence_ledger (
    seq         INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  TEXT NOT NULL,
    event       TEXT NOT NULL,
    payload     TEXT NOT NULL,
    authority   TEXT NOT NULL,
    created_at  REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ledger_project
    ON intelligence_ledger(project_id, seq);
"""


class ManuscriptStore:
    """
    Thread-safe SQLite store for manuscript intelligence.

    A single connection guarded by a lock. FastAPI runs the endpoints in a
    threadpool; WAL plus a lock is simpler and faster here than a pool, and
    the write volume is one commit per approve-draft click.
    """

    def __init__(self, db_path: Path | str):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.executescript(_SCHEMA)
            self._conn.execute(
                "INSERT OR REPLACE INTO schema_meta(key, value) VALUES(?, ?)",
                ("schema_version", str(SCHEMA_VERSION)),
            )
            self._conn.commit()

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    # ── chapter hash gate ────────────────────────────────────────────

    def get_chapter_hashes(self, project_id: str) -> Dict[int, str]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT chapter_index, chapter_hash FROM chapter_state WHERE project_id=?",
                (project_id,),
            ).fetchall()
        return {int(r["chapter_index"]): r["chapter_hash"] for r in rows}

    def record_chapter(
        self,
        project_id: str,
        chapter_index: int,
        chapter_hash: str,
        *,
        title: Optional[str] = None,
        line_count: int = 0,
        word_count: int = 0,
        indexed: bool = False,
        revision_id: Optional[str] = None,
    ) -> None:
        now = _now()
        with self._lock:
            existing = self._conn.execute(
                "SELECT indexed_at FROM chapter_state WHERE project_id=? AND chapter_index=?",
                (project_id, chapter_index),
            ).fetchone()
            indexed_at = now if indexed else (existing["indexed_at"] if existing else None)
            self._conn.execute(
                """INSERT INTO chapter_state
                   (project_id, chapter_index, chapter_hash, title, line_count,
                    word_count, indexed_at, last_seen_at, revision_id)
                   VALUES (?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(project_id, chapter_index) DO UPDATE SET
                     chapter_hash=excluded.chapter_hash,
                     title=excluded.title,
                     line_count=excluded.line_count,
                     word_count=excluded.word_count,
                     indexed_at=excluded.indexed_at,
                     last_seen_at=excluded.last_seen_at,
                     revision_id=excluded.revision_id""",
                (project_id, chapter_index, chapter_hash, title, line_count,
                 word_count, indexed_at, now, revision_id),
            )
            self._conn.commit()

    def chapter_summaries(self, project_id: str) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                """SELECT chapter_index, chapter_hash, title, line_count, word_count,
                          indexed_at, last_seen_at
                   FROM chapter_state WHERE project_id=? ORDER BY chapter_index""",
                (project_id,),
            ).fetchall()
        return [dict(r) for r in rows]

    # ── entities ─────────────────────────────────────────────────────

    def find_entity(
        self, project_id: str, kind: EntityKind, name: str
    ) -> Optional[Entity]:
        """Match on canonical name or alias. Live records only."""
        canon = normalize_name(name)
        if not canon:
            return None
        with self._lock:
            row = self._conn.execute(
                """SELECT * FROM entities
                   WHERE project_id=? AND kind=? AND canonical_name=?
                     AND superseded_by IS NULL""",
                (project_id, kind.value, canon),
            ).fetchone()
            if row:
                return self._row_to_entity(row)
            rows = self._conn.execute(
                """SELECT * FROM entities
                   WHERE project_id=? AND kind=? AND superseded_by IS NULL""",
                (project_id, kind.value),
            ).fetchall()
        for r in rows:
            aliases = json.loads(r["aliases"])
            if any(normalize_name(a) == canon for a in aliases):
                return self._row_to_entity(r)
        return None

    def upsert_entity(self, entity: Entity) -> tuple[Entity, bool]:
        """
        Merge an observation into the store.

        Returns (entity, created). A lower-authority observation never
        overwrites a higher-authority field — it only adds aliases,
        extends chapter range, and bumps mention counts.
        """
        existing = self.find_entity(entity.project_id, entity.kind, entity.name)
        if existing is None:
            self._insert_entity(entity)
            self.append_ledger(
                entity.project_id, "entity_created",
                {"entity_id": entity.entity_id, "kind": entity.kind.value,
                 "name": entity.name},
                entity.provenance.authority,
            )
            survivor = self._absorb_alias_duplicates(entity)
            return survivor, True

        merged = self._merge_entity(existing, entity)
        self._update_entity(merged)
        survivor = self._absorb_alias_duplicates(merged)
        return survivor, False

    def _absorb_alias_duplicates(self, entity: Entity) -> Entity:
        """
        Fold separately-recorded records of the same person together.

        The indexer may create 'Ana' in chapter one and 'Ana Reyes' in
        chapter four before anything links them. Once an alias reveals
        they are the same, the weaker record is superseded into the
        stronger one — never deleted, so the trail survives.
        """
        keys = {normalize_name(a) for a in entity.aliases}
        keys.discard(entity.canonical_name)
        keys.discard("")
        if not keys:
            return entity

        for key in keys:
            with self._lock:
                row = self._conn.execute(
                    """SELECT * FROM entities
                       WHERE project_id=? AND kind=? AND canonical_name=?
                         AND superseded_by IS NULL AND entity_id != ?""",
                    (entity.project_id, entity.kind.value, key, entity.entity_id),
                ).fetchone()
            if row is None:
                continue

            other = self._row_to_entity(row)
            # The record with higher authority survives. A user-corrected
            # name is never folded into an inferred one.
            if other.provenance.authority.outranks(entity.provenance.authority):
                survivor, absorbed = other, entity
            else:
                survivor, absorbed = entity, other

            if absorbed.name not in survivor.aliases:
                survivor.aliases.append(absorbed.name)
            for alias in absorbed.aliases:
                if alias not in survivor.aliases and normalize_name(alias) != survivor.canonical_name:
                    survivor.aliases.append(alias)
            for k, v in absorbed.attributes.items():
                survivor.attributes.setdefault(k, v)
            survivor.mention_count += absorbed.mention_count
            if absorbed.first_chapter is not None:
                survivor.first_chapter = (
                    absorbed.first_chapter if survivor.first_chapter is None
                    else min(survivor.first_chapter, absorbed.first_chapter)
                )
            if absorbed.last_chapter is not None:
                survivor.last_chapter = (
                    absorbed.last_chapter if survivor.last_chapter is None
                    else max(survivor.last_chapter, absorbed.last_chapter)
                )
            survivor.provenance.confidence = max(
                survivor.provenance.confidence, absorbed.provenance.confidence
            )
            survivor.provenance.updated_at = _now()

            self._update_entity(survivor)
            with self._lock:
                self._conn.execute(
                    "UPDATE entities SET superseded_by=?, updated_at=? WHERE entity_id=?",
                    (survivor.entity_id, _now(), absorbed.entity_id),
                )
                self._conn.commit()
            self.append_ledger(
                entity.project_id, "entity_merged",
                {"survivor": survivor.entity_id, "absorbed": absorbed.entity_id,
                 "name": survivor.name},
                survivor.provenance.authority,
            )
            entity = survivor
        return entity

    def _merge_entity(self, base: Entity, incoming: Entity) -> Entity:
        incoming_wins = incoming.provenance.authority.outranks(base.provenance.authority)

        # Aliases always union — a new surface form is new information
        # regardless of who saw it.
        alias_keys = {normalize_name(a) for a in base.aliases}
        alias_keys.add(base.canonical_name)
        for a in list(incoming.aliases) + [incoming.name]:
            k = normalize_name(a)
            if k and k not in alias_keys:
                base.aliases.append(a)
                alias_keys.add(k)

        # Attributes: higher authority overwrites; equal or lower only fills gaps.
        for key, val in incoming.attributes.items():
            if val in (None, "", [], {}):
                continue
            if incoming_wins or key not in base.attributes:
                base.attributes[key] = val

        if incoming_wins:
            base.name = incoming.name
            base.canonical_name = incoming.canonical_name
            base.provenance.authority = incoming.provenance.authority
            base.provenance.source = incoming.provenance.source

        for attr in ("first_chapter",):
            iv = getattr(incoming, attr)
            bv = getattr(base, attr)
            if iv is not None:
                setattr(base, attr, iv if bv is None else min(bv, iv))
        if incoming.last_chapter is not None:
            base.last_chapter = (
                incoming.last_chapter if base.last_chapter is None
                else max(base.last_chapter, incoming.last_chapter)
            )

        base.mention_count += max(incoming.mention_count, 0)
        base.provenance.confidence = max(
            base.provenance.confidence, incoming.provenance.confidence
        )
        base.provenance.updated_at = _now()
        base.provenance.last_confirmed = _now()
        base.provenance.revision_id = (
            incoming.provenance.revision_id or base.provenance.revision_id
        )
        return base

    def correct_entity(
        self,
        project_id: str,
        entity_id: str,
        *,
        name: Optional[str] = None,
        attributes: Optional[Dict[str, Any]] = None,
        authority: Authority = Authority.USER,
        source: str = "user_correction",
    ) -> Optional[Entity]:
        """
        Apply a human correction.

        The old record is superseded, not deleted. The new record carries
        USER authority, which no future inference pass can overwrite.
        """
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM entities WHERE entity_id=? AND project_id=?",
                (entity_id, project_id),
            ).fetchone()
        if row is None:
            return None

        old = self._row_to_entity(row)
        new = Entity(
            project_id=project_id,
            kind=old.kind,
            name=name or old.name,
            aliases=list(old.aliases),
            attributes={**old.attributes, **(attributes or {})},
            first_chapter=old.first_chapter,
            last_chapter=old.last_chapter,
            mention_count=old.mention_count,
            provenance=Provenance(
                source=source,
                authority=authority,
                confidence=1.0,
                revision_id=old.provenance.revision_id,
            ),
        )
        if name and normalize_name(name) != old.canonical_name:
            if old.name not in new.aliases:
                new.aliases.append(old.name)

        self._insert_entity(new)
        with self._lock:
            self._conn.execute(
                "UPDATE entities SET superseded_by=?, updated_at=? WHERE entity_id=?",
                (new.entity_id, _now(), old.entity_id),
            )
            self._conn.commit()
        self.append_ledger(
            project_id, "entity_corrected",
            {"old": old.entity_id, "new": new.entity_id, "name": new.name},
            authority,
        )
        return new

    def merge_entities(
        self, project_id: str, survivor_id: str, absorbed_id: str
    ) -> Optional[Entity]:
        """
        Declare two records the same subject. This is a USER act.

        The absorbed record's name becomes an alias on the survivor, which
        is what stops the continuity watchdog re-raising the same question
        on every future commit.
        """
        if survivor_id == absorbed_id:
            return None
        with self._lock:
            rows = self._conn.execute(
                """SELECT * FROM entities
                   WHERE project_id=? AND entity_id IN (?,?) AND superseded_by IS NULL""",
                (project_id, survivor_id, absorbed_id),
            ).fetchall()
        if len(rows) != 2:
            return None

        by_id = {r["entity_id"]: self._row_to_entity(r) for r in rows}
        survivor, absorbed = by_id[survivor_id], by_id[absorbed_id]
        if survivor.kind is not absorbed.kind:
            return None

        for alias in [absorbed.name, *absorbed.aliases]:
            if (normalize_name(alias) != survivor.canonical_name
                    and alias not in survivor.aliases):
                survivor.aliases.append(alias)
        for k, v in absorbed.attributes.items():
            survivor.attributes.setdefault(k, v)
        survivor.mention_count += absorbed.mention_count
        if absorbed.first_chapter is not None:
            survivor.first_chapter = (
                absorbed.first_chapter if survivor.first_chapter is None
                else min(survivor.first_chapter, absorbed.first_chapter)
            )
        if absorbed.last_chapter is not None:
            survivor.last_chapter = (
                absorbed.last_chapter if survivor.last_chapter is None
                else max(survivor.last_chapter, absorbed.last_chapter)
            )
        survivor.provenance.authority = Authority.USER
        survivor.provenance.source = "user_merge"
        survivor.provenance.confidence = 1.0
        survivor.provenance.updated_at = _now()

        self._update_entity(survivor)
        with self._lock:
            self._conn.execute(
                "UPDATE entities SET superseded_by=?, updated_at=? WHERE entity_id=?",
                (survivor.entity_id, _now(), absorbed.entity_id),
            )
            self._conn.commit()
        self.append_ledger(
            project_id, "entity_merged_by_user",
            {"survivor": survivor.entity_id, "absorbed": absorbed.entity_id,
             "name": survivor.name},
            Authority.USER,
        )
        return survivor

    def list_entities(
        self,
        project_id: str,
        kind: Optional[EntityKind] = None,
        *,
        limit: int = 500,
    ) -> List[Entity]:
        sql = ("SELECT * FROM entities WHERE project_id=? AND superseded_by IS NULL")
        args: List[Any] = [project_id]
        if kind is not None:
            sql += " AND kind=?"
            args.append(kind.value)
        sql += " ORDER BY mention_count DESC, updated_at DESC LIMIT ?"
        args.append(limit)
        with self._lock:
            rows = self._conn.execute(sql, args).fetchall()
        return [self._row_to_entity(r) for r in rows]

    def _insert_entity(self, e: Entity) -> None:
        p = e.provenance
        with self._lock:
            self._conn.execute(
                """INSERT INTO entities
                   (entity_id, project_id, kind, name, canonical_name, aliases,
                    attributes, first_chapter, last_chapter, mention_count,
                    memory_type, source, authority, confidence, created_at,
                    updated_at, last_confirmed, superseded_by, privacy, revision_id)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (e.entity_id, e.project_id, e.kind.value, e.name, e.canonical_name,
                 json.dumps(e.aliases), json.dumps(e.attributes), e.first_chapter,
                 e.last_chapter, e.mention_count, MemoryType.CREATIVE.value,
                 p.source, p.authority.value, p.confidence, p.created_at,
                 p.updated_at, p.last_confirmed, p.superseded_by, p.privacy,
                 p.revision_id),
            )
            self._conn.commit()

    def _update_entity(self, e: Entity) -> None:
        p = e.provenance
        with self._lock:
            self._conn.execute(
                """UPDATE entities SET
                     name=?, canonical_name=?, aliases=?, attributes=?,
                     first_chapter=?, last_chapter=?, mention_count=?,
                     source=?, authority=?, confidence=?, updated_at=?,
                     last_confirmed=?, revision_id=?
                   WHERE entity_id=?""",
                (e.name, e.canonical_name, json.dumps(e.aliases),
                 json.dumps(e.attributes), e.first_chapter, e.last_chapter,
                 e.mention_count, p.source, p.authority.value, p.confidence,
                 p.updated_at, p.last_confirmed, p.revision_id, e.entity_id),
            )
            self._conn.commit()

    @staticmethod
    def _row_to_entity(row: sqlite3.Row) -> Entity:
        return Entity(
            entity_id=row["entity_id"],
            project_id=row["project_id"],
            kind=EntityKind(row["kind"]),
            name=row["name"],
            canonical_name=row["canonical_name"],
            aliases=json.loads(row["aliases"]),
            attributes=json.loads(row["attributes"]),
            first_chapter=row["first_chapter"],
            last_chapter=row["last_chapter"],
            mention_count=row["mention_count"],
            provenance=Provenance.from_row(dict(row)),
        )

    # ── continuity flags ─────────────────────────────────────────────

    def open_flag(self, flag: ContinuityFlag, fingerprint: str) -> bool:
        """
        Record a flag. Returns True if newly opened.

        Fingerprint dedupes: re-running the watchdog over the same text
        must not stack identical flags. If a matching flag was resolved
        and the condition recurs, it reopens.
        """
        p = flag.provenance
        with self._lock:
            row = self._conn.execute(
                "SELECT flag_id, resolved FROM continuity_flags WHERE project_id=? AND fingerprint=?",
                (flag.project_id, fingerprint),
            ).fetchone()
            if row is not None:
                if row["resolved"]:
                    self._conn.execute(
                        """UPDATE continuity_flags
                           SET resolved=0, resolved_at=NULL, resolution=NULL, updated_at=?
                           WHERE flag_id=?""",
                        (_now(), row["flag_id"]),
                    )
                    self._conn.commit()
                    return True
                return False
            self._conn.execute(
                """INSERT INTO continuity_flags
                   (flag_id, project_id, severity, message, entity_id, chapter_index,
                    line_index, evidence, fingerprint, resolved, source, authority,
                    confidence, created_at, updated_at, revision_id)
                   VALUES (?,?,?,?,?,?,?,?,?,0,?,?,?,?,?,?)""",
                (flag.flag_id, flag.project_id, flag.severity.value, flag.message,
                 flag.entity_id, flag.chapter_index, flag.line_index,
                 json.dumps(flag.evidence), fingerprint, p.source, p.authority.value,
                 p.confidence, p.created_at, p.updated_at, p.revision_id),
            )
            self._conn.commit()
        return True

    def resolve_flags_not_in(
        self, project_id: str, live_fingerprints: Sequence[str], chapter_index: int
    ) -> int:
        """
        Auto-resolve flags for a chapter whose condition no longer holds.

        Only touches inference-authored flags for the chapter just indexed.
        A flag a human opened or annotated is left alone.
        """
        with self._lock:
            rows = self._conn.execute(
                """SELECT flag_id, fingerprint FROM continuity_flags
                   WHERE project_id=? AND chapter_index=? AND resolved=0
                     AND authority IN ('inference','system')""",
                (project_id, chapter_index),
            ).fetchall()
            live = set(live_fingerprints)
            stale = [r["flag_id"] for r in rows if r["fingerprint"] not in live]
            for fid in stale:
                self._conn.execute(
                    """UPDATE continuity_flags
                       SET resolved=1, resolved_at=?, resolution='auto: condition no longer present', updated_at=?
                       WHERE flag_id=?""",
                    (_now(), _now(), fid),
                )
            if stale:
                self._conn.commit()
        return len(stale)

    def resolve_flag(
        self, project_id: str, flag_id: str, resolution: str = "resolved by user"
    ) -> bool:
        with self._lock:
            cur = self._conn.execute(
                """UPDATE continuity_flags
                   SET resolved=1, resolved_at=?, resolution=?, updated_at=?
                   WHERE flag_id=? AND project_id=? AND resolved=0""",
                (_now(), resolution, _now(), flag_id, project_id),
            )
            self._conn.commit()
        return cur.rowcount > 0

    def list_flags(
        self, project_id: str, *, include_resolved: bool = False, limit: int = 200
    ) -> List[ContinuityFlag]:
        sql = "SELECT * FROM continuity_flags WHERE project_id=?"
        args: List[Any] = [project_id]
        if not include_resolved:
            sql += " AND resolved=0"
        sql += " ORDER BY created_at DESC LIMIT ?"
        args.append(limit)
        with self._lock:
            rows = self._conn.execute(sql, args).fetchall()
        out: List[ContinuityFlag] = []
        for r in rows:
            out.append(ContinuityFlag(
                flag_id=r["flag_id"],
                project_id=r["project_id"],
                severity=FlagSeverity(r["severity"]),
                message=r["message"],
                entity_id=r["entity_id"],
                chapter_index=r["chapter_index"],
                line_index=r["line_index"],
                evidence=json.loads(r["evidence"]),
                resolved=bool(r["resolved"]),
                resolved_at=r["resolved_at"],
                resolution=r["resolution"],
                provenance=Provenance.from_row(dict(r)),
            ))
        return out

    # ── voice signals ────────────────────────────────────────────────

    def add_voice_signal(self, signal: VoiceSignal) -> None:
        with self._lock:
            self._conn.execute(
                """INSERT INTO voice_signals
                   (signal_id, project_id, signal_type, ai_text, human_text,
                    chapter_index, created_at)
                   VALUES (?,?,?,?,?,?,?)""",
                (signal.signal_id, signal.project_id, signal.signal_type.value,
                 signal.ai_text, signal.human_text, signal.chapter_index,
                 signal.created_at),
            )
            self._conn.commit()

    def list_voice_signals(
        self,
        project_id: str,
        *,
        signal_type: Optional[VoiceSignalType] = None,
        limit: int = 400,
    ) -> List[VoiceSignal]:
        sql = "SELECT * FROM voice_signals WHERE project_id=?"
        args: List[Any] = [project_id]
        if signal_type is not None:
            sql += " AND signal_type=?"
            args.append(signal_type.value)
        sql += " ORDER BY created_at DESC LIMIT ?"
        args.append(limit)
        with self._lock:
            rows = self._conn.execute(sql, args).fetchall()
        return [
            VoiceSignal(
                signal_id=r["signal_id"],
                project_id=r["project_id"],
                signal_type=VoiceSignalType(r["signal_type"]),
                ai_text=r["ai_text"],
                human_text=r["human_text"],
                chapter_index=r["chapter_index"],
                created_at=r["created_at"],
            )
            for r in rows
        ]

    # ── style profile ────────────────────────────────────────────────

    def save_style_profile(self, profile: StyleProfile) -> None:
        with self._lock:
            self._conn.execute(
                """INSERT INTO style_profiles(project_id, payload, updated_at)
                   VALUES (?,?,?)
                   ON CONFLICT(project_id) DO UPDATE SET
                     payload=excluded.payload, updated_at=excluded.updated_at""",
                (profile.project_id, json.dumps(profile.to_dict()), profile.updated_at),
            )
            self._conn.commit()

    def get_style_profile(self, project_id: str) -> Optional[StyleProfile]:
        with self._lock:
            row = self._conn.execute(
                "SELECT payload FROM style_profiles WHERE project_id=?", (project_id,)
            ).fetchone()
        if row is None:
            return None
        return StyleProfile(**json.loads(row["payload"]))

    # ── ledger ───────────────────────────────────────────────────────

    def append_ledger(
        self,
        project_id: str,
        event: str,
        payload: Dict[str, Any],
        authority: Authority = Authority.SYSTEM,
    ) -> None:
        with self._lock:
            self._conn.execute(
                """INSERT INTO intelligence_ledger
                   (project_id, event, payload, authority, created_at)
                   VALUES (?,?,?,?,?)""",
                (project_id, event, json.dumps(payload, default=str),
                 authority.value, _now()),
            )
            self._conn.commit()

    def read_ledger(self, project_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                """SELECT seq, event, payload, authority, created_at
                   FROM intelligence_ledger WHERE project_id=?
                   ORDER BY seq DESC LIMIT ?""",
                (project_id, limit),
            ).fetchall()
        return [
            {"seq": r["seq"], "event": r["event"], "payload": json.loads(r["payload"]),
             "authority": r["authority"], "created_at": r["created_at"]}
            for r in rows
        ]

    # ── health ───────────────────────────────────────────────────────

    def project_stats(self, project_id: str) -> Dict[str, Any]:
        with self._lock:
            def one(sql: str, *a: Any) -> int:
                return int(self._conn.execute(sql, a).fetchone()[0])

            return {
                "chapters": one("SELECT COUNT(*) FROM chapter_state WHERE project_id=?", project_id),
                "chapters_indexed": one(
                    "SELECT COUNT(*) FROM chapter_state WHERE project_id=? AND indexed_at IS NOT NULL",
                    project_id),
                "entities": one(
                    "SELECT COUNT(*) FROM entities WHERE project_id=? AND superseded_by IS NULL",
                    project_id),
                "entities_superseded": one(
                    "SELECT COUNT(*) FROM entities WHERE project_id=? AND superseded_by IS NOT NULL",
                    project_id),
                "flags_open": one(
                    "SELECT COUNT(*) FROM continuity_flags WHERE project_id=? AND resolved=0",
                    project_id),
                "flags_resolved": one(
                    "SELECT COUNT(*) FROM continuity_flags WHERE project_id=? AND resolved=1",
                    project_id),
                "voice_signals": one(
                    "SELECT COUNT(*) FROM voice_signals WHERE project_id=?", project_id),
                "ledger_entries": one(
                    "SELECT COUNT(*) FROM intelligence_ledger WHERE project_id=?", project_id),
            }
