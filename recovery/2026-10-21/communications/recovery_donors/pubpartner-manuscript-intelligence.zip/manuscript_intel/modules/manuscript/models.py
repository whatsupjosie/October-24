"""
Manuscript intelligence data models.

Every record carries provenance. Nothing is a bare fact.
Authority chain: user > corrected > pub_manager > inference > system.
Superseded records are never deleted.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Dict, List, Optional


# ──────────────────────────────────────────────────────────────────────
# AUTHORITY
# ──────────────────────────────────────────────────────────────────────

class Authority(str, Enum):
    """Who asserted this. Higher wins. Never silently downgrade."""
    SYSTEM = "system"
    INFERENCE = "inference"
    PUB_MANAGER = "pub_manager"
    CORRECTED = "corrected"
    USER = "user"

    @property
    def rank(self) -> int:
        return _AUTHORITY_RANK[self]

    def outranks(self, other: "Authority") -> bool:
        return self.rank > other.rank


_AUTHORITY_RANK = {
    Authority.SYSTEM: 0,
    Authority.INFERENCE: 1,
    Authority.PUB_MANAGER: 2,
    Authority.CORRECTED: 3,
    Authority.USER: 4,
}


class MemoryType(str, Enum):
    """The nine typed categories. Manuscript intelligence is CREATIVE."""
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    RELATIONAL = "relational"
    PROCEDURAL = "procedural"
    CREATIVE = "creative"
    IDENTITY = "identity"
    GOVERNANCE = "governance"
    OPERATIONAL = "operational"
    AFFECTIVE = "affective"


class EntityKind(str, Enum):
    CHARACTER = "character"
    LOCATION = "location"
    PLOT_THREAD = "plot_thread"
    TIMELINE_EVENT = "timeline_event"
    OBJECT = "object"


class FlagSeverity(str, Enum):
    """Observations, not diagnoses. Never auto-edit the manuscript."""
    NOTE = "note"
    ATTENTION = "attention"
    CONCERN = "concern"


class VoiceSignalType(str, Enum):
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    REWRITTEN = "rewritten"


def _now() -> float:
    return time.time()


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


# ──────────────────────────────────────────────────────────────────────
# PROVENANCE
# ──────────────────────────────────────────────────────────────────────

@dataclass
class Provenance:
    source: str = "indexer"
    authority: Authority = Authority.INFERENCE
    confidence: float = 0.5
    created_at: float = field(default_factory=_now)
    updated_at: float = field(default_factory=_now)
    last_confirmed: Optional[float] = None
    superseded_by: Optional[str] = None
    privacy: str = "project"
    revision_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["authority"] = self.authority.value
        return d

    @staticmethod
    def from_row(row: Dict[str, Any]) -> "Provenance":
        return Provenance(
            source=row.get("source") or "indexer",
            authority=Authority(row.get("authority") or "inference"),
            confidence=float(row.get("confidence") or 0.0),
            created_at=float(row.get("created_at") or 0.0),
            updated_at=float(row.get("updated_at") or 0.0),
            last_confirmed=row.get("last_confirmed"),
            superseded_by=row.get("superseded_by"),
            privacy=row.get("privacy") or "project",
            revision_id=row.get("revision_id"),
        )


# ──────────────────────────────────────────────────────────────────────
# ENTITIES
# ──────────────────────────────────────────────────────────────────────

@dataclass
class Entity:
    """A character, location, plot thread, timeline event, or object."""
    project_id: str
    kind: EntityKind
    name: str
    entity_id: str = field(default_factory=lambda: _new_id("ent"))
    canonical_name: str = ""
    aliases: List[str] = field(default_factory=list)
    attributes: Dict[str, Any] = field(default_factory=dict)
    first_chapter: Optional[int] = None
    last_chapter: Optional[int] = None
    mention_count: int = 0
    provenance: Provenance = field(default_factory=Provenance)

    def __post_init__(self) -> None:
        if not self.canonical_name:
            self.canonical_name = normalize_name(self.name)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "entity_id": self.entity_id,
            "project_id": self.project_id,
            "kind": self.kind.value,
            "name": self.name,
            "canonical_name": self.canonical_name,
            "aliases": list(self.aliases),
            "attributes": dict(self.attributes),
            "first_chapter": self.first_chapter,
            "last_chapter": self.last_chapter,
            "mention_count": self.mention_count,
            "provenance": self.provenance.to_dict(),
        }


@dataclass
class ContinuityFlag:
    """Something worth a human look. Never an assertion of error."""
    project_id: str
    message: str
    flag_id: str = field(default_factory=lambda: _new_id("flag"))
    severity: FlagSeverity = FlagSeverity.NOTE
    entity_id: Optional[str] = None
    chapter_index: Optional[int] = None
    line_index: Optional[int] = None
    evidence: List[str] = field(default_factory=list)
    resolved: bool = False
    resolved_at: Optional[float] = None
    resolution: Optional[str] = None
    provenance: Provenance = field(default_factory=Provenance)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "flag_id": self.flag_id,
            "project_id": self.project_id,
            "severity": self.severity.value,
            "message": self.message,
            "entity_id": self.entity_id,
            "chapter_index": self.chapter_index,
            "line_index": self.line_index,
            "evidence": list(self.evidence),
            "resolved": self.resolved,
            "resolved_at": self.resolved_at,
            "resolution": self.resolution,
            "provenance": self.provenance.to_dict(),
        }


@dataclass
class VoiceSignal:
    """One accept/reject/rewrite event. The raw material of voice training."""
    project_id: str
    signal_type: VoiceSignalType
    ai_text: str
    signal_id: str = field(default_factory=lambda: _new_id("vs"))
    human_text: Optional[str] = None
    chapter_index: Optional[int] = None
    created_at: float = field(default_factory=_now)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "signal_id": self.signal_id,
            "project_id": self.project_id,
            "type": self.signal_type.value,
            "ai_text": self.ai_text,
            "human_text": self.human_text,
            "chapter_index": self.chapter_index,
            "created_at": self.created_at,
        }


@dataclass
class StyleProfile:
    """Derived, never authored. Rebuilt from signals; safe to discard."""
    project_id: str
    sample_count: int = 0
    accepted_count: int = 0
    rejected_count: int = 0
    rewritten_count: int = 0
    mean_sentence_words: float = 0.0
    median_sentence_words: float = 0.0
    dialogue_ratio: float = 0.0
    mean_paragraph_sentences: float = 0.0
    comma_density: float = 0.0
    semicolon_density: float = 0.0
    em_dash_density: float = 0.0
    exemplars: List[str] = field(default_factory=list)
    avoid_exemplars: List[str] = field(default_factory=list)
    updated_at: float = field(default_factory=_now)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def is_meaningful(self) -> bool:
        """Below this, the profile is noise. Do not steer generation with it."""
        return self.sample_count >= 8


@dataclass
class CommitResult:
    revision_id: str
    project_id: str
    chapters_received: int
    chapters_indexed: List[int]
    chapters_skipped: List[int]
    entities_created: int
    entities_updated: int
    flags_opened: int
    flags_auto_resolved: int
    duration_ms: int
    indexer_available: bool
    errors: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ──────────────────────────────────────────────────────────────────────
# NAME NORMALIZATION
# ──────────────────────────────────────────────────────────────────────

_HONORIFICS = {
    "mr", "mrs", "ms", "miss", "dr", "doctor", "prof", "professor",
    "sir", "lady", "lord", "captain", "capt", "sgt", "sergeant",
    "detective", "det", "officer", "father", "fr", "sister", "rev",
    "reverend", "st", "saint", "aunt", "uncle", "grandma", "grandpa",
}


def normalize_name(name: str) -> str:
    """
    Fold a name to a comparison key.

    'Det. Humphrey Bogart' -> 'humphrey bogart'
    'HUMPHREY'             -> 'humphrey'

    Deliberately conservative: strips honorifics and punctuation only.
    Does NOT collapse first/last names — 'John' and 'John Smith' stay
    distinct until an alias link is made explicitly.
    """
    cleaned = "".join(c if (c.isalnum() or c.isspace()) else " " for c in name)
    parts = [p for p in cleaned.lower().split() if p]
    while parts and parts[0] in _HONORIFICS:
        parts.pop(0)
    return " ".join(parts)
