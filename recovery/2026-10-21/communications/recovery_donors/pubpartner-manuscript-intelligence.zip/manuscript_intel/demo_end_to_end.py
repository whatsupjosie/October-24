"""
End-to-end demonstration: three chapters, a correction, voice training,
and an intelligence-informed generation prompt.

    python3 demo_end_to_end.py

No network. No API key. No model. Everything below runs on rules.
"""
from __future__ import annotations

import asyncio
import tempfile
from pathlib import Path

from modules.manuscript import (
    CallableProvider,
    EntityKind,
    ManuscriptPipeline,
    ManuscriptStore,
)

CH1 = [
    "Ana Reyes pushed open the door of the Blackwood Hotel and shook the rain from her coat.",
    '"You are late," said Marcus. He did not look up from the ledger.',
    '"The bridge was out," Ana replied. "I walked."',
    "The lobby smelled of wet wool and old money. Marcus closed the ledger.",
    '"Then you will want the room at the back," he said. "It is the only one left."',
    "Ana counted the keys on the board behind him. There were seven keys.",
]

CH2 = [
    "The next morning Ana found the ledger open on the desk.",
    "Marcus was nowhere in the lobby. The rain had stopped.",
    '"He left before dawn," said the porter. "He took the road to Ravensbourne."',
    "Ana read the last entry twice. The handwriting was not Marcus handwriting.",
    "She put the ledger in her bag and went out into the grey morning.",
]

CH3 = [
    "Ravensbourne was smaller than Ana expected.",
    "The road ended at a church and the church was locked.",
    '"You are looking for Marcus," said a woman on the steps. "Everyone is."',
    "Ana showed her the ledger. The woman did not take it.",
    '"Anna Reyes," the woman said. "He wrote about you."',
]


async def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    store = ManuscriptStore(tmp / "manuscript_intelligence.db")

    async def fake_model(system: str, user: str, max_tokens: int = 400) -> str:
        return "She opened the ledger on the church step.\nThe last page was blank."

    pipeline = ManuscriptPipeline(store, provider=CallableProvider(fake_model))
    project = "the_blackwood_ledger"

    print("=" * 70)
    print("PUBCAST 2i — MANUSCRIPT INTELLIGENCE — END TO END")
    print("=" * 70)

    # ── 1. first commit ──────────────────────────────────────────────
    print("\n[1] Writer commits chapters one and two")
    r = await pipeline.commit(project, [
        {"index": 0, "title": "The Hotel", "lines": CH1},
        {"index": 1, "title": "The Ledger", "lines": CH2},
    ])
    print(f"    indexed {r.chapters_indexed}  entities +{r.entities_created}  "
          f"flags {r.flags_opened}  {r.duration_ms}ms")

    # ── 2. hash gate ─────────────────────────────────────────────────
    print("\n[2] Writer saves again without changing anything")
    r = await pipeline.commit(project, [
        {"index": 0, "title": "The Hotel", "lines": CH1},
        {"index": 1, "title": "The Ledger", "lines": CH2},
    ])
    print(f"    skipped {r.chapters_skipped}  indexed {r.chapters_indexed}  "
          f"{r.duration_ms}ms   <- no model calls, nothing re-read")

    # ── 3. what it learned ───────────────────────────────────────────
    print("\n[3] What the manuscript taught it, with no model involved")
    for kind in (EntityKind.CHARACTER, EntityKind.LOCATION, EntityKind.TIMELINE_EVENT):
        ents = store.list_entities(project, kind)
        if not ents:
            continue
        print(f"    {kind.value}:")
        for e in ents[:6]:
            alias = f" (aka {', '.join(e.aliases)})" if e.aliases else ""
            print(f"      {e.name}{alias}   x{e.mention_count}  "
                  f"conf {e.provenance.confidence:.2f}  [{e.provenance.authority.value}]")

    # ── 4. correction ────────────────────────────────────────────────
    print("\n[4] Writer corrects the record")
    marcus = next(e for e in store.list_entities(project, EntityKind.CHARACTER)
                  if "Marcus" in e.name)
    corrected = store.correct_entity(
        project, marcus.entity_id,
        name="Marcus Vane",
        attributes={"role": "hotel clerk", "occupation": "keeper of the ledger"},
    )
    print(f"    {marcus.name} -> {corrected.name}  "
          f"[{corrected.provenance.authority.value}]  aliases {corrected.aliases}")

    # ── 5. correction survives re-indexing ───────────────────────────
    print("\n[5] Re-index everything and check the correction held")
    await pipeline.commit(project, [
        {"index": 0, "title": "The Hotel", "lines": CH1},
        {"index": 1, "title": "The Ledger", "lines": CH2},
    ], force_reindex=True)
    after = next(e for e in store.list_entities(project, EntityKind.CHARACTER)
                 if e.entity_id == corrected.entity_id)
    print(f"    {after.name}  role={after.attributes.get('role')!r}  "
          f"[{after.provenance.authority.value}]   <- inference did not overwrite it")

    # ── 6. continuity ────────────────────────────────────────────────
    print("\n[6] Writer adds chapter three")
    r = await pipeline.commit(project, [{"index": 2, "title": "Ravensbourne", "lines": CH3}])
    print(f"    indexed {r.chapters_indexed}  flags opened {r.flags_opened}")
    for f in store.list_flags(project):
        print(f"      [{f.severity.value}] {f.message}")

    # ── 7. voice ─────────────────────────────────────────────────────
    print("\n[7] Voice training from accept / reject / rewrite")
    for i in range(7):
        pipeline.record_voice_signal(
            project, "accepted",
            f"She went out. The street was empty. Nothing moved on it, {i}.")
    pipeline.record_voice_signal(
        project, "rejected",
        "It was a dark and stormy night, and the wind howled interminably "
        "through the ancient and crumbling eaves of the forgotten manor.")
    profile = pipeline.record_voice_signal(
        project, "rewritten",
        ai_text="Ana, experiencing a profound and overwhelming sense of melancholy, "
                "ventured forth into the inclement weather.",
        human_text="Ana went out. It was cold.")
    print(f"    samples {profile.sample_count}  "
          f"mean sentence {profile.mean_sentence_words} words  "
          f"active={profile.is_meaningful()}")

    # ── 8. the payoff ────────────────────────────────────────────────
    print("\n[8] The generation prompt this produces")
    system, user = pipeline.build_generation_prompt(
        project, CH3[-2:], current_chapter=2,
        instruction="Ana opens the ledger on the church steps.")
    print("    " + "-" * 62)
    for line in system.split("\n"):
        print("    | " + line)
    print("    " + "-" * 62)

    out = await pipeline.generate(project, CH3[-2:], current_chapter=2)
    print(f"\n    generated: {out['lines']}")
    print(f"    context:   {out['context']}")

    # ── 9. health ────────────────────────────────────────────────────
    print("\n[9] Cartridge health")
    for k, v in store.project_stats(project).items():
        print(f"    {k:24} {v}")

    print("\n[10] Audit trail (most recent first)")
    for ev in store.read_ledger(project, limit=6):
        print(f"    #{ev['seq']:<3} {ev['event']:<24} [{ev['authority']}]")

    db = tmp / "manuscript_intelligence.db"
    print(f"\n    database: {db.stat().st_size / 1024:.1f} KB for a three-chapter manuscript")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
