# PubCast Menu Work — GitHub Recovery Inventory

Recovered 2026-10-18 for Josie Curtsey Cobbley. These are copies of existing
repository files, **not** rewritten or merged menu implementations. Original
files remain unchanged. The source repositories were inspected read-only.

## Start here

1. `breaking_dawn/foresight.html` — the clearest implemented dynamic fan/tray menu: each
   open tray gets a blade; a permanent blank blade opens the program picker.
   Supports focus, hide, close, drag, resize, and browser-local layout restoration.
   Program surfaces require the separately running PubCast routes and services.
2. `breaking_dawn/FORESIGHT_ENGINEERING_HANDOFF_2026-08-19.md` — the more detailed
   authoritative *design intent*, including important refinements not all in code.
3. `prime_assembled_archive/foresight/foresight_ui_v18.html` — the elaborate
   polygonal/Art Deco Foresight workspace from the Prime `assembled-pubcast`
   branch archive. The included Python files implement shape contracts and tray
   fitting experiments.
4. `prime_main/foresight_ui_v17.html` — earlier standalone Counter with an
   expanding system fan, modal menu categories, editable visual settings,
   lighting interface, and freeform tray mechanics.
5. `prime_assembled_archive/2i/index.html` and
   `prime_main/21 with backend MVP 8-12-26 930.html` — Writer's Room menus.

## What is actually present

| Location | Menu work | Important limitations |
| --- | --- | --- |
| Prime `main`, `foresight_ui_v17.html` | System fan blades for File, Edit, Help, Connection, Settings, Light, Pub Partner, GoLab, Interaction, PubClass, Trays; settings modal, tray manager, appearance/material choices; freeform draggable/resizable trays | Several buttons only show a notification, file picker has example entries, and internal `renderMenu()` is empty. This is not a fully wired product menu. |
| Prime `assembled-pubcast` ZIP, Foresight v18 | Polygon styling and tray show/hide launcher layered onto v17; shape library, tray fitting and Python tests | Work-in-progress and distinct from the later Aug. 19 fan-as-open-tray spec; verify integration before adopting as canonical. |
| Breaking Dawn `foresight.html` | Working code for dynamic open-tray blades, blank blade, program picker, per-tray focus/hide/close, local storage, drag/resize, simple service status | Does not yet implement the complete Silver System Bar, carousel/multiple countertops, robotic arm, or Chat Slot design; the PubPartner/2i surfaces are health/status only. |
| The Counter and 2i, `2i_writers_room_v12 (1).html` | Manuscript hamburger/rail menu for chat/reference/co-write, file, locking, chapters, generation, export and provider settings | Standalone historical editor variant; not proof of current Reach integration. |
| Prime `21 with backend MVP...html` | Writer's Room hamburger and contextual edit menu, LLM settings and keyboard help | Source snapshot; backend functions require their intended service. |
| Prime `bar.js` + `bar.html` | Overlay interaction menus for bartender, gaming tables, seating and stage | Depends on PubWorld assets and game/room integrations. |
| Prime `index.html` + `app.js` + `styles.css` | Standard room navigation across Dressing, Green Room, Studio, Control, Conference and Pub | Older PubCast UI, not the Foresight design. |
| NowCurtsey Spark assignment | Explicit inventory/hardening test plan for menus, controls, tabs, keyboard navigation and window behavior | Task specification and JSX donor snapshot, not proof that the tests or repairs were completed. |

## Critical design decision: don't confuse the two menu layers

The August 19 handoff distinguishes:

- **Silver System Bar:** conventional File/Edit/settings menus.
- **Fan Menu:** represents **open trays**, not generic system commands. One blank
  blade must always remain to open another file/program; each opened tray gets
  its own labeled blade. The hub manages fan visibility and, eventually,
  multi-countertop selection.

It also specifies an upper-left Lantern, robotic arm, and Foresight Chat Slot;
multiple flat rotating countertops; separate low-stakes individual-tray close
and deliberately gated entire-countertop close. Earlier Prime v17's system
fan puts File/Edit/etc. on blades and should **not** silently supersede the
later explicit distinction.

## Source provenance

- `whatsupjosie/The-Prime` `main` @ `ecf01ba0918acaefa6055d0a5cbe22135732e167`
  (2026-08-15): https://github.com/whatsupjosie/The-Prime
- `whatsupjosie/The-Prime` `assembled-pubcast` @
  `a02b740d6af1d6110b8e1f9def6f0cb770dea86e` (2026-08-15):
  https://github.com/whatsupjosie/The-Prime/tree/assembled-pubcast
- `whatsupjosie/Pubcaast-Breaking-Dawn` `main` @
  `302e348` (2026-08-19): https://github.com/whatsupjosie/Pubcaast-Breaking-Dawn
- `whatsupjosie/The-Counter-and-2i` `main` @
  `28790a9` (2026-08-12): https://github.com/whatsupjosie/The-Counter-and-2i
- `whatsupjosie/NowCurtsey-Build` `Spark-Assignment` @
  `6969ffa8325462973ea6a3bdb20d0a3e1eafe457` (2026-09-29):
  https://github.com/whatsupjosie/NowCurtsey-Build/tree/Spark-Assignment
- `whatsupjosie/NowCurtsey-Build` `main` @ `5966eff` (2026-08-31):
  https://github.com/whatsupjosie/NowCurtsey-Build

`whatsupjosie/Pubcast-Reach` was also inspected. Its visible material largely
contains planning documents/archive references, not a later directly checked-in
Foresight menu implementation. This inventory covers GitHub material only;
later September/October local or ZIP builds may supersede these sources.

## Verification in this recovery

- Inspected source and branch trees; copied the actual repository files.
- Confirmed the assembled Prime archive contains Foresight v17/v18, a 2i
  editor/backend, polygon tray engine, layout data and tests.
- Ran Python shape tests from that archive: **23 passed**. Two additional
  test modules could not import because the supplied test environment lacks
  `fastapi` and `control_room_server`; they were **not** counted as passing.
- No live PubCast service or browser end-to-end test was run. Functionality
  above describes source-level implementation, not a claim of deployment.

## Archive layout

- `prime_main/` — selected menu/navigation files from Prime main.
- `prime_assembled_archive/` — extracted source from `foresight_and_2i_committed.zip`.
- `prime_assembled_branch_assets/` — original integrated ZIP, git patch/bundle,
  and menu/tray visual reference images.
- `breaking_dawn/` — dynamic Foresight tray menu and engineering handoff.
- `counter_and_2i/` — historical writer's-room menu prototypes/variants.
- `nowcurtsey_spark/` — original Spark UI hardening packet.
- `integration_reference/` — PubCast/PubPartner/2i/Foresight architecture plan.

No files in this package were uploaded or pushed back to GitHub.
