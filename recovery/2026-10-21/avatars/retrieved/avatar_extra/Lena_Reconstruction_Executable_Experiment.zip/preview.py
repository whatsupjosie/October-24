from pathlib import Path
import numpy as np, trimesh, cv2
p=Path(__file__).resolve().parent
m=trimesh.load(p/'Lena_VisualHull_Experimental.glb',force='mesh')
v=m.vertices;faces=m.faces;colors=np.asarray(m.visual.vertex_colors)[:,:3]
for degrees in (0,45,90):
    theta=np.deg2rad(degrees)
    x=v[:,0]*np.cos(theta)+v[:,2]*np.sin(theta)
    depth=-v[:,0]*np.sin(theta)+v[:,2]*np.cos(theta)
    y=v[:,1]
    px=((x+1.2)*230).astype(np.int32);py=((2-y)*230).astype(np.int32)
    canvas=np.full((930,570,3),244,dtype=np.uint8)
    order=np.argsort(depth[faces].mean(axis=1))
    for fi in order:
        f=faces[fi];pts=np.stack([px[f],py[f]],axis=1)
        if np.any(pts[:,0]<-50) or np.any(pts[:,0]>620) or np.any(pts[:,1]<-50) or np.any(pts[:,1]>980):continue
        col=colors[f].mean(axis=0).astype(np.uint8)
        cv2.fillConvexPoly(canvas,pts,col.tolist(),lineType=cv2.LINE_AA)
    cv2.imwrite(str(p/f'preview_{degrees}.png'),cv2.cvtColor(canvas,cv2.COLOR_RGB2BGR))
