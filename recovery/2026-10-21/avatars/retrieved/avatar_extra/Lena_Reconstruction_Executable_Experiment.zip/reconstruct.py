"""Offline, reproducible two-view silhouette visual-hull reconstruction.
Not a learned 3D model: incompatible silhouettes or occluded limbs are not inferred.
"""
from pathlib import Path
import argparse, json
import numpy as np
from PIL import Image
from scipy.ndimage import binary_fill_holes, binary_closing, label, gaussian_filter
from skimage.measure import marching_cubes
import trimesh

ROOT=Path(__file__).resolve().parent

def load_view(path, size=(320,640)):
    im=Image.open(path).convert('RGB').resize(size,Image.Resampling.LANCZOS)
    a=np.asarray(im).astype(np.float32)/255
    # off-white background; preserve pale skin/pink hair with color distance
    background=np.median(np.concatenate([a[:35,:35].reshape(-1,3),a[:35,-35:].reshape(-1,3),a[-35:,:35].reshape(-1,3),a[-35:,-35:].reshape(-1,3)]),axis=0)
    dist=np.linalg.norm(a-background,axis=2)
    mask=(dist>0.19)&(np.min(a,axis=2)<0.94)
    mask=binary_closing(mask,iterations=2)
    labs,n=label(mask)
    if n:
        counts=np.bincount(labs.ravel());counts[0]=0
        # keep components >= 0.3% of largest (feet can disconnect)
        mask=np.isin(labs,np.where(counts>max(counts)*0.003)[0])
    mask=binary_fill_holes(mask)
    return a,mask

def reconstruct(front_path,side_path,out):
    front,fmask=load_view(front_path)
    side,smask=load_view(side_path)
    # orthographic visual hull: frontal x-y and profile z-y silhouettes
    # align image top/bottom, x-centered, with side view's nose at image right
    ny,nx,nz=256,124,96
    yf=np.linspace(0,639,ny).astype(int)
    xf=np.linspace(0,319,nx).astype(int)
    zs=np.linspace(0,319,nz).astype(int)
    front_sample=fmask[yf[:,None],xf[None,:]]
    side_sample=smask[yf[:,None],zs[None,:]]
    vox=front_sample[:,:,None]&side_sample[:,None,:]
    # smooth slight pixel staircase, not a morphological fake of missing body
    density=gaussian_filter(vox.astype(np.float32),sigma=(0.85,0.8,0.8))
    verts,faces,_,_=marching_cubes(density,level=0.48)
    # vertex order y, x, z; world coords +Y up, front faces +Z
    yy=verts[:,0];xx=verts[:,1];zz=verts[:,2]
    world=np.column_stack(((xx/(nx-1)-.5)*1.9,(.5-yy/(ny-1))*3.8,(zz/(nz-1)-.5)*1.05))
    # sample RGB from actual views; use side image for +/-X-facing surfaces
    # front-facing vertices get front reference, rear is a neutral back projection
    iy=np.clip(np.rint(yy/(ny-1)*639).astype(int),0,639)
    ix=np.clip(np.rint(xx/(nx-1)*319).astype(int),0,319)
    iz=np.clip(np.rint(zz/(nz-1)*319).astype(int),0,319)
    # front image for main view; side reference for profile. Vertex colors for portability.
    fcol=front[iy,ix];scol=side[iy,iz]
    mesh=trimesh.Trimesh(vertices=world,faces=faces,process=False)
    normals=mesh.vertex_normals
    side_weight=np.clip((np.abs(normals[:,0])-.25)/.5,0,1)*.82
    back_weight=np.clip((-normals[:,2]-.15)/.65,0,1)
    # Back has no registered T-pose back reference: use softened front projection.
    rgb=fcol*(1-side_weight[:,None])+scol*side_weight[:,None]
    rgb=rgb*(1-.14*back_weight[:,None])
    mesh.visual.vertex_colors=np.column_stack((np.clip(rgb*255,0,255).astype('uint8'),np.full(len(rgb),255,dtype='uint8')))
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    mesh.export(out)
    result={'vertices':len(mesh.vertices),'faces':len(mesh.faces),'watertight':bool(mesh.is_watertight),'components':len(mesh.split(only_watertight=False)),'bounds':mesh.bounds.tolist(),'front_mask_pixels':int(fmask.sum()),'side_mask_pixels':int(smask.sum()),'method':'two-view silhouette visual hull, vertex colors projected from original art','limitation':'static mesh; not Lena likeness verified; inconsistent poses and hidden geometry not recoverable'}
    (out.parent/'RECONSTRUCTION_RESULT.json').write_text(json.dumps(result,indent=2))
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--front',default=str(ROOT/'inputs/front.png'));p.add_argument('--side',default=str(ROOT/'inputs/left.png'));p.add_argument('--output',default=str(ROOT/'Lena_VisualHull_Experimental.glb'));a=p.parse_args()
    print(json.dumps(reconstruct(a.front,a.side,a.output),indent=2))
