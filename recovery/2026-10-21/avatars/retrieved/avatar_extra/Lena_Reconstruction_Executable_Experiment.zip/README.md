# Lena two-view reconstruction experiment

This is an executable, source-included **offline visual-hull reconstructor**. It segments the supplied front and profile reference images, intersects their silhouettes in a 3D voxel volume, extracts a watertight mesh with marching cubes, projects colors from the reference images, and writes a GLB. It also renders 0°, 45°, and 90° inspection images.

## Run

`python reconstruct.py --front inputs/front.png --side inputs/left.png --output Lena_VisualHull_Experimental.glb`

`python preview.py`

Python requirements: `numpy`, `Pillow`, `scipy`, `scikit-image`, `trimesh`, `opencv-python`.

## Actual result / quality gate

The executable ran, exported a GLB, and generated the preview images. It is **not** a successful Lena character model. The original front and side images use different arm poses, and projecting colors from orthographic views onto an intersected silhouette produces doubled faces, striped clothes, and distorted limbs at three-quarter angles. A visual hull cannot recover hidden anatomy or a consistent rig from these inputs alone. No skinning or animation is claimed. The 45° preview is included to expose the failure, not disguise it.

A true multi-view character reconstruction requires pose registration and surface/texture optimization or a trained multi-view reconstruction model; this implementation is an honest baseline and test harness, not a substitute for those stages.
