# Open questions (not ingested; production notes, not in-world lore)

Everything in `working_draft.json` is **not canon**. Curtsey is still solidifying it. Where it disagrees with
`starter_canon.json`, both are kept and nothing has been resolved.

* **Studio name is undecided.** Candidates: "Sensual Pleasures" (his own mistake: he means it pleases the
  senses; people hear "sexy"), "Bella Faux Pas" (the little mistake), or Rear View Foresight (the monument exists).
* **Studio history conflict.** Canon `canon_003` (older repo canon): vaudeville theatre, then grindhouse and
  adult theatre. Draft: classics in its heyday, then porn only after Purfluous took over. Both kept.
* **Pete.** Canon `canon_004`: old friend and near family, taught set craft by Purfluous. Draft: "that's how
  we met Pete" through the porn shoots. Compatible only if "we" means the audience. Unresolved.
* **Horace.** Only known so far: met through the porn shoots, alongside Pete.
