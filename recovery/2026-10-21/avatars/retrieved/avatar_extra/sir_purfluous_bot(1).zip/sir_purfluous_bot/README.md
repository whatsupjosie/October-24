# Sir Purfluous — offline character + director bot

Standard-library only (Python 3.10+). No LLM. No background monitor: **Nudge owns conversational
initiation**, and this bot only ever answers when spoken to. Director output is a *proposal*
(`executed: False`), never an action.

## What it does

**Lore (grounded).** Answers questions about the character from the ingested canon (SQLite FTS5) and
cites the source of every answer. If the canon doesn't have it, it says so instead of inventing.

**Director (rule-based).** Reads what a person types and picks one move:

| Move | When | What he does |
|------|------|--------------|
| QUESTION | default; stuck; self-discovery | One question at a time, never repeating until a pool is used up |
| NOTE | tone problems (too hot / flat / racing), "too much", craft topics | One actionable correction |
| TELL | direct ask, out of time, or stuck after two questions | Stops asking; plain, decisive |
| DEMO | "show me", or a note didn't land | Gets up, takes the opposite chair, re-delivers *your* quoted line (slowed / underplayed / stressed) |

Every reply carries `register` (`theatrical`, `plain`, `whisper`) and a `cue` stage direction, so a human
performer or a TTS layer can act it: sing-song and self-announcing by default; the accent drops for blunt
moments; a shouting whisper for the confiding ones. After a plain beat he snaps back up into the theatre.

## Running

```bash
python sir_purfluous_bot.py talk                       # interactive; remembers what it asked, so it can escalate
python sir_purfluous_bot.py chat "What do you know about Pete?"
python sir_purfluous_bot.py director "I played \"I told you never to come back here!\" and it was angry"
python sir_purfluous_bot.py search "Peter O'Toole"
python sir_purfluous_bot.py chat --draft "What do you know about the squatter?"   # includes uncanonized drafts
python -m unittest                                      # 49 tests
```
One-shot commands start a fresh session each time, so escalation (question → question → tell) only shows
in `talk` mode or when `PurfluousBot` is embedded and kept alive.

## Honest limits

* It matches **words**, not meaning. A person who says it differently than the patterns expect gets the
  default question instead of a read. It is a decision skeleton, not understanding.
* **DEMO cannot improvise the other half of a scene.** It stages the chair swap and re-delivers your own
  line with beats; it does not write the opposite role's lines.
* **TELL has no domain knowledge.** It gives a decisive process directive ("pick one, commit, adjust"),
  not the right answer to your problem.
* It will not tell anyone who they are; self-discovery stays a whispered question.
* Plain register is blunt but not profane. Add that in your own voice if you want it.
* No Career Dreamer flow yet (opening note, role paragraph, three numbered first-person topics).
* **Canon vs draft.** `lore/starter_canon.json` is the older repo canon, unchanged (15 entries). Your new backstory (name, squatter/tax story, failures to porn, Horace and Pete) lives in `lore/working_draft.json` as **drafts, not canon**: off by default, loaded with `--draft`, and always answered as "Working draft, not canon yet:". Where the two disagree both are kept and nothing is resolved. Your raw words are in `lore/dictation_raw.md` (never ingested); open questions are in `lore/OPEN_QUESTIONS.md`.
  points at GitHub repos this build could not check. Ingest your own canon with `PurfluousBot.ingest(path)`.
* Real improvisation, reading tone from meaning, and playing the opposite role need an LLM behind this,
  with the character file as its system prompt and this module as the move-selection guardrail.
