"""Offline Sir Purfluous: grounded character lore plus a rule-based director. Python 3.10+; stdlib only."""
from __future__ import annotations

import argparse
import hashlib
import json
import random
import re
import sqlite3
import time
from pathlib import Path

from director import DIRECTOR, Director, read_person  # DIRECTOR re-exported for compatibility

SCHEMA = """
CREATE TABLE IF NOT EXISTS knowledge (
 id TEXT PRIMARY KEY, kind TEXT NOT NULL, title TEXT NOT NULL,
 text TEXT NOT NULL, source TEXT NOT NULL, signature TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS knowledge_kind ON knowledge(kind);
CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_fts USING fts5(
 title, text, content='knowledge', content_rowid='rowid', tokenize='unicode61');
CREATE TRIGGER IF NOT EXISTS knowledge_ai AFTER INSERT ON knowledge BEGIN
 INSERT INTO knowledge_fts(rowid,title,text) VALUES(new.rowid,new.title,new.text);
END;
CREATE TRIGGER IF NOT EXISTS knowledge_ad AFTER DELETE ON knowledge BEGIN
 INSERT INTO knowledge_fts(knowledge_fts,rowid,title,text) VALUES('delete',old.rowid,old.title,old.text);
END;
CREATE TRIGGER IF NOT EXISTS knowledge_au AFTER UPDATE ON knowledge BEGIN
 INSERT INTO knowledge_fts(knowledge_fts,rowid,title,text) VALUES('delete',old.rowid,old.title,old.text);
 INSERT INTO knowledge_fts(rowid,title,text) VALUES(new.rowid,new.title,new.text);
END;
"""
WELCOME = "Ah, Sancho! The theatre is open, the budget is not, and somehow we must make art. What have you brought me?"
NO_RESULT = "Sancho, that particular reel is not in my archive. I won't invent a fact merely to improve the lighting."
GREETING = re.compile(r"^\s*(hi|hello|hey|greetings|good (morning|afternoon|evening))\b", re.I)
LORE_INTENT = re.compile(
    r"\b(who is|who'?s|what do you know|tell me about|do you know|the story of|the tale of|remember when)\b", re.I)
STOPWORDS = frozenset(
    "a an the and or of to in on at is are was were be it its i me my you your we do does did what who how about "
    "tell know that this for with but so as by from can could would should will just too not no if then there here "
    "have has had im am".split())


class PurfluousBot:
    def __init__(self, db=':memory:', seed=None):
        self.conn = sqlite3.connect(str(db))
        self.conn.executescript(SCHEMA)
        self.rng = random.Random(seed)
        self.director = Director(seed)
        self.last_id = None
        self.history = []

    def close(self):
        self.conn.close()

    # ---- ingest (unchanged behaviour) -------------------------------------------------
    def ingest(self, path):
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(path)
        total = 0
        paths = sorted(x for x in p.rglob('*') if x.is_file() and x.suffix.lower() in {'.json', '.md', '.txt', '.py'}) if p.is_dir() else [p]
        for f in paths:
            if f.stat().st_size > 3_000_000:
                continue
            if f.suffix.lower() == '.json':
                try:
                    obj = json.loads(f.read_text(encoding='utf-8-sig'))
                    if isinstance(obj, list) and all(isinstance(x, dict) and {'title', 'text'} <= x.keys() for x in obj):
                        for i, x in enumerate(obj):
                            self._add(x.get('id') or f'{f}:{i}', x.get('kind', 'lore'), x['title'], x['text'], x.get('source', str(f)))
                            total += 1
                        continue
                except (ValueError, UnicodeError):
                    pass
            try:
                data = f.read_text(encoding='utf-8-sig')
            except (UnicodeError, OSError):
                continue
            # Bounded sections: preserve code, comments and their actual provenance.
            chunks = re.split(r'(?m)^(?=class |def |#{3,}|## |\[.+\])', data)
            if len(chunks) == 1:
                chunks = [data[i:i + 1800] for i in range(0, len(data), 1800)]
            for i, chunk in enumerate(chunks):
                if not chunk.strip():
                    continue
                for j in range(0, len(chunk), 1800):
                    part = chunk[j:j + 1800]
                    title = next((v.strip(' #[]\t')[:150] for v in part.splitlines() if v.strip()), f.name)
                    self._add(f'{f}:{i}:{j}', f.suffix[1:], title, part, str(f))
                    total += 1
        self.conn.commit()
        return total

    def _add(self, id, kind, title, body, source):
        uid = hashlib.sha256(str(id).encode()).hexdigest()
        body = str(body)[:10000]
        signature = hashlib.sha256(body.encode()).hexdigest()
        self.conn.execute("""INSERT INTO knowledge(id,kind,title,text,source,signature)
            VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
            kind=excluded.kind,title=excluded.title,text=excluded.text,source=excluded.source,signature=excluded.signature""",
                          (uid, str(kind), str(title), body, str(source), signature))

    # ---- retrieval --------------------------------------------------------------------
    @staticmethod
    def _tokens(q):
        found = re.findall(r'[^\W_]+', (q or '').lower(), flags=re.UNICODE)
        return [t for t in found if len(t) >= 2 and t not in STOPWORDS][:16]

    def search(self, q, limit=5, kinds=None):
        tokens = self._tokens(q)
        if not tokens:
            return []
        match = ' OR '.join('"' + t.replace('"', '') + '"' for t in tokens)
        sql = """SELECT k.id,k.kind,k.title,k.text,k.source,bm25(knowledge_fts,4.0,1.0) AS score
                 FROM knowledge_fts JOIN knowledge k ON k.rowid=knowledge_fts.rowid WHERE knowledge_fts MATCH ?"""
        args = [match]
        if kinds:
            sql += ' AND k.kind IN (' + ','.join('?' for _ in kinds) + ')'
            args += list(kinds)
        sql += ' ORDER BY score ASC,k.id ASC LIMIT ?'
        args.append(max(1, min(int(limit), 30)))
        return [dict(zip(['id', 'kind', 'title', 'text', 'source', 'score'], row)) for row in self.conn.execute(sql, args)]

    # ---- responses --------------------------------------------------------------------
    @staticmethod
    def _packet(text, mode, move, register='theatrical', cue=None, proposal=None, sources=None, demo=None, reason=None):
        return {'speaker': 'Sir Purfluous', 'text': text, 'mode': mode, 'move': move, 'reason': reason,
                'register': register, 'cue': cue, 'proposal': proposal, 'demo': demo, 'sources': sources or []}

    def _direct(self, message, mode):
        out = self.director.respond(message)
        return self._packet(out['text'], mode, out['move'], out['register'], out['cue'], out['proposal'],
                            demo=out['demo'], reason=out['reason'])

    def _lore(self, matches, message, mode):
        candidate = next((m for m in matches if m['id'] != self.last_id), matches[0])
        self.last_id = candidate['id']
        # Explicit grounded excerpt: no generative rewriting of user-provided source.
        excerpt = ' '.join(candidate['text'].split())
        if len(excerpt) > 380:
            excerpt = excerpt[:377].rsplit(' ', 1)[0] + '…'
        is_draft = candidate['kind'].startswith('draft_')
        if is_draft:
            prefix = "Working draft, not canon yet: "
        elif candidate['kind'] in ('tale', 'story'):
            prefix = "Ah, Sancho, I have the very reel! "
        else:
            prefix = "My dear Sancho, the archive says this: "
        self.history.append({'time': time.time(), 'user': message, 'item': candidate['id']})
        return self._packet(prefix + excerpt, mode, 'lore', 'theatrical', '(sing-song, a little grand)',
                            sources=[{'title': candidate['title'], 'source': candidate['source'], 'id': candidate['id'],
                                      'status': 'draft' if is_draft else 'canon'}])

    def respond(self, message, mode='chat'):
        """mode='director' always coaches. mode='chat' answers lore questions from the archive and
        routes anything that sounds like a person needing help to the director."""
        if mode not in ('chat', 'director'):
            raise ValueError('Invalid mode')
        message = message or ''
        if mode == 'director':
            return self._direct(message, mode)
        if GREETING.match(message):
            return self._packet(WELCOME, mode, 'greeting', 'theatrical', '(sing-song, announcing himself)')
        reading = read_person(message)
        lore_intent = bool(LORE_INTENT.search(message))
        if lore_intent or not reading.has_need:
            matches = self.search(message, limit=6)
            tokens = set(self._tokens(message))
            title_hit = any(tokens & set(re.findall(r'[^\W_]+', m['title'].lower())) for m in matches)
            if matches and (lore_intent or title_hit):
                return self._lore(matches, message, mode)
            if lore_intent:
                return self._packet(NO_RESULT, mode, 'no_result', 'plain', '(drops the accent: blunt, matter-of-fact)')
        return self._direct(message, mode)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('command', choices=['chat', 'search', 'director', 'talk'])
    p.add_argument('message', nargs='?', default='')
    p.add_argument('--db', default='purfluous.sqlite3')
    p.add_argument('--lore', default=str(Path(__file__).parent / 'lore' / 'starter_canon.json'))
    p.add_argument('--draft', action='store_true',
                   help='also load lore/working_draft.json (uncanonized material; answers are labeled as drafts)')
    a = p.parse_intermixed_args()
    if a.command != 'talk' and not a.message:
        p.error('message is required for chat, search and director')
    bot = PurfluousBot(a.db)
    bot.ingest(a.lore)
    if a.draft:
        bot.ingest(Path(__file__).parent / 'lore' / 'working_draft.json')
    if a.command == 'talk':
        # Interactive: the director remembers what it has already asked, so it can escalate
        # from questions to a plain "here's the call". One-shot commands start fresh every time.
        print("Sir Purfluous is in. Blank line to leave.")
        while True:
            try:
                line = input('you> ').strip()
            except EOFError:
                break
            if not line:
                break
            r = bot.respond(line)
            print(f"{r['cue']} {r['text']}\n")
    else:
        if a.command == 'search':
            result = bot.search(a.message)
        else:
            result = bot.respond(a.message, mode='director' if a.command == 'director' else 'chat')
        print(json.dumps(result, indent=2, ensure_ascii=False))
    bot.close()


if __name__ == '__main__':
    main()
