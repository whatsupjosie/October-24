import unittest
from pathlib import Path

import director as d
from sir_purfluous_bot import PurfluousBot

LORE = Path(__file__).parent / 'lore' / 'starter_canon.json'


class ReadingTests(unittest.TestCase):
    def test_signals(self):
        self.assertIn('stuck', d.read_person("I'm totally stuck").signals)
        self.assertIn('stuck', d.read_person("I really don't know").signals)
        self.assertIn('direct_ask', d.read_person('just tell me').signals)
        self.assertIn('rushed', d.read_person("I'm out of time").signals)
        self.assertIn('tone_hot', d.read_person('I played it angry').signals)
        self.assertIn('self_discovery', d.read_person("I don't know what I want").signals)

    def test_quoted_attempt_extracted(self):
        r = d.read_person('I said "I told you never to come back here" and it was flat')
        self.assertEqual(r.attempt, 'I told you never to come back here')

    def test_bare_tell_me_is_not_a_direct_ask(self):
        self.assertNotIn('direct_ask', d.read_person('Tell me about Pete').signals)

    def test_take_is_craft_only_in_context(self):
        self.assertIsNone(d.read_person("I'll take the blue one").craft)
        self.assertEqual(d.read_person('can we do another take').craft, 'take')


class DemonstrationTests(unittest.TestCase):
    def test_slow_inserts_beats(self):
        self.assertIn('[beat]', d.slow('I told you, never to come back here.'))

    def test_slow_pauses_before_the_word_that_matters(self):
        self.assertEqual(d.slow('I told you never to come back here'), 'I told you [beat] never to come back here')

    def test_underplay_removes_heat(self):
        out = d.underplay('I am REALLY done with this!')
        self.assertNotIn('!', out)
        self.assertNotIn('REALLY', out)
        self.assertNotIn('really', out.lower())

    def test_stress_lands_one_word(self):
        out = d.stress('I told you never to come back')
        self.assertIn('NEVER', out)
        self.assertIn('[beat] NEVER', out)

    def test_unknown_kind_raises(self):
        with self.assertRaises(ValueError):
            d.demonstrate('hello there friend', 'shout')


class MoveTests(unittest.TestCase):
    def setUp(self):
        self.dr = d.Director(seed=1)

    def test_question_is_default_and_single(self):
        out = self.dr.respond('I want to make a short film')
        self.assertEqual(out['move'], 'question')
        self.assertEqual(out['text'].count('?'), 1)

    def test_every_question_in_every_pool_is_single(self):
        for pool in d.QUESTIONS.values():
            for q in pool:
                self.assertEqual(q.count('?'), 1, q)

    def test_stuck_asks_twice_then_tells(self):
        a = self.dr.respond("I'm stuck")
        b = self.dr.respond("I'm still stuck")
        c = self.dr.respond("I'm stuck and I don't know")
        self.assertEqual([a['move'], b['move'], c['move']], ['question', 'question', 'tell'])
        self.assertEqual(c['register'], 'plain')
        self.assertIsNotNone(c['proposal'])
        self.assertFalse(c['proposal']['executed'])

    def test_stuck_questions_do_not_repeat_until_pool_exhausted(self):
        seen = [self.dr.respond("I'm stuck")['text'] for _ in range(1)]
        self.dr.session.questions_in_a_row = 0
        seen.append(self.dr.respond("I'm stuck")['text'])
        self.assertNotEqual(seen[0].split('. ', 1)[-1], seen[1].split('. ', 1)[-1])

    def test_direct_ask_tells_in_plain_register_with_cue(self):
        out = self.dr.respond('just tell me what to do')
        self.assertEqual(out['move'], 'tell')
        self.assertEqual(out['register'], 'plain')
        self.assertIn('accent', out['cue'])

    def test_rushed_tells(self):
        self.assertEqual(self.dr.respond("I'm out of time, the take is in ten minutes")['move'], 'tell')

    def test_craft_tell_uses_craft_advice(self):
        out = self.dr.respond('I have no time, just tell me about camera')
        self.assertEqual(out['move'], 'tell')
        self.assertEqual(out['proposal']['topic'], 'camera')

    def test_self_discovery_is_never_told(self):
        for msg in ("who am I", "just tell me who I am", "I don't know what I want"):
            out = d.Director(seed=2).respond(msg)
            self.assertEqual(out['move'], 'question', msg)
            self.assertEqual(out['register'], 'whisper')
            self.assertIn('shouting whisper', out['cue'])

    def test_self_discovery_direct_ask_is_honest_about_it(self):
        out = d.Director(seed=2).respond('just tell me who I am')
        self.assertIn("isn't mine to give", out['text'])

    def test_tone_note_then_demo_when_it_does_not_land(self):
        a = self.dr.respond('I delivered "I told you never to come back here!" and it was angry')
        self.assertEqual(a['move'], 'note')
        self.assertIn('Too hot', a['text'])
        b = self.dr.respond("I tried that and it's still angry")
        self.assertEqual(b['move'], 'demo')
        self.assertEqual(b['demo']['kind'], 'underplay')
        self.assertEqual(b['demo']['original'], 'I told you never to come back here!')
        self.assertNotIn('!', b['demo']['shown'])
        self.assertIn('opposite chair', b['cue'])

    def test_flat_gets_stress_demo(self):
        self.dr.respond('my line "I told you never to come back" was flat')
        out = self.dr.respond('show me')
        self.assertEqual(out['demo']['kind'], 'stress')

    def test_show_me_without_a_line_asks_for_it_honestly(self):
        out = d.Director(seed=3).respond('show me')
        self.assertEqual(out['move'], 'demo')
        self.assertIsNone(out['demo'])
        self.assertIn('quotation marks', out['text'])

    def test_overwhelmed_is_one_thing_at_a_time(self):
        out = self.dr.respond('this is too much')
        self.assertEqual(out['move'], 'note')
        self.assertEqual(out['register'], 'plain')
        self.assertEqual(out['text'].count('?'), 1)

    def test_first_turn_announces_then_snaps_back_after_plain(self):
        a = d.Director(seed=4).respond('I want to make a short film')
        self.assertTrue(a['text'].startswith('Sir Purfluous, at your service!'))
        dr = d.Director(seed=4)
        dr.respond('just tell me')
        b = dr.respond('I want to make a short film')
        self.assertTrue(b['text'].startswith('And now, back to the theatre!'))

    def test_seeded_runs_are_deterministic(self):
        msgs = ["I'm stuck", "who am I", 'I want to make a film']
        a = [d.Director(seed=9).respond(m)['text'] for m in msgs]
        b = [d.Director(seed=9).respond(m)['text'] for m in msgs]
        self.assertEqual(a, b)


DRAFT = Path(__file__).parent / 'lore' / 'working_draft.json'


class CanonTests(unittest.TestCase):
    """Canon is the older repo canon, unchanged. New backstory is a draft: opt-in, labeled, never canon."""

    def setUp(self):
        self.bot = PurfluousBot(seed=1)
        self.bot.ingest(LORE)

    def tearDown(self):
        self.bot.close()

    def count(self):
        return self.bot.conn.execute('SELECT COUNT(*) FROM knowledge').fetchone()[0]

    def test_default_load_is_only_the_original_canon(self):
        self.assertEqual(self.count(), 15)
        n = self.bot.conn.execute("SELECT COUNT(*) FROM knowledge WHERE kind LIKE 'draft_%'").fetchone()[0]
        self.assertEqual(n, 0)

    def test_original_canon_003_is_restored_exactly(self):
        hits = [r['text'] for r in self.bot.search('vaudeville grindhouse', limit=30)
                if r['title'] == 'The beautiful obsolete studio']
        self.assertEqual(hits, ["The studio grew from a vaudeville theatre to a grindhouse and adult theatre. "
                                "Sir Purfluous cherishes beautiful, archaic filming equipment and dreams larger than the budget."])

    def test_draft_story_is_not_reachable_by_default(self):
        found = [r for r in self.bot.search('squatter IRS back taxes', limit=30) if r['kind'].startswith('draft_')]
        self.assertEqual(found, [])
        self.assertNotEqual(self.bot.respond('What do you know about the squatter?')['move'], 'lore')

    def test_draft_loads_only_on_request_and_is_labeled(self):
        self.bot.ingest(DRAFT)
        self.assertEqual(self.count(), 23)
        x = self.bot.respond('What do you know about the squatter?')
        self.assertEqual(x['move'], 'lore')
        self.assertTrue(x['text'].startswith('Working draft, not canon yet:'))
        self.assertEqual(x['sources'][0]['status'], 'draft')

    def test_canon_answers_are_labeled_canon(self):
        x = self.bot.respond('What do you know about Pete?')
        self.assertEqual(x['sources'][0]['status'], 'canon')

    def test_draft_keeps_his_wording(self):
        self.bot.ingest(DRAFT)
        blob = ' '.join(r['text'] for r in self.bot.search('arty movies failed porn figure squatter leave Lord knows', limit=30))
        self.assertIn('the only thing he could figure was to start shooting porn', blob)
        self.assertIn("a squatter who wouldn't leave", blob)
        self.assertIn('Lord knows where he got it', blob)

    def test_both_versions_coexist_unresolved(self):
        self.bot.ingest(DRAFT)
        blob = ' '.join(r['text'].lower() for r in self.bot.search('studio theatre grindhouse porn', limit=30))
        self.assertIn('grindhouse and adult theatre', blob)
        self.assertIn('start shooting porn', blob)

    def test_ingest_is_idempotent_with_draft(self):
        self.bot.ingest(DRAFT)
        n = self.count()
        self.bot.ingest(DRAFT)
        self.assertEqual(n, self.count())

    def test_raw_dictation_file_is_verbatim(self):
        raw = (Path(__file__).parent / 'lore' / 'dictation_raw.md').read_text(encoding='utf-8')
        self.assertIn('the only thing he could figure was to start shooting porn. So, he did.', raw)
        self.assertIn("he's pompus but funy curt and rude but in a playful wy thta isnt mean", raw)
        self.assertIn("cuz he's ignorant", raw)


class RoutingTests(unittest.TestCase):
    def setUp(self):
        self.bot = PurfluousBot(seed=1)
        self.bot.ingest(LORE)

    def tearDown(self):
        self.bot.close()

    def test_the_case_that_used_to_return_the_scarf(self):
        x = self.bot.respond('too angry, slow it down, I need a pause')
        self.assertEqual(x['sources'], [])
        self.assertEqual(x['move'], 'note')

    def test_career_confusion_goes_to_director_not_lore(self):
        x = self.bot.respond("I'm stuck on what career to pick")
        self.assertEqual(x['sources'], [])
        self.assertIn(x['move'], ('question', 'tell'))

    def test_lore_questions_still_get_grounded_answers(self):
        x = self.bot.respond('What do you know about Pete?')
        self.assertEqual(x['move'], 'lore')
        self.assertTrue(x['sources'])

    def test_unknown_lore_is_declined_honestly(self):
        x = self.bot.respond('Tell me about Data Storyteller')
        self.assertEqual(x['move'], 'no_result')
        self.assertEqual(x['sources'], [])
        self.assertIn("won't invent", x['text'])

    def test_director_mode_never_returns_lore(self):
        x = self.bot.respond('Elizabeth Taylor scarf', mode='director')
        self.assertEqual(x['sources'], [])

    def test_greeting(self):
        self.assertEqual(self.bot.respond('Hello there')['move'], 'greeting')

    def test_stopword_only_query_finds_nothing(self):
        self.assertEqual(self.bot.search('what do you know about it'), [])

    def test_response_schema_is_uniform(self):
        keys = {'speaker', 'text', 'mode', 'move', 'reason', 'register', 'cue', 'proposal', 'demo', 'sources'}
        for msg in ('hello', 'What do you know about Pete?', "I'm stuck", 'zzzz'):
            self.assertEqual(set(self.bot.respond(msg)), keys, msg)

    def test_no_background_monitoring_or_initiation(self):
        self.assertFalse(hasattr(self.bot, 'monitoring_loop'))
        self.assertFalse(hasattr(self.bot.director, 'monitoring_loop'))
        before = self.bot.director.session.turns
        self.bot.search('anything')
        self.assertEqual(self.bot.director.session.turns, before)


class CliTests(unittest.TestCase):
    def run_cli(self, *args):
        import json, subprocess, sys, tempfile
        db = str(Path(tempfile.mkdtemp()) / 't.sqlite3')
        out = subprocess.run([sys.executable, str(Path(__file__).parent / 'sir_purfluous_bot.py'), *args, '--db', db],
                             capture_output=True, text=True, check=True).stdout
        return json.loads(out)

    def test_flag_may_sit_anywhere(self):
        a = self.run_cli('chat', '--draft', 'What do you know about the squatter?')
        b = self.run_cli('chat', 'What do you know about the squatter?', '--draft')
        self.assertEqual(a['move'], 'lore')
        self.assertEqual(a['text'], b['text'])
        self.assertTrue(a['text'].startswith('Working draft, not canon yet:'))

    def test_default_cli_does_not_know_the_draft(self):
        self.assertEqual(self.run_cli('chat', 'What do you know about the squatter?')['move'], 'no_result')


if __name__ == '__main__':
    unittest.main()
