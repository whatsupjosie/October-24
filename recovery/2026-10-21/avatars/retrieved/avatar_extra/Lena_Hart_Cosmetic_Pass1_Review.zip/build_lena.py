"""Lena Hart stylized 3D rig, from reference colors and canonical PubCast joint source.
Generated geometry is an authored approximation, not photogrammetric reconstruction.
"""
import json, math, struct
from pathlib import Path
import numpy as np
import trimesh
ROOT=Path(__file__).parent
J=json.loads((ROOT/'canonical_rig.json').read_text())['joints']; names=[x['name'] for x in J]; ids={n:i for i,n in enumerate(names)}
world=[]
for j in J: world.append(np.array(j['offset'],float)+(world[ids[j['parent']]] if j['parent'] else 0))
parts=[]
def add(mesh,color,bone,name):
    parts.append((mesh,np.array(color,dtype=float)/255,ids[bone],name))
def ell(center,radii,color,bone,name,sub=2):
    m=trimesh.creation.icosphere(subdivisions=sub,radius=1);m.apply_scale(radii);m.apply_translation(center);add(m,color,bone,name)
def cyl(a,b,r1,r2,color,bone,name,n=14):
    a=np.array(a,float);b=np.array(b,float);axis=b-a;axis/=np.linalg.norm(axis);u=np.cross(axis,[0,0,1]) if abs(axis[2])<.9 else np.cross(axis,[0,1,0]);u/=np.linalg.norm(u);v=np.cross(axis,u)
    verts=[]
    for c,r in [(a,r1),(b,r2)]:
        for i in range(n):verts.append(c+r*(u*math.cos(2*math.pi*i/n)+v*math.sin(2*math.pi*i/n)))
    faces=[]
    for i in range(n): k=(i+1)%n;faces.extend([[i,k,n+i],[k,n+k,n+i]])
    faces.extend([[0,k,i] for i,k in [(i,(i+1)%n) for i in range(1,n-1)]])
    faces.extend([[n,n+i,n+i+1] for i in range(1,n-1)])
    add(trimesh.Trimesh(vertices=verts,faces=faces,process=False),color,bone,name)
def box(center,scale,color,bone,name):
    m=trimesh.creation.box(extents=scale);m.apply_translation(center);add(m,color,bone,name)
SKIN=[232,171,134];HAIR=[223,81,117];HAIR_DARK=[157,42,76];BLACK=[28,29,28];JACKET=[35,35,33];JACKET_LIGHT=[58,56,51];JEAN=[49,89,108];JEAN_LIGHT=[69,109,128];BOOT=[24,23,22];GOLD=[189,145,76];WHITE=[245,238,219];IRIS=[39,122,118]
# Lena cosmetic pass 1: tailored silhouette, tapered anatomy, shaped face and hair.
def loft(y_sections, color, bone, name, n=32, center_z=0):
    vs=[]; fs=[]
    for y,rx,rz,cx,cz in y_sections:
        for i in range(n):
            t=2*math.pi*i/n
            vs.append([cx+rx*math.cos(t),y,center_z+cz+rz*math.sin(t)])
    for k in range(len(y_sections)-1):
        for i in range(n):
            j=(i+1)%n; a=k*n+i; b=k*n+j
            fs.extend([[a,b,b+n],[a,b+n,a+n]])
    fs.extend([[0,i+1,i] for i in range(1,n-1)])
    z=(len(y_sections)-1)*n
    fs.extend([[z,z+i,z+i+1] for i in range(1,n-1)])
    add(trimesh.Trimesh(vertices=vs,faces=fs,process=False),color,bone,name)
def tapered(a,b,radii_a,radii_b,color,bone,name,n=20):
    a=np.array(a,float);b=np.array(b,float); d=b-a;d/=np.linalg.norm(d)
    u=np.cross(d,[0,0,1]) if abs(d[2])<.92 else np.cross(d,[0,1,0]);u/=np.linalg.norm(u);v=np.cross(d,u)
    vv=[]
    for c,(ru,rv) in [(a,radii_a),(b,radii_b)]:
        for i in range(n):
            t=i*2*math.pi/n;vv.append(c+ru*u*math.cos(t)+rv*v*math.sin(t))
    ff=[]
    for i in range(n):
        j=(i+1)%n;ff.extend([[i,j,n+j],[i,n+j,n+i]])
    ff.extend([[0,i+1,i] for i in range(1,n-1)])
    ff.extend([[n,n+i,n+i+1] for i in range(1,n-1)])
    add(trimesh.Trimesh(vertices=vv,faces=ff,process=False),color,bone,name)
# Fitted torso: shoulders and chest narrow into waist; jacket open down the front.
loft([(1.02,.153,.092,0,0),(1.09,.142,.085,0,0),(1.18,.143,.084,0,0),(1.27,.164,.099,0,0),(1.34,.188,.093,0,0),(1.40,.156,.08,0,0)],BLACK,'Spine_03','Fitted black top')
# Leather panels are thin shaped surfaces rather than an inflated jacket shell.
for s,side in [(1,'L'),(-1,'R')]:
    # front jacket panels, with gap revealing the black top
    loft([(1.04,.065,.014,s*.112,.105),(1.13,.07,.014,s*.118,.101),(1.26,.076,.014,s*.133,.105),(1.36,.068,.014,s*.133,.086)],JACKET,'Spine_03','Jacket front '+side,18)
    tapered([s*.105,1.40,.105],[s*.065,1.17,.115],(.028,.009),(.018,.009),JACKET_LIGHT,'Spine_03','Notched lapel '+side)
    tapered([s*.168,1.30,.105],[s*.137,1.06,.105],(.009,.009),(.009,.009),GOLD,'Spine_03','Asymmetric zipper piping '+side)
    for y in [1.14,1.26,1.35]: ell([s*.172,y,.111],[.006,.006,.004],GOLD,'Spine_03','Jacket metal stud',1)
# rear jacket shaped like a coat, not a ball
loft([(1.03,.153,.02,0,-.080),(1.18,.15,.02,0,-.087),(1.31,.18,.02,0,-.083),(1.39,.15,.02,0,-.065)],JACKET,'Spine_03','Leather jacket back')
loft([(0.99,.17,.102,0,0),(1.05,.164,.104,0,0),(1.12,.147,.085,0,0)],JEAN,'Pelvis','Fitted jeans hip')
for s,side in [(1,'L'),(-1,'R')]:
    # thighs and calves are anatomical tapered volumes, not tubes.
    tapered([s*.094,1.005,0],[s*.108,.735,0],(.106,.099),(.075,.075),JEAN,'Thigh_'+side,'Jeans upper leg '+side)
    tapered([s*.108,.75,0],[s*.107,.57,0],(.077,.078),(.066,.07),JEAN,'Thigh_'+side,'Jeans knee '+side)
    tapered([s*.107,.57,0],[s*.107,.38,0],(.067,.067),(.050,.053),JEAN,'Calf_'+side,'Jeans calf '+side)
    tapered([s*.107,.38,0],[s*.107,.24,0],(.052,.052),(.050,.051),JEAN,'Calf_'+side,'Jeans ankle '+side)
    tapered([s*.107,.27,0],[s*.107,.095,0],(.060,.065),(.071,.071),BOOT,'Foot_'+side,'Boot shaft '+side)
    ell([s*.107,.084,.063],[.079,.064,.124],BOOT,'Foot_'+side,'Boot rounded toe',2)
    box([s*.107,.052,.038],[.16,.024,.21],BLACK,'Foot_'+side,'Boot sole')
    for y in [.15,.19,.23]: box([s*.107,y,.069],[.078,.008,.008],GOLD,'Foot_'+side,'Boot eyelets')
    tapered([s*.185,1.355,0],[s*.443,1.354,0],(.077,.071),(.054,.053),JACKET,'UpperArm_'+side,'Tailored leather upper sleeve')
    tapered([s*.443,1.354,0],[s*.718,1.353,0],(.055,.052),(.038,.038),JACKET,'LowerArm_'+side,'Tailored leather forearm')
    tapered([s*.700,1.353,0],[s*.745,1.353,0],(.045,.043),(.043,.042),JACKET_LIGHT,'Hand_'+side,'Jacket cuff')
    tapered([s*.745,1.353,0],[s*.853,1.353,0],(.036,.025),(.019,.014),SKIN,'Hand_'+side,'Extended hand '+side)
    for f in ['Index','Middle','Ring','Pinky']:
        n='{}_01_{}'.format(f,side)
        if n in ids:ell(world[ids[n]]+[0,.002,.003],[.018,.012,.011],SKIN,n,f+' finger '+side,1)
box([0,1.035,.103],[.318,.027,.021],BLACK,'Pelvis','Belt')
box([0,1.035,.124],[.065,.044,.008],GOLD,'Pelvis','Belt buckle')
box([0,1.035,.132],[.045,.028,.009],BLACK,'Pelvis','Buckle inset')
# Sculpted face: oval cranium, narrowed jaw and pointed chin, all based on the T-pose reference.
c=world[ids['Head']]
tapered([0,1.415,0],[0,1.515,0],(.047,.044),(.043,.042),SKIN,'Neck_01','Neck')
loft([(c[1]-.076,.044,.059,0,.018),(c[1]-.045,.073,.077,0,.008),(c[1]+.005,.091,.085,0,0),(c[1]+.066,.099,.088,0,-.002),(c[1]+.132,.093,.087,0,-.006),(c[1]+.174,.067,.067,0,-.012)],SKIN,'Head','Sculpted face',40)
for s in [-1,1]:
    # Eyes are shallow almond shapes on front surface.
    ell(c+[s*.045,.083,.087],[.029,.013,.006],WHITE,'Head','Almond eye white',3)
    ell(c+[s*.045,.083,.092],[.011,.012,.005],IRIS,'Head','Teal iris',3)
    ell(c+[s*.045,.083,.096],[.005,.008,.003],BLACK,'Head','Pupil',2)
    tapered(c+[s*.072,.121,.088],c+[s*.022,.128,.092],(.006,.005),(.006,.005),HAIR_DARK,'Head','Arched eyebrow',12)
    ell(c+[s*.095,.062,.004],[.014,.026,.021],SKIN,'Head','Ear',2)
ell(c+[0,.045,.092],[.014,.029,.018],SKIN,'Head','Refined nose',3)
ell(c+[0,-.012,.083],[.030,.005,.006],[159,78,85],'Head','Mouth',3)
# Side-parted pink bob; rear volume hugs head, sweeping layers frame the face.
ell(c+[0,.167,-.042],[.111,.082,.088],HAIR,'Head','Pink hair crown',3)
for s in [-1,1]:
    ell(c+[s*.099,.080,-.050],[.025,.098,.050],HAIR,'Head','Bob side mass '+str(s),3)
    for k in range(5):
        x=s*(.017+k*.017)
        tapered(c+[x,.224,-.015],c+[x+s*.024,.155,.070],(.011,.009),(.004,.004),HAIR if k%3 else HAIR_DARK,'Head','Swept bangs',12)
    for k in range(6):
        x=s*(.060+k*.009)
        tapered(c+[x,.116,-.090],c+[x+s*.020,-.048,-.041],(.014,.012),(.004,.004),HAIR,'Head','Bob layered ends',10)
# Material-per-part meshes, bound rigidly to canonical joint nodes; articulated at joints.
buf=bytearray();views=[];accessors=[]
def acc(arr,component,typ,target=None,minmax=False):
    a=np.ascontiguousarray(arr);offset=len(buf);raw=a.tobytes();buf.extend(raw);buf.extend(b'\0'*((-len(buf))%4));v={'buffer':0,'byteOffset':offset,'byteLength':len(raw)}
    if target:v['target']=target
    views.append(v);o={'bufferView':len(views)-1,'componentType':component,'count':len(a),'type':typ}
    if minmax:o.update(min=a.min(axis=0).tolist() if a.ndim>1 else [float(a.min())],max=a.max(axis=0).tolist() if a.ndim>1 else [float(a.max())])
    accessors.append(o);return len(accessors)-1
v=[];norm=[];jids=[];weights=[];tri=[];materials=[];material_map={};groups={}
for mesh,col,jid,label in parts:
    k=tuple(col.tolist());m=material_map.get(k)
    if m is None:
        m=len(materials);material_map[k]=m;materials.append({'name':'Lena color '+str(m),'pbrMetallicRoughness':{'baseColorFactor':list(k)+[1.0],'metallicFactor':0.05 if k!=tuple(GOLD) else .65,'roughnessFactor':.72},'doubleSided':True})
    start=len(v);v.extend(mesh.vertices.tolist());norm.extend(mesh.vertex_normals.tolist());jids.extend([[jid,0,0,0]]*len(mesh.vertices));weights.extend([[1,0,0,0]]*len(mesh.vertices));groups.setdefault(m,[]).extend((mesh.faces+start).flatten().tolist())
pos=acc(np.array(v,dtype='<f4'),5126,'VEC3',34962,True);no=acc(np.array(norm,dtype='<f4'),5126,'VEC3',34962);ji=acc(np.array(jids,dtype='<u2'),5123,'VEC4',34962);we=acc(np.array(weights,dtype='<f4'),5126,'VEC4',34962)
prims=[]
for mat,faces in groups.items():
    idx=acc(np.array(faces,dtype='<u4'),5125,'SCALAR',34963)
    prims.append({'attributes':{'POSITION':pos,'NORMAL':no,'JOINTS_0':ji,'WEIGHTS_0':we},'indices':idx,'material':mat})
inv=[]
for p in world:
    a=np.eye(4);a[:3,3]=-p;inv.append(a.T.flatten())
ibm=acc(np.array(inv,dtype='<f4'),5126,'MAT4')
nodes=[{'name':j['name'],'translation':j['offset'],'children':[]} for j in J]
for i,j in enumerate(J):
    if j['parent']:nodes[ids[j['parent']]]['children'].append(i)
for n in nodes:
    if not n['children']:n.pop('children')
nodes.append({'name':'Lena_Hart_Skinned','mesh':0,'skin':0})
times=acc(np.array([0,.5,1,1.5,2],dtype='<f4'),5126,'SCALAR',minmax=True)
channels=[];samplers=[]
for bone,axis,angles in [('UpperArm_L','z',[0,-.15,-.35,-.15,0]),('UpperArm_R','z',[0,.15,.35,.15,0]),('Head','y',[0,.13,0,-.13,0]),('Thigh_L','x',[0,.13,0,-.13,0]),('Thigh_R','x',[0,-.13,0,.13,0])]:
    q=[]
    for a in angles:
        half=a/2;q.append([math.sin(half) if axis=='x' else 0,math.sin(half) if axis=='y' else 0,math.sin(half) if axis=='z' else 0,math.cos(half)])
    qa=acc(np.array(q,dtype='<f4'),5126,'VEC4');samplers.append({'input':times,'output':qa,'interpolation':'LINEAR'});channels.append({'sampler':len(samplers)-1,'target':{'node':ids[bone],'path':'rotation'}})
gltf={'asset':{'version':'2.0','generator':'PubCast Lena Hart offline character authoring'},'scene':0,'scenes':[{'nodes':[0,len(nodes)-1]}],'nodes':nodes,'buffers':[{'byteLength':len(buf)}],'bufferViews':views,'accessors':accessors,'meshes':[{'name':'Lena Hart - stylized pink hair leather jacket jeans boots','primitives':prims}],'materials':materials,'skins':[{'name':'PubCast canonical Rust 71','joints':list(range(len(J))),'skeleton':0,'inverseBindMatrices':ibm}],'animations':[{'name':'Lena idle head and limbs','channels':channels,'samplers':samplers}]}
js=json.dumps(gltf,separators=(',',':')).encode();js+=b' '*((-len(js))%4)
blob=b'glTF'+struct.pack('<II',2,12+8+len(js)+8+len(buf))+struct.pack('<I4s',len(js),b'JSON')+js+struct.pack('<I4s',len(buf),b'BIN\0')+buf
out=ROOT/'assets'/'lena_hart_stylized_rigged.glb';out.write_bytes(blob)
print('Wrote',out,'vertices',len(v),'triangles',sum(len(x) for x in groups.values())//3,'bones',len(J),'animations',len(channels))
