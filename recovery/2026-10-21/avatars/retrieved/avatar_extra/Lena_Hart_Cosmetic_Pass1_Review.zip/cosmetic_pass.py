from pathlib import Path
p=Path(__file__).parent/'build_lena.py'
s=p.read_text()
start=s.index('# Anatomical scale follows')
end=s.index('# Material-per-part meshes')
new='''# Lena cosmetic pass 1: tailored silhouette, tapered anatomy, shaped face and hair.
def loft(y_sections, color, bone, name, n=32, center_z=0):
    vs=[]; fs=[]
    for y,rx,rz,cx,cz in y_sections:
        for i in range(n):
            t=2*math.pi*i/n
            vs.append([cx+rx*math.cos(t),y,center_z+cz+rz*math.sin(t)])
    for k in range(len(y_sections)-1):
        for i in range(n):
            j=(i+1)%n; a=k*n+i; b=k*n+j
            fs.extend([[a,b,b+n],[a,b+n,a+n]])
    fs.extend([[0,i+1,i] for i in range(1,n-1)])
    z=(len(y_sections)-1)*n
    fs.extend([[z,z+i,z+i+1] for i in range(1,n-1)])
    add(trimesh.Trimesh(vertices=vs,faces=fs,process=False),color,bone,name)
def tapered(a,b,radii_a,radii_b,color,bone,name,n=20):
    a=np.array(a,float);b=np.array(b,float); d=b-a;d/=np.linalg.norm(d)
    u=np.cross(d,[0,0,1]) if abs(d[2])<.92 else np.cross(d,[0,1,0]);u/=np.linalg.norm(u);v=np.cross(d,u)
    vv=[]
    for c,(ru,rv) in [(a,radii_a),(b,radii_b)]:
        for i in range(n):
            t=i*2*math.pi/n;vv.append(c+ru*u*math.cos(t)+rv*v*math.sin(t))
    ff=[]
    for i in range(n):
        j=(i+1)%n;ff.extend([[i,j,n+j],[i,n+j,n+i]])
    ff.extend([[0,i+1,i] for i in range(1,n-1)])
    ff.extend([[n,n+i,n+i+1] for i in range(1,n-1)])
    add(trimesh.Trimesh(vertices=vv,faces=ff,process=False),color,bone,name)
# Fitted torso: shoulders and chest narrow into waist; jacket open down the front.
loft([(1.02,.153,.092,0,0),(1.09,.142,.085,0,0),(1.18,.143,.084,0,0),(1.27,.164,.099,0,0),(1.34,.188,.093,0,0),(1.40,.156,.08,0,0)],BLACK,'Spine_03','Fitted black top')
# Leather panels are thin shaped surfaces rather than an inflated jacket shell.
for s,side in [(1,'L'),(-1,'R')]:
    # front jacket panels, with gap revealing the black top
    loft([(1.04,.065,.014,s*.112,.105),(1.13,.07,.014,s*.118,.101),(1.26,.076,.014,s*.133,.105),(1.36,.068,.014,s*.133,.086)],JACKET,'Spine_03','Jacket front '+side,18)
    tapered([s*.105,1.40,.105],[s*.065,1.17,.115],(.028,.009),(.018,.009),JACKET_LIGHT,'Spine_03','Notched lapel '+side)
    tapered([s*.168,1.30,.105],[s*.137,1.06,.105],(.009,.009),(.009,.009),GOLD,'Spine_03','Asymmetric zipper piping '+side)
    for y in [1.14,1.26,1.35]: ell([s*.172,y,.111],[.006,.006,.004],GOLD,'Spine_03','Jacket metal stud',1)
# rear jacket shaped like a coat, not a ball
loft([(1.03,.153,.02,0,-.080),(1.18,.15,.02,0,-.087),(1.31,.18,.02,0,-.083),(1.39,.15,.02,0,-.065)],JACKET,'Spine_03','Leather jacket back')
loft([(0.99,.17,.102,0,0),(1.05,.164,.104,0,0),(1.12,.147,.085,0,0)],JEAN,'Pelvis','Fitted jeans hip')
for s,side in [(1,'L'),(-1,'R')]:
    # thighs and calves are anatomical tapered volumes, not tubes.
    tapered([s*.094,1.005,0],[s*.108,.735,0],(.106,.099),(.075,.075),JEAN,'Thigh_'+side,'Jeans upper leg '+side)
    tapered([s*.108,.75,0],[s*.107,.57,0],(.077,.078),(.066,.07),JEAN,'Thigh_'+side,'Jeans knee '+side)
    tapered([s*.107,.57,0],[s*.107,.38,0],(.067,.067),(.050,.053),JEAN,'Calf_'+side,'Jeans calf '+side)
    tapered([s*.107,.38,0],[s*.107,.24,0],(.052,.052),(.050,.051),JEAN,'Calf_'+side,'Jeans ankle '+side)
    tapered([s*.107,.27,0],[s*.107,.095,0],(.060,.065),(.071,.071),BOOT,'Foot_'+side,'Boot shaft '+side)
    ell([s*.107,.084,.063],[.079,.064,.124],BOOT,'Foot_'+side,'Boot rounded toe',2)
    box([s*.107,.052,.038],[.16,.024,.21],BLACK,'Foot_'+side,'Boot sole')
    for y in [.15,.19,.23]: box([s*.107,y,.069],[.078,.008,.008],GOLD,'Foot_'+side,'Boot eyelets')
    tapered([s*.185,1.355,0],[s*.443,1.354,0],(.077,.071),(.054,.053),JACKET,'UpperArm_'+side,'Tailored leather upper sleeve')
    tapered([s*.443,1.354,0],[s*.718,1.353,0],(.055,.052),(.038,.038),JACKET,'LowerArm_'+side,'Tailored leather forearm')
    tapered([s*.700,1.353,0],[s*.745,1.353,0],(.045,.043),(.043,.042),JACKET_LIGHT,'Hand_'+side,'Jacket cuff')
    tapered([s*.745,1.353,0],[s*.853,1.353,0],(.036,.025),(.019,.014),SKIN,'Hand_'+side,'Extended hand '+side)
    for f in ['Index','Middle','Ring','Pinky']:
        n='{}_01_{}'.format(f,side)
        if n in ids:ell(world[ids[n]]+[0,.002,.003],[.018,.012,.011],SKIN,n,f+' finger '+side,1)
box([0,1.035,.103],[.318,.027,.021],BLACK,'Pelvis','Belt')
box([0,1.035,.124],[.065,.044,.008],GOLD,'Pelvis','Belt buckle')
box([0,1.035,.132],[.045,.028,.009],BLACK,'Pelvis','Buckle inset')
# Sculpted face: oval cranium, narrowed jaw and pointed chin, all based on the T-pose reference.
c=world[ids['Head']]
tapered([0,1.415,0],[0,1.515,0],(.047,.044),(.043,.042),SKIN,'Neck_01','Neck')
loft([(c[1]-.076,.044,.059,0,.018),(c[1]-.045,.073,.077,0,.008),(c[1]+.005,.091,.085,0,0),(c[1]+.066,.099,.088,0,-.002),(c[1]+.132,.093,.087,0,-.006),(c[1]+.174,.067,.067,0,-.012)],SKIN,'Head','Sculpted face',40)
for s in [-1,1]:
    # Eyes are shallow almond shapes on front surface.
    ell(c+[s*.045,.083,.087],[.029,.013,.006],WHITE,'Head','Almond eye white',3)
    ell(c+[s*.045,.083,.092],[.011,.012,.005],IRIS,'Head','Teal iris',3)
    ell(c+[s*.045,.083,.096],[.005,.008,.003],BLACK,'Head','Pupil',2)
    tapered(c+[s*.072,.121,.088],c+[s*.022,.128,.092],(.006,.005),(.006,.005),HAIR_DARK,'Head','Arched eyebrow',12)
    ell(c+[s*.095,.062,.004],[.014,.026,.021],SKIN,'Head','Ear',2)
ell(c+[0,.045,.092],[.014,.029,.018],SKIN,'Head','Refined nose',3)
ell(c+[0,-.012,.083],[.030,.005,.006],[159,78,85],'Head','Mouth',3)
# Side-parted pink bob; rear volume hugs head, sweeping layers frame the face.
ell(c+[0,.167,-.032],[.108,.083,.094],HAIR,'Head','Pink hair crown',3)
for s in [-1,1]:
    ell(c+[s*.086,.080,-.032],[.042,.107,.080],HAIR,'Head','Bob side mass '+str(s),3)
    for k in range(5):
        x=s*(.017+k*.017)
        tapered(c+[x,.224,-.015],c+[x+s*.024,.155,.070],(.015,.012),(.005,.006),HAIR if k%3 else HAIR_DARK,'Head','Swept bangs',12)
    for k in range(6):
        x=s*(.060+k*.009)
        tapered(c+[x,.116,-.090],c+[x+s*.020,-.048,-.041],(.014,.012),(.004,.004),HAIR,'Head','Bob layered ends',10)
'''
p.write_text(s[:start]+new+s[end:])
