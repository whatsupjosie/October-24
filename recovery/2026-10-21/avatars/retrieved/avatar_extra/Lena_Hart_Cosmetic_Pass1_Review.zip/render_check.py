import trimesh,numpy as np
from PIL import Image,ImageDraw
from pathlib import Path
root=Path(__file__).parent
scene=trimesh.load(root/'assets/lena_hart_stylized_rigged.glb',force='scene')
W,H=900,1050;im=Image.new('RGB',(W,H),'white');draw=ImageDraw.Draw(im)
tri=[]
for name,geom in scene.geometry.items():
    v=np.asarray(geom.vertices); f=np.asarray(geom.faces); n=np.asarray(geom.face_normals)
    col=np.array([160,160,160]);vis=geom.visual
    try:
        if hasattr(vis,'material') and vis.material is not None:
            mat=vis.material; col=np.array(mat.baseColorFactor[:3]) if hasattr(mat,'baseColorFactor') else col
    except Exception:pass
    for i,face in enumerate(f):
        vv=v[face];center=vv.mean(axis=0)
        # +Z front, skip backfacing
        if n[i,2]<-.10:continue
        pts=[(W/2+float(x)*450, H-75-float(y)*545) for x,y,z in vv]
        light=.65+.35*max(0,float(n[i,2]));color=tuple(np.clip(col*light,0,255).astype(int))
        tri.append((float(center[2]),pts,color))
for _,pts,col in sorted(tri,key=lambda x:x[0]):draw.polygon(pts,fill=col)
im.save(root/'Lena_Cosmetic_Pass1_Front.png')
print('rendered',len(tri),'faces')
