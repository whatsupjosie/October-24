"""Offline, on-demand Sir Purfluous character and director bot. Python 3.10+; stdlib only."""
from __future__ import annotations
import argparse, hashlib, json, random, re, sqlite3, time
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS knowledge (
 id TEXT PRIMARY KEY, kind TEXT NOT NULL, title TEXT NOT NULL,
 text TEXT NOT NULL, source TEXT NOT NULL, signature TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS knowledge_kind ON knowledge(kind);
CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_fts USING fts5(
 title, text, content='knowledge', content_rowid='rowid', tokenize='unicode61');
CREATE TRIGGER IF NOT EXISTS knowledge_ai AFTER INSERT ON knowledge BEGIN
 INSERT INTO knowledge_fts(rowid,title,text) VALUES(new.rowid,new.title,new.text);
END;
CREATE TRIGGER IF NOT EXISTS knowledge_ad AFTER DELETE ON knowledge BEGIN
 INSERT INTO knowledge_fts(knowledge_fts,rowid,title,text) VALUES('delete',old.rowid,old.title,old.text);
END;
CREATE TRIGGER IF NOT EXISTS knowledge_au AFTER UPDATE ON knowledge BEGIN
 INSERT INTO knowledge_fts(knowledge_fts,rowid,title,text) VALUES('delete',old.rowid,old.title,old.text);
 INSERT INTO knowledge_fts(rowid,title,text) VALUES(new.rowid,new.title,new.text);
END;
"""
WELCOME = "Ah, Sancho! The theatre is open, the budget is not, and somehow we must make art. What have you brought me?"
NO_RESULT = "Sancho, that particular reel is not in my archive. I won't invent a fact merely to improve the lighting."
DIRECTOR = {
 "rehearsal": ("Performance rehearsal","Begin with intention: what does the character want? Play the objective once plainly, then vary tempo, stakes, and restraint."),
 "camera": ("Camera framing","Find the story's point of view before choosing a lens. Establish geography, protect eyelines, and rehearse the movement before rolling."),
 "lighting": ("Lighting design","Decide what the light should reveal or conceal. Establish a motivated source, then test contrast and continuity."),
 "sound": ("Sound preparation","Confirm microphone placement, room tone, and gain before the take. A glorious image cannot rescue unintelligible dialogue."),
 "blocking": ("Stage blocking","Identify entrances, exits, eyelines, sightlines, and safe movement. Mark positions before rehearsing."),
 "take": ("Another take","Give one actionable note at a time. Specify what changes, then give the performer space to execute.")
}
class PurfluousBot:
 def __init__(self, db=':memory:', seed=None):
  self.conn=sqlite3.connect(str(db))
  self.conn.executescript(SCHEMA)
  self.rng=random.Random(seed)
  self.last_id=None
  self.history=[]
 def close(self):
  self.conn.close()
 def ingest(self, path):
  p=Path(path)
  if not p.exists(): raise FileNotFoundError(path)
  total=0
  paths=sorted(x for x in p.rglob('*') if x.is_file() and x.suffix.lower() in {'.json','.md','.txt','.py'}) if p.is_dir() else [p]
  for f in paths:
   if f.stat().st_size>3_000_000: continue
   if f.suffix.lower()=='.json':
    try:
     obj=json.loads(f.read_text(encoding='utf-8-sig'))
     if isinstance(obj,list) and all(isinstance(x,dict) and {'title','text'}<=x.keys() for x in obj):
      for i,x in enumerate(obj):
       self._add(x.get('id') or f'{f}:{i}',x.get('kind','lore'),x['title'],x['text'],x.get('source',str(f)))
       total+=1
      continue
    except (ValueError,UnicodeError): pass
   try: data=f.read_text(encoding='utf-8-sig')
   except (UnicodeError,OSError): continue
   # Bounded sections: preserve code, comments and their actual provenance.
   chunks=re.split(r'(?m)^(?=class |def |#{3,}|## |\[.+\])',data)
   if len(chunks)==1: chunks=[data[i:i+1800] for i in range(0,len(data),1800)]
   for i,chunk in enumerate(chunks):
    if not chunk.strip(): continue
    for j in range(0,len(chunk),1800):
     part=chunk[j:j+1800]
     title=next((v.strip(' #[]\t')[:150] for v in part.splitlines() if v.strip()),f.name)
     self._add(f'{f}:{i}:{j}',f.suffix[1:],title,part,str(f))
     total+=1
  self.conn.commit()
  return total
 def _add(self,id,kind,title,body,source):
  uid=hashlib.sha256(str(id).encode()).hexdigest()
  body=str(body)[:10000]
  signature=hashlib.sha256(body.encode()).hexdigest()
  self.conn.execute("""INSERT INTO knowledge(id,kind,title,text,source,signature)
   VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
   kind=excluded.kind,title=excluded.title,text=excluded.text,source=excluded.source,signature=excluded.signature""",
   (uid,str(kind),str(title),body,str(source),signature))
 def search(self,q,limit=5,kinds=None):
  tokens=re.findall(r'[^\W_]+',q.lower(),flags=re.UNICODE)
  tokens=[t for t in tokens if len(t)>=2][:16]
  if not tokens:return []
  match=' OR '.join('"'+t.replace('"','')+'"' for t in tokens)
  sql="""SELECT k.id,k.kind,k.title,k.text,k.source,bm25(knowledge_fts,4.0,1.0) AS score
          FROM knowledge_fts JOIN knowledge k ON k.rowid=knowledge_fts.rowid WHERE knowledge_fts MATCH ?"""
  args=[match]
  if kinds:
   sql+=' AND k.kind IN ('+','.join('?' for _ in kinds)+')'
   args+=list(kinds)
  sql+=' ORDER BY score ASC,k.id ASC LIMIT ?';args.append(max(1,min(int(limit),30)))
  return [dict(zip(['id','kind','title','text','source','score'],row)) for row in self.conn.execute(sql,args)]
 def respond(self,message,mode='chat'):
  if mode not in ('chat','director'):raise ValueError('Invalid mode')
  matches=self.search(message,limit=6)
  words=set(re.findall(r'[a-z]+',message.lower()))
  if mode=='director':
   chosen=next(((key,*value) for key,value in DIRECTOR.items() if key in words),None)
   if chosen:
    key,title,advice=chosen
    text=f"Sancho, {title.lower()}! {advice} The next cue is yours."
    return {'speaker':'Sir Purfluous','text':text,'mode':mode,'proposal':{'type':'director_note','topic':key,'note':advice,'executed':False},'sources':[]}
  if not matches:
   text=WELCOME if not self.history else NO_RESULT
   return {'speaker':'Sir Purfluous','text':text,'mode':mode,'proposal':None,'sources':[]}
  candidate=next((m for m in matches if m['id']!=self.last_id),matches[0])
  self.last_id=candidate['id']
  # Explicit grounded excerpt: no generative rewriting of user-provided source.
  excerpt=' '.join(candidate['text'].split())
  if len(excerpt)>380:excerpt=excerpt[:377].rsplit(' ',1)[0]+'…'
  prefix= "Ah, Sancho, I have the very reel! " if candidate['kind'] in ('tale','story') else "My dear Sancho, the archive says this: "
  text=prefix+excerpt
  self.history.append({'time':time.time(),'user':message,'item':candidate['id']})
  return {'speaker':'Sir Purfluous','text':text,'mode':mode,'proposal':None,'sources':[{'title':candidate['title'],'source':candidate['source'],'id':candidate['id']}]}
def main():
 p=argparse.ArgumentParser()
 p.add_argument('command',choices=['chat','search','director'])
 p.add_argument('message')
 p.add_argument('--db',default='purfluous.sqlite3')
 p.add_argument('--lore',default=str(Path(__file__).parent/'lore'/'starter_canon.json'))
 a=p.parse_args()
 bot=PurfluousBot(a.db)
 bot.ingest(a.lore)
 if a.command=='search': result=bot.search(a.message)
 else:result=bot.respond(a.message,mode='director' if a.command=='director' else 'chat')
 print(json.dumps(result,indent=2,ensure_ascii=False))
 bot.close()
if __name__=='__main__':main()
