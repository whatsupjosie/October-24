# Sir Purfluous — offline character bot

A working, standard-library-only character-and-director retrieval engine. No LLM required. No background conversation monitor. **Nudge owns conversational initiation.** Director commands produce *proposals*, never silently execute.

## Running

```bash
python sir_purfluous_bot.py search "Peter O'Toole"
python sir_purfluous_bot.py chat "What do you know about Pete?"
python sir_purfluous_bot.py director "camera"
```

The bot indexes its included starter canon into SQLite FTS5. It searches on demand and returns the source for each retrieved response. It can ingest arbitrary `.py`, `.json`, `.md`, or `.txt` lore using `PurfluousBot.ingest(path)`. Re-importing the same path updates records without duplicating them. It does not automatically access repositories: add the canonical source files to a local lore directory and ingest that directory to populate the richer library.

**Provenance:** `lore/starter_canon.json` is a curated *subset* based on inspected `whatsupjosie/The-Prime` / `Wednesday-` canon. Exact source file locations are in `lore/source_manifest.json`. It is not a full transcription of those sources, and passages may be shortened. Fictional tall tales are labeled in-world lore, not facts about actual movies.

**Limitations:** Retrieval and simple keyword director coaching are not equivalent to AI reasoning. Source loading and PubCast integration are not automatic. Director suggestions are never studio actuation. Waiting-room admission/security and room-initiation decisions stay with their existing owners.
