import unittest, tempfile
from pathlib import Path
from sir_purfluous_bot import PurfluousBot
class Tests(unittest.TestCase):
 def setUp(self):
  self.bot=PurfluousBot()
  self.bot.ingest(Path(__file__).parent/'lore'/'starter_canon.json')
 def tearDown(self):self.bot.close()
 def test_search(self):
  self.assertTrue(any('Taylor' in x['title'] for x in self.bot.search('Elizabeth Taylor scarf')))
 def test_retrieval(self):
  x=self.bot.respond('golden hour heart to heart')
  self.assertTrue(x['sources'])
  self.assertIn('Sancho',x['text'])
 def test_director_is_proposal(self):
  x=self.bot.respond('camera',mode='director')
  self.assertEqual(x['proposal']['executed'],False)
 def test_no_unasked_work(self):
  self.assertFalse(hasattr(self.bot,'monitoring_loop'))
 def test_ingest_idempotent(self):
  f=Path(__file__).parent/'lore'/'starter_canon.json'
  self.bot.ingest(f);n=self.bot.conn.execute('SELECT COUNT(*) FROM knowledge').fetchone()[0]
  self.bot.ingest(f);self.assertEqual(n,self.bot.conn.execute('SELECT COUNT(*) FROM knowledge').fetchone()[0])
if __name__=='__main__':unittest.main()
