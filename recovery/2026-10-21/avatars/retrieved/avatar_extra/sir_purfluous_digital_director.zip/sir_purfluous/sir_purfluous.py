"""Sir Purfluous: an on-demand PubCast digital performance director.

No background task, conversation subscription, emotional surveillance, or Nudge role.
The host supplies an AI decision maker and explicitly authorized studio tools.
"""
from __future__ import annotations

import inspect
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Mapping, Protocol

PERSONA = """Sir Purfluous is PubCast's gloriously flamboyant digital performance director.
His voice is witty, extravagant, theatrical, warmly demanding, and never cruel.
He loves dramatic entrances, meaningful silences, nuanced acting, and precise craft.
He gives actionable rehearsal notes, interprets scripts, suggests blocking and camera
coverage, and can ask the host to operate studio controls during an authorized
performance session. He is a participant, not a conversation-flow governor.
He does not monitor conversations, manufacture emotional arcs, interrupt users,
or decide when to initiate interactions: Nudge handles conversational opportunity.
He never claims a cue happened unless a tool confirms its execution.
"""

class AIPlanner(Protocol):
    async def __call__(self, persona: str, request: str,
                       context: Mapping[str, Any],
                       available_tools: tuple[str, ...]) -> "DirectorDecision": ...

@dataclass(frozen=True)
class ToolCall:
    name: str
    arguments: Mapping[str, Any] = field(default_factory=dict)

@dataclass(frozen=True)
class DirectorDecision:
    response: str
    calls: tuple[ToolCall, ...] = ()

@dataclass(frozen=True)
class ToolResult:
    name: str
    success: bool
    result: Any = None
    error: str | None = None

@dataclass(frozen=True)
class DirectionResult:
    response: str
    tool_results: tuple[ToolResult, ...]
    timestamp: float

ToolHandler = Callable[..., Any]

class SirPurfluous:
    """On-demand character with scoped studio controls, not a background service."""

    def __init__(self, planner: AIPlanner) -> None:
        self._planner = planner
        self._tools: dict[str, ToolHandler] = {}

    def register_tool(self, name: str, handler: ToolHandler) -> None:
        """Host-controlled registration of a concrete studio operation."""
        if not name or not name.isidentifier() or name.startswith("_"):
            raise ValueError("Tool name must be a public identifier")
        if not callable(handler):
            raise TypeError("Tool handler must be callable")
        if name in self._tools:
            raise ValueError(f"Tool already registered: {name}")
        self._tools[name] = handler

    async def direct(self, request: str, *, session_id: str,
                     context: Mapping[str, Any] | None = None,
                     allowed_tools: set[str] | frozenset[str] | None = None,
                     execute: bool = False) -> DirectionResult:
        """Provide performance direction; optionally execute scoped, permitted cues.

        A host must explicitly set execute=True and supply allowed_tools for cues.
        The planner is AI-backed; tool implementations are deterministic host services.
        """
        if not session_id.strip() or not request.strip():
            raise ValueError("A performance session and request are required")
        permissions = set(allowed_tools or ()) & self._tools.keys()
        advertised = tuple(sorted(permissions)) if execute else ()
        decision = await self._planner(PERSONA, request,
                                       {**dict(context or {}), "session_id": session_id},
                                       advertised)
        if not isinstance(decision, DirectorDecision):
            raise TypeError("Planner must return DirectorDecision")
        results: list[ToolResult] = []
        for call in decision.calls:
            if not isinstance(call, ToolCall):
                raise TypeError("Planner calls must be ToolCall instances")
            if not execute or call.name not in permissions:
                results.append(ToolResult(call.name, False, error="Cue not authorized"))
                continue
            try:
                value = self._tools[call.name](**dict(call.arguments))
                if inspect.isawaitable(value):
                    value = await value
                results.append(ToolResult(call.name, True, result=value))
            except Exception as exc:
                results.append(ToolResult(call.name, False, error=f"{type(exc).__name__}: {exc}"))
        return DirectionResult(decision.response, tuple(results), time.time())
