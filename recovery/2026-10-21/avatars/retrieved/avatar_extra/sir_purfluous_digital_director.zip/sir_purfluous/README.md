# Sir Purfluous — on-demand digital performance director

The former conversation-monitoring service is intentionally removed. There are **no** background loops, message listeners, emotion keyword classifiers, global scene states, unsolicited announcements, or conversational authority. **Nudge owns conversational initiation and relevance.**

`SirPurfluous` is a personality-driven performance director. PubCast's host must provide an `AIPlanner` (an async adapter returning `DirectorDecision`) and register concrete studio control tools, such as `camera`, `lighting`, `mark_take`, or `playback`. No vendor/model or PubCast production endpoints are assumed.

The user or host explicitly invokes `direct(request, session_id=..., ...)`. `execute=False` is the default. To execute cues, the host must pass both `execute=True` and a per-invocation `allowed_tools` allowlist. Each tool outcome is returned and should be shown/recorded by the host; proposed speech is not proof of completed operations.

**Not yet integrated:** This is a self-contained replacement module plus unit tests, not a claim of wiring into PubCast, Nudge, a model adapter, real-stage devices, permissions service, or Blackbox. Production integration should validate tool argument schemas, enforce actor/session permissions at the tool/service boundary, scope targets to authorized rooms, log audit events, and use appropriate timeouts for connected control surfaces.

Run tests from this directory: `python -m unittest -v test_sir_purfluous.py`.
