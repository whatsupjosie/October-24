import asyncio
import unittest
from sir_purfluous import SirPurfluous, DirectorDecision, ToolCall

class DirectorTests(unittest.TestCase):
    def test_permissions_and_no_autonomous_execution(self):
        triggered = []
        async def planner(persona, request, context, tools):
            return DirectorDecision("Again, with feeling!", (ToolCall("mark_take", {"take": 2}),))
        director = SirPurfluous(planner)
        director.register_tool("mark_take", lambda take: triggered.append(take) or "marked")
        preview = asyncio.run(director.direct("Review rehearsal", session_id="s", allowed_tools={"mark_take"}))
        self.assertFalse(preview.tool_results[0].success)
        self.assertEqual(triggered, [])
        authorized = asyncio.run(director.direct("Mark take", session_id="s", allowed_tools={"mark_take"}, execute=True))
        self.assertEqual(triggered, [2])
        self.assertTrue(authorized.tool_results[0].success)
        denied = asyncio.run(director.direct("Mark take", session_id="s", allowed_tools=set(), execute=True))
        self.assertFalse(denied.tool_results[0].success)
        self.assertEqual(triggered, [2])

    def test_async_tool_and_errors(self):
        async def planner(*args):
            return DirectorDecision("Cue camera one", (ToolCall("camera", {"number": 1}),))
        async def camera(number):
            return f"camera {number} ready"
        director = SirPurfluous(planner)
        director.register_tool("camera", camera)
        result = asyncio.run(director.direct("Cue", session_id="stage", execute=True, allowed_tools={"camera"}))
        self.assertEqual(result.tool_results[0].result, "camera 1 ready")

if __name__ == "__main__":
    unittest.main()
