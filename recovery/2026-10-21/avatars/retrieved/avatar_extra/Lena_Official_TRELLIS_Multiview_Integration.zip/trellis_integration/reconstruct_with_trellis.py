"""Lena multi-view reconstruction using Microsoft's actual TRELLIS inference pipeline.
No substitute silhouette meshing. Requires official TRELLIS installation and CUDA.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
DEFAULT_IMAGES = [ROOT/'prepared'/'front.png', ROOT/'prepared'/'left.png', ROOT/'prepared'/'back.png']


def preflight(paths, output, require_gpu=True):
    from PIL import Image
    details=[]
    for p in paths:
        p=Path(p)
        if not p.is_file():
            raise FileNotFoundError(f'Missing reference: {p}')
        with Image.open(p) as im:
            im.verify()
        with Image.open(p) as im:
            details.append({'file':str(p),'size':list(im.size),'mode':im.mode})
    import importlib.util
    available=importlib.util.find_spec('trellis') is not None
    try:
        import torch
        cuda=bool(torch.cuda.is_available())
        device=torch.cuda.get_device_name(0) if cuda else None
    except ImportError:
        cuda=False;device=None
    report={'images':details,'trellis_installed':available,'cuda_available':cuda,'cuda_device':device,'output':str(output)}
    if require_gpu and (not available or not cuda):
        raise RuntimeError('TRELLIS inference cannot run: '+json.dumps(report))
    return report


def reconstruct(images, output, model, seed, texture_size, simplify):
    from PIL import Image
    os.environ.setdefault('SPCONV_ALGO','native')
    from trellis.pipelines import TrellisImageTo3DPipeline
    from trellis.utils import postprocessing_utils
    import trimesh
    report=preflight(images,output)
    pipeline=TrellisImageTo3DPipeline.from_pretrained(model)
    pipeline.cuda()
    inputs=[Image.open(p).convert('RGBA') for p in images]
    result=pipeline.run_multi_image(inputs, seed=seed,
        sparse_structure_sampler_params={'steps':12,'cfg_strength':7.5},
        slat_sampler_params={'steps':12,'cfg_strength':3})
    if not result.get('mesh') or not result.get('gaussian'):
        raise RuntimeError('TRELLIS returned no mesh or Gaussian representation')
    glb=postprocessing_utils.to_glb(result['gaussian'][0],result['mesh'][0],
                                     simplify=simplify,texture_size=texture_size)
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    glb.export(str(output))
    scene=trimesh.load(str(output),force='scene')
    meshes=[g for g in scene.geometry.values() if isinstance(g,trimesh.Trimesh)]
    if not meshes or sum(len(m.faces) for m in meshes)==0:
        raise RuntimeError('Export produced no usable triangles')
    report.update({'result':'EXPORTED','meshes':len(meshes),'triangles':sum(len(m.faces) for m in meshes),
                   'vertices':sum(len(m.vertices) for m in meshes),'size_bytes':output.stat().st_size,
                   'rigged':False,'visual_likeness_verified':False})
    output.with_suffix('.report.json').write_text(json.dumps(report,indent=2))
    return report


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--images',nargs='+',type=Path,default=DEFAULT_IMAGES)
    p.add_argument('--output',type=Path,default=ROOT/'output'/'Lena_TRELLIS_Multiview.glb')
    p.add_argument('--model',default='microsoft/TRELLIS-image-large')
    p.add_argument('--seed',type=int,default=1)
    p.add_argument('--texture-size',type=int,default=2048)
    p.add_argument('--simplify',type=float,default=0.7)
    p.add_argument('--preflight',action='store_true')
    args=p.parse_args(argv)
    if args.preflight:
        print(json.dumps(preflight(args.images,args.output,require_gpu=False),indent=2));return 0
    print(json.dumps(reconstruct(args.images,args.output,args.model,args.seed,args.texture_size,args.simplify),indent=2));return 0

if __name__=='__main__':
    try:sys.exit(main())
    except Exception as exc:
        print(f'RECONSTRUCTION FAILED: {exc}',file=sys.stderr);sys.exit(1)
