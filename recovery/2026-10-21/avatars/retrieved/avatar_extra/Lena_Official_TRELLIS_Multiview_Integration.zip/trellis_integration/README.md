# Lena Hart — official TRELLIS multi-image reconstruction integration

This replaces the homegrown silhouette-based **generation** step with the real, published learned 3D reconstruction pipeline from [Microsoft TRELLIS](https://github.com/microsoft/TRELLIS) (MIT license). The integration uses its public `TrellisImageTo3DPipeline.run_multi_image` and `postprocessing_utils.to_glb` APIs, adapted from Microsoft's `example_multi_image.py` and `example.py`. It does **not** pretend to contain the large trained model weights or claim successful inference on a CPU-only environment.

## What's included

- Lena's original front, left-profile, and rear references in `inputs/`.
- GrabCut foreground segmentation and height normalization in `prepare_views.py`.
- Ready-to-run RGBA images in `prepared/`.
- Real TRELLIS multi-image inference and GLB export in `reconstruct_with_trellis.py`.
- Source/preparation/preflight tests.

## Running on a supported GPU computer

TRELLIS upstream states Linux, NVIDIA CUDA, and at least **16 GB VRAM**. Clone the upstream repository (with submodules), follow its `setup.sh` instructions and install its trained `microsoft/TRELLIS-image-large` weights. Inside the configured TRELLIS Python environment:

```bash
python prepare_views.py
python reconstruct_with_trellis.py --preflight
python reconstruct_with_trellis.py --output output/Lena_TRELLIS_Multiview.glb
```

Use this folder as the working directory or pass absolute `--images` paths. Inference downloads weights from Hugging Face if not already cached. For offline execution, set `--model /path/to/TRELLIS-image-large` with the complete downloaded model directory.

**Known source problem:** the three drawings are not the same pose. The front has a hand on the hip and the profile/rear differ. TRELLIS multi-image inference is experimental and cannot guarantee exact likeness, even with its trained model. Its output is a textured *static* 3D mesh; rigging to PubCast's canonical skeleton is a separate subsequent step.

## Executed here

- `python prepare_views.py` — RAN, generated three RGBA normalized views.
- `python -m unittest -v` — RAN, 3 tests passed.
- `python reconstruct_with_trellis.py --preflight` — RAN, detected no TRELLIS install and no CUDA GPU.
- Actual TRELLIS reconstruction — **NOT RUN**, no GPU/weights available in this environment.
- Likeness and GLB validation — **NOT RUN** because this integration has not generated a model.

The previous defective GLBs are deliberately excluded; this ZIP does not falsely include a new Lena GLB.

## License

The adapter code here is newly written against the published interfaces. The referenced upstream project is MIT licensed (Copyright Microsoft Corporation). Its bundled dependencies may have other licenses. See https://github.com/microsoft/TRELLIS/blob/main/LICENSE and upstream documentation.
