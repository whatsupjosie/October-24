"""Normalize supplied Lena artwork for multi-view learned reconstruction."""
from pathlib import Path
from PIL import Image, ImageChops, ImageFilter
import numpy as np
ROOT=Path(__file__).resolve().parent

def prepare(src,dst,canvas=(768,768)):
    image=Image.open(src).convert('RGB')
    import cv2
    a=np.asarray(image,dtype=np.uint8)
    h,w=a.shape[:2]
    # GrabCut uses foreground/background color models rather than treating paper texture as subject.
    # A narrow outer border is background; a center rectangle is initially probable foreground.
    bgr=cv2.cvtColor(a,cv2.COLOR_RGB2BGR)
    gc=np.zeros((h,w),np.uint8)
    gc[:,:]=cv2.GC_PR_BGD
    margin_x=max(2,int(w*.035));margin_y=max(2,int(h*.02))
    gc[margin_y:h-margin_y,margin_x:w-margin_x]=cv2.GC_PR_FGD
    gc[:margin_y,:]=cv2.GC_BGD;gc[-margin_y:,:]=cv2.GC_BGD
    gc[:,:margin_x]=cv2.GC_BGD;gc[:,-margin_x:]=cv2.GC_BGD
    bg=np.zeros((1,65),np.float64);fg=np.zeros((1,65),np.float64)
    cv2.grabCut(bgr,gc,None,bg,fg,6,cv2.GC_INIT_WITH_MASK)
    bw=np.isin(gc,[cv2.GC_FGD,cv2.GC_PR_FGD])
    from scipy.ndimage import binary_fill_holes,label
    labs,n=label(bw)
    if n:
        counts=np.bincount(labs.ravel());counts[0]=0
        bw=labs==counts.argmax()
    bw=binary_fill_holes(bw)
    mask=Image.fromarray((bw*255).astype('uint8'),'L').filter(ImageFilter.GaussianBlur(.55))
    bounds=mask.getbbox()
    if bounds is None:raise ValueError(f'No subject found: {src}')
    cut=image.crop(bounds);alpha=mask.crop(bounds)
    scale=min(canvas[0]*.85/cut.width,canvas[1]*.92/cut.height)
    wh=(max(1,round(cut.width*scale)),max(1,round(cut.height*scale)))
    cut=cut.resize(wh,Image.Resampling.LANCZOS)
    alpha=alpha.resize(wh,Image.Resampling.LANCZOS)
    out=Image.new('RGBA',canvas,(255,255,255,0))
    pos=((canvas[0]-wh[0])//2,(canvas[1]-wh[1])//2)
    out.paste(cut,pos,alpha)
    Path(dst).parent.mkdir(parents=True,exist_ok=True);out.save(dst)
    return {'source':str(src),'output':str(dst),'subject_bounds':bounds,'normalized_size':wh}

if __name__=='__main__':
    import json
    print(json.dumps([prepare(ROOT/'inputs'/f'{n}.png',ROOT/'prepared'/f'{n}.png') for n in ('front','left','back')],indent=2))
