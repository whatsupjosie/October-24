import unittest
from pathlib import Path
from PIL import Image
from reconstruct_with_trellis import preflight
from prepare_views import prepare,ROOT

class PipelineTests(unittest.TestCase):
    def test_sources_present(self):
        for n in ('front','left','back'):
            self.assertTrue((ROOT/'inputs'/f'{n}.png').is_file())
    def test_prepared_alpha_and_size(self):
        for n in ('front','left','back'):
            p=ROOT/'prepared'/f'{n}.png'
            self.assertTrue(p.is_file())
            with Image.open(p) as im:
                self.assertEqual(im.size,(768,768))
                self.assertEqual(im.mode,'RGBA')
                self.assertEqual(im.getpixel((0,0))[3],0)
                self.assertGreater(im.getchannel('A').getbbox()[2],100)
    def test_preflight_reports_actual_capabilities(self):
        r=preflight([ROOT/'prepared'/f'{n}.png' for n in ('front','left','back')],ROOT/'output'/'Lena.glb',False)
        self.assertEqual(len(r['images']),3)
        self.assertIsInstance(r['cuda_available'],bool)
        self.assertIsInstance(r['trellis_installed'],bool)

if __name__=='__main__':unittest.main()
