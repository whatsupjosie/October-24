import json,struct,unittest
from pathlib import Path
P=Path(__file__).parent
class OfflineViewerTest(unittest.TestCase):
 def test_dependency_free_viewer(self):
  html=(P/'offline_viewer.html').read_text();js=(P/'offline_viewer.js').read_text()
  self.assertIn('offline_viewer.js',html)
  self.assertNotIn('three.module.js',html)
  self.assertIn("getContext('webgl2'",js)
  self.assertIn('gl.drawElements',js)
 def test_rig_asset_present_and_structurally_valid(self):
  data=(P/'assets/pubcast_canonical_71_diagnostic.glb').read_bytes()
  self.assertEqual(data[:4],b'glTF')
  self.assertEqual(struct.unpack_from('<I',data,8)[0],len(data))
  n=struct.unpack_from('<I',data,12)[0]
  doc=json.loads(data[20:20+n]);self.assertEqual(len(doc['skins'][0]['joints']),71)
  self.assertGreater(len(doc['animations']),0)
  self.assertIn('WEIGHTS_0',doc['meshes'][0]['primitives'][0]['attributes'])
if __name__=='__main__':unittest.main()
