'use strict';
(async()=>{
const status=document.querySelector('#status'),canvas=document.querySelector('#canvas');
try{
const gl=canvas.getContext('webgl2',{antialias:true});if(!gl)throw Error('WebGL2 unavailable');
const response=await fetch('./assets/pubcast_canonical_71_diagnostic.glb');if(!response.ok)throw Error('GLB HTTP '+response.status);
const bytes=await response.arrayBuffer(),dv=new DataView(bytes);
if(dv.getUint32(0,true)!==0x46546c67)throw Error('Invalid GLB magic');
const jsonLength=dv.getUint32(12,true),json=JSON.parse(new TextDecoder().decode(new Uint8Array(bytes,20,jsonLength)));
const binHeader=20+jsonLength,binOffset=binHeader+8;
const binLength=dv.getUint32(binHeader,true);if(dv.getUint32(binHeader+4,true)!==0x004e4942)throw Error('Missing BIN chunk');
const bin=bytes.slice(binOffset,binOffset+binLength);
const types={5121:[Uint8Array,1],5123:[Uint16Array,2],5125:[Uint32Array,4],5126:[Float32Array,4]};
function access(i){const a=json.accessors[i],v=json.bufferViews[a.bufferView], [C,size]=types[a.componentType],count=a.count*({SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT4:16}[a.type]);const offset=(v.byteOffset||0)+(a.byteOffset||0);return new C(bin.slice(offset,offset+count*size));}
const prim=json.meshes[0].primitives[0],attrs=prim.attributes;
const vertex=`#version 300 es
precision highp float;layout(location=0)in vec3 p;layout(location=1)in vec3 normal;layout(location=2)in uvec4 joint;layout(location=3)in vec4 weight;
uniform mat4 vp;uniform mat4 bones[100];out vec3 vNormal;
void main(){mat4 skin=weight.x*bones[joint.x]+weight.y*bones[joint.y]+weight.z*bones[joint.z]+weight.w*bones[joint.w];vec4 pos=skin*vec4(p,1.);gl_Position=vp*pos;vNormal=mat3(skin)*normal;}`;
const fragment=`#version 300 es
precision highp float;in vec3 vNormal;out vec4 color;void main(){float light=.28+.72*max(dot(normalize(vNormal),normalize(vec3(.6,.9,1.))),0.);color=vec4(vec3(.32,.66,.94)*light,1.);}`;
function shader(type,source){const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;}
const prog=gl.createProgram();gl.attachShader(prog,shader(gl.VERTEX_SHADER,vertex));gl.attachShader(prog,shader(gl.FRAGMENT_SHADER,fragment));gl.linkProgram(prog);if(!gl.getProgramParameter(prog,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(prog));gl.useProgram(prog);
const vao=gl.createVertexArray();gl.bindVertexArray(vao);
function buffer(location,data,components,integer=false){const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,data,gl.STATIC_DRAW);gl.enableVertexAttribArray(location);const type=data instanceof Float32Array?gl.FLOAT:data instanceof Uint8Array?gl.UNSIGNED_BYTE:gl.UNSIGNED_SHORT;if(integer)gl.vertexAttribIPointer(location,components,type,0,0);else gl.vertexAttribPointer(location,components,type,false,0,0);}
buffer(0,access(attrs.POSITION),3);buffer(1,access(attrs.NORMAL),3);buffer(2,access(attrs.JOINTS_0),4,true);buffer(3,access(attrs.WEIGHTS_0),4);
const indices=access(prim.indices),ibo=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ibo);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,indices,gl.STATIC_DRAW);
const indexType=indices instanceof Uint32Array?gl.UNSIGNED_INT:gl.UNSIGNED_SHORT;
const skin=json.skins[0],nodes=json.nodes,inv=access(skin.inverseBindMatrices),bones=new Float32Array(skin.joints.length*16),world=nodes.map(()=>new Float32Array(16));
function mul(a,b){const out=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++){let v=0;for(let k=0;k<4;k++)v+=a[k*4+r]*b[c*4+k];out[c*4+r]=v;}return out;}
function trs(t,q,s){const [x,y,z,w]=q,[sx,sy,sz]=s;const m=new Float32Array(16);m[0]=(1-2*(y*y+z*z))*sx;m[1]=2*(x*y+z*w)*sx;m[2]=2*(x*z-y*w)*sx;m[4]=2*(x*y-z*w)*sy;m[5]=(1-2*(x*x+z*z))*sy;m[6]=2*(y*z+x*w)*sy;m[8]=2*(x*z+y*w)*sz;m[9]=2*(y*z-x*w)*sz;m[10]=(1-2*(x*x+y*y))*sz;m[12]=t[0];m[13]=t[1];m[14]=t[2];m[15]=1;return m;}
const parents=nodes.map(()=>-1);nodes.forEach((n,i)=>(n.children||[]).forEach(c=>parents[c]=i));
const animation=json.animations?.[0],channel=animation?.channels?.[0],sampler=channel?animation.samplers[channel.sampler]:null,times=sampler?access(sampler.input):null,values=sampler?access(sampler.output):null;
let playing=true,phase=0,last=performance.now(),yaw=.6,pitch=.2,zoom=6,drag=false,lastX=0,lastY=0;
document.querySelector('#toggle').onclick=()=>{playing=!playing;document.querySelector('#toggle').textContent=playing?'Pause':'Play';};
document.querySelector('#reset').onclick=()=>{yaw=.6;pitch=.2;zoom=6;};
canvas.onpointerdown=e=>{drag=true;lastX=e.clientX;lastY=e.clientY;canvas.setPointerCapture(e.pointerId);};canvas.onpointerup=()=>drag=false;canvas.onpointermove=e=>{if(!drag)return;yaw+=(e.clientX-lastX)*.008;pitch=Math.max(-1.3,Math.min(1.3,pitch+(e.clientY-lastY)*.008));lastX=e.clientX;lastY=e.clientY;};canvas.onwheel=e=>{e.preventDefault();zoom=Math.max(2,Math.min(20,zoom*Math.exp(e.deltaY*.001)));};
function perspective(aspect){const f=1/Math.tan(.55),near=.1,far=100,m=new Float32Array(16);m[0]=f/aspect;m[5]=f;m[10]=(far+near)/(near-far);m[11]=-1;m[14]=2*far*near/(near-far);return m;}
function lookAt(eye,target){const z=normalize(sub(eye,target)),x=normalize(cross([0,1,0],z)),y=cross(z,x);const m=new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,0,0,0,1]);m[12]=-dot(x,eye);m[13]=-dot(y,eye);m[14]=-dot(z,eye);return m;}
function sub(a,b){return a.map((v,i)=>v-b[i]);}function dot(a,b){return a.reduce((s,v,i)=>s+v*b[i],0);}function cross(a,b){return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];}function normalize(a){const n=Math.hypot(...a)||1;return a.map(v=>v/n);}
const boneLoc=gl.getUniformLocation(prog,'bones[0]'),vpLoc=gl.getUniformLocation(prog,'vp');
function frame(now){const dt=Math.min((now-last)/1000,.1);last=now;if(playing)phase+=dt;
const local=nodes.map((n,i)=>{let q=n.rotation||[0,0,0,1];if(channel&&channel.target.node===i&&times.length){const duration=times[times.length-1],t=duration?phase%duration:0;let k=0;while(k<times.length-2&&times[k+1]<t)k++;const alpha=times[k+1]===times[k]?0:(t-times[k])/(times[k+1]-times[k]);q=normalize(values.slice(k*4,k*4+4).map((v,j)=>v*(1-alpha)+values[(k+1)*4+j]*alpha));}return trs(n.translation||[0,0,0],q,n.scale||[1,1,1]);});
function calc(i){if(world[i][15])return world[i];world[i]=parents[i]<0?local[i]:mul(calc(parents[i]),local[i]);return world[i];}
world.forEach(m=>m.fill(0));skin.joints.forEach((id,i)=>bones.set(mul(calc(id),inv.slice(i*16,i*16+16)),i*16));
const w=canvas.clientWidth,h=canvas.clientHeight;if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}gl.viewport(0,0,w,h);gl.enable(gl.DEPTH_TEST);gl.clearColor(.045,.07,.12,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
const eye=[zoom*Math.sin(yaw)*Math.cos(pitch),1.2+zoom*Math.sin(pitch),zoom*Math.cos(yaw)*Math.cos(pitch)];gl.uniformMatrix4fv(vpLoc,false,mul(perspective(w/h),lookAt(eye,[0,1.2,0])));gl.uniformMatrix4fv(boneLoc,false,bones);gl.bindVertexArray(vao);gl.drawElements(gl.TRIANGLES,indices.length,indexType,0);
requestAnimationFrame(frame);}
status.textContent=`Loaded ${json.skins[0].joints.length} joints • ${access(attrs.POSITION).length/3} vertices • ${json.animations?.length||0} animation(s) • WebGL2`;document.body.dataset.ready='true';requestAnimationFrame(frame);
}catch(e){status.textContent='FAILED: '+e.message;document.body.dataset.ready='false';console.error(e);}
})();
