# Offline viewer implementation

Added `offline_viewer.html` and `offline_viewer.js`: a dependency-free WebGL2 GLB renderer with joint skinning, animation sampling, orbit and zoom controls. Uses the existing canonical 71-joint diagnostic GLB, **not Lena Hart**. Does not require Three.js or the npm registry.

**RAN:** `node --check offline_viewer.js`; `python -m unittest test_offline_viewer -v` (2 tests pass). These check syntax and file/asset integrity, **not visual correctness**.

**BLOCKED:** Tried automated Chromium rendering via Playwright at localhost and file://, but this execution environment returned `net::ERR_BLOCKED_BY_ADMINISTRATOR` for both. Thus actual rendering and interactions are **WROTE, NOT RUN**. No screenshot or visual verification claim is made.

**Outstanding:** Real Lena Hart 3D geometry, end-to-end application verification, full studio features, export and import tests, full PubCast integration. The standalone viewer is a test harness, not a finished studio.
