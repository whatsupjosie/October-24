import unittest,json,struct
from pathlib import Path
import numpy as np
from build_offline_glb import build
class OfflineGLB(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.path=build();cls.data=cls.path.read_bytes();cls.total,=struct.unpack_from('<I',cls.data,8)
  n,tag=struct.unpack_from('<I4s',cls.data,12);assert tag==b'JSON'
  cls.doc=json.loads(cls.data[20:20+n]);cls.binary=cls.data[28+n:]
 def array(self,index,dtype,shape):
  a=self.doc['accessors'][index];v=self.doc['bufferViews'][a['bufferView']];start=v['byteOffset']+28+struct.unpack_from('<I',self.data,12)[0]
  return np.frombuffer(self.data,dtype=dtype,count=int(np.prod(shape)),offset=start).reshape(shape)
 def test_glb_header_and_buffer(self):
  self.assertEqual(self.data[:4],b'glTF');self.assertEqual(self.total,len(self.data));self.assertEqual(self.doc['buffers'][0]['byteLength'],len(self.binary))
 def test_hierarchy_and_skin(self):
  d=self.doc;self.assertEqual(len(d['skins'][0]['joints']),71)
  self.assertEqual(len(d['nodes']),72);self.assertEqual(d['nodes'][0]['name'],'Root')
  self.assertEqual(d['skins'][0]['skeleton'],0)
 def test_vertex_weights_and_nonroot(self):
  attrs=self.doc['meshes'][0]['primitives'][0]['attributes'];count=self.doc['accessors'][attrs['POSITION']]['count']
  weights=self.array(attrs['WEIGHTS_0'],'<f4',(count,4));joints=self.array(attrs['JOINTS_0'],'<u2',(count,4))
  self.assertTrue(np.allclose(weights.sum(axis=1),1));self.assertTrue(np.any((joints[:,1]>0)&(weights[:,1]>.1)))
 def test_inverse_bind_matrices(self):
  i=self.doc['skins'][0]['inverseBindMatrices'];m=self.array(i,'<f4',(71,16)).reshape(71,4,4)
  self.assertTrue(np.isfinite(m).all());self.assertTrue(np.allclose(m[:,3,3],1))
 def test_animation_channel(self):
  a=self.doc['animations'][0];self.assertEqual(a['channels'][0]['target']['path'],'rotation')
  self.assertEqual(self.doc['nodes'][a['channels'][0]['target']['node']]['name'],'UpperArm_L')
if __name__=='__main__':unittest.main()
