"""Actual HTTP integration tests, no external JS dependency required."""
import contextlib
import json
import threading
import unittest
from http.server import ThreadingHTTPServer
from urllib.request import urlopen
from pathlib import Path
from server import Handler

ROOT=Path(__file__).resolve().parent

class HttpIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
        cls.base=f'http://127.0.0.1:{cls.server.server_port}/'
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join(timeout=3)
    def fetch(self,path):
        with urlopen(self.base+path,timeout=3) as r:
            return r.status,r.headers,r.read()
    def test_http_serves_studio_and_rig(self):
        status,headers,body=self.fetch('index.html')
        self.assertEqual(status,200)
        self.assertIn(b'studio.js',body)
        status,headers,body=self.fetch('canonical_rig.json')
        self.assertEqual(status,200)
        self.assertEqual(len(json.loads(body)['joints']),71)
    def test_http_serves_all_source_models(self):
        for name in ('manny.glb','sheila.glb','pete_avatar_pubcast_v56.glb'):
            with self.subTest(name=name):
                status,headers,body=self.fetch('assets/'+name)
                self.assertEqual(status,200)
                self.assertEqual(body[:4],b'glTF')
    def test_no_cache_header(self):
        _,headers,_=self.fetch('studio.js')
        self.assertEqual(headers.get('Cache-Control'),'no-store')

if __name__=='__main__':unittest.main()
