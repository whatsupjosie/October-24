# PubCast Avatar Studio — Gate 1, source-grounded recovery

RAN: `python -m unittest test_gate1 -v` — 4 tests, OK.

RAN: Extracted 71 joints from the `create_pubcast_rig()` constructor in the October 14 Rust source, including one root, the Blade Arrays, tail chain and sockets. The extractor deliberately targets this specific source structure and must be updated when the Rust constructor changes. This is a Python expansion of the Rust construction logic, not a compiled Rust execution.

RAN: Existing `manny.glb` and `sheila.glb` each contain one skin with 89 joints and no animation clips. Each skin has 65 joint names overlapping the extracted Rust rig, six Rust names absent, and 24 extra skin joint names. Therefore the existing models are **not** automatically compatible with the Rust rig. The GLB audit checks container integrity and structural indices, not skin deformation quality.

WROTE, NOT RUN: No new 3D rigging UI, browser skinning, image-to-3D conversion, or Blender worker is delivered in this Gate 1 package. These stages require implementation and independent verification.

Original files remain unchanged. The package includes read-only copies of only the relevant sources and existing model fixtures.

To rerun on Windows PowerShell 5.1:

    python .\extract_canonical.py
    python -m unittest test_gate1 -v
    python .\audit_existing_glb.py .\source\october\assets\avatar\manny.glb .\source\october\assets\avatar\sheila.glb

Gate 2 will require choosing whether to retain the 89-joint assets and retarget them to the Rust rig or create new geometry and weights. Do not relabel the existing skins as canonical.
