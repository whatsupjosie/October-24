# Browser dependency blocker — measured 2026-10-15

- The HTTP server successfully served the HTML, canonical 71-joint JSON, JavaScript, and all three included GLB files (actual localhost integration test).
- The browser bundle is **not self-contained**: `vendor/three.module.js` and its add-ons are absent. Distribution test fails as designed.
- A real `npm view three@0.160.0 version --fetch-retries=0 --fetch-timeout=8000` attempt failed with `EAI_AGAIN` DNS resolution for registry.npmjs.org. This environment cannot presently download the dependency.
- Browser rendering, mesh deformation, and GLB round-trip are not verified and must not be represented as passing.
- `setup_vendor.ps1` is a download recipe for connected Windows hosts, not an offline installation. An offline distribution must vendor the actual libraries and pass `test_vendor_complete` before release.
- 12 of 13 Python tests pass, one fails on missing vendored dependency; `node --check studio.js` passes.
