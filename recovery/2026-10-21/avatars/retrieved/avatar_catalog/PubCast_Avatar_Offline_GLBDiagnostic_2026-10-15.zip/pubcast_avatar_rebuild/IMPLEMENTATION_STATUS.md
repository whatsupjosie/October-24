# PubCast Avatar Studio — continuation status

## RAN
- Source-grounded 71-joint hierarchy checks: 7 Python tests passed.
- JavaScript syntax validation (`node --check studio.js`) passed.
- Extracted three existing source GLBs from the October 14 archive without altering originals. Structural GLB inspection succeeded: Manny 89 skin joints, Sheila 89, Pete 56; none contains animation clips.
- Implemented model-fixture selection and source-GLB load pathway in studio interface.
- Fixed animation clock accumulation so pausing/starting a mixer doesn't accumulate large delta.
- Added rest-pose capture for edge-stretch measurement instead of incorrectly assuming mesh raw vertex coordinates are rest-deformed positions.

## WROTE, NOT RUN
- Source-GLB loading in actual browser, Three.js rendering, GLB export and round-trip, animated deformation metrics. Browser dependencies have not been vendored into this package; the included PowerShell script can retrieve pinned Three.js modules when internet is available. Browser execution remains unverified.

## UNKNOWN / NOT DONE
- Lena Hart likeness mesh, image-to-3D, rig retargeting, visual skin-quality measurements, Blender pipeline, fully offline turnkey execution.

The existing model fixtures are reference assets only, not Lena Hart and not equivalent to the canonical Rust rig. A failing canonical hierarchy check on these fixtures is expected and should not be relabeled as success.

## Offline diagnostic GLB — 2026-10-15

RAN: `build_offline_glb.py` produced `assets/pubcast_canonical_71_diagnostic.glb`, a standalone glTF 2.0 binary containing the 71-joint canonical hierarchy, inverse bind matrices, 5,589 vertices with two-joint skin weights, and a left-arm quaternion animation. `trimesh.load(...,force="scene")` successfully imported the resulting GLB (1 mesh, 5,589 vertices). Fifteen targeted Python tests passed. This is a technical deformation fixture, NOT a Lena Hart character or verified browser studio. Missing vendored Three.js dependencies still block the browser.
