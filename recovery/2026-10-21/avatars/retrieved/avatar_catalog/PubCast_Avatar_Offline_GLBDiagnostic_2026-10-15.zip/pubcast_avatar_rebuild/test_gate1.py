import unittest,json
from pathlib import Path
from extract_canonical import SOURCE,build
from audit_existing_glb import inspect
ROOT=Path(__file__).parent
class Gate1(unittest.TestCase):
 def test_single_root_and_topological(self):
  joints=build(SOURCE.read_text());seen=set();roots=[]
  for j in joints:
   self.assertNotIn(j['name'],seen)
   if j['parent'] is None:roots.append(j['name'])
   else:self.assertIn(j['parent'],seen)
   self.assertEqual(len(j['offset']),3)
   seen.add(j['name'])
  self.assertEqual(roots,['Root'])
 def test_extracted_file_matches(self):
  self.assertEqual(build(SOURCE.read_text()),json.loads((ROOT/'canonical_rig.json').read_text())['joints'])
 def test_specific_joint_hierarchy(self):
  m={j['name']:j for j in build(SOURCE.read_text())}
  self.assertEqual(m['Blade_Array_L']['parent'],'Hand_L')
  self.assertEqual(m['Tail_05']['parent'],'Tail_04')
  self.assertEqual(m['Socket_Hand_R']['parent'],'Hand_R')
 def test_existing_models_are_structurally_readable(self):
  for name in ['manny.glb','sheila.glb']:
   d=inspect(ROOT/'source/october/assets/avatar'/name)
   self.assertGreater(d['skinned_nodes'],0)
   self.assertGreater(len(d['joint_counts']),0)
if __name__=='__main__':unittest.main(verbosity=2)
