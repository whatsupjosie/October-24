"""Extract the explicitly enumerated Rust create_pubcast_rig construction (fail closed)."""
import json,re,sys
from pathlib import Path
SOURCE=Path(__file__).parent/'source/october/run2_rust/skeleton_v2_hardened.rs'
OUT=Path(__file__).parent/'canonical_rig.json'
def build(text):
    section=text.split('pub fn create_pubcast_rig() -> Self {',1)[1].split('s.assert_topological_order();',1)[0]
    joints=[]
    def add(name,parent,offset):
        if any(j['name']==name for j in joints):raise ValueError('duplicate '+name)
        if parent is not None and parent not in {j['name'] for j in joints}:raise ValueError('missing parent '+str(parent))
        if len(offset)!=3:raise ValueError('invalid offset '+name)
        joints.append({'name':name,'parent':parent,'offset':[float(v) for v in offset]})
    # Ensure source patterns still match the expected version; reject edits rather than guessing.
    base=re.findall(r's\.add_unchecked\("([A-Za-z_0-9]+)",\s*(None|Some\("[A-Za-z_0-9]+"\)),\s*\[([^\]]+)\]',section.split('for (side, xs)')[0])
    if len(base)!=8:raise ValueError('unexpected base joint declarations: '+str(len(base)))
    for name,p,off in base:
        parent=None if p=='None' else p[6:-2]
        add(name,parent,[float(x.strip()) for x in off.split(',')])
    # Side section has 28 joints per side, expanded from fixed Rust loop data.
    side_section=section.split('for (side, xs)',1)[1].split('// Tail chain',1)[0]
    assert 'Blade_Array{side}' in side_section and 'let digits =' in side_section
    for side,xs in [('_L',1),('_R',-1)]:
        for name,parent,off in [
          ('Clavicle','Spine_03',[xs*.05,.05,0]),('UpperArm','Clavicle',[xs*.15,0,0]),('UpperArm_Twist','UpperArm',[xs*.13,0,0]),
          ('LowerArm','UpperArm',[xs*.27,0,0]),('LowerArm_Twist','LowerArm',[xs*.12,0,0]),('Hand','LowerArm',[xs*.23,0,0]),
          ('Thumb_01','Hand',[xs*.02,0,.02]),('Thumb_02','Thumb_01',[xs*.03,0,.01]),('Thumb_03','Thumb_02',[xs*.025,0,0])]:
            add(name+side,parent if parent=='Spine_03' else parent+side,off)
        for digit,z,xo in [('Index',.015,[.06,.04,.03]),('Middle',.005,[.065,.045,.033]),('Ring',-.01,[.06,.04,.028]),('Pinky',-.022,[.055,.033,.022])]:
            for i in range(3):add(f'{digit}_0{i+1}{side}',f'{digit}_0{i}{side}' if i else 'Hand'+side,[xs*xo[i],0,z if i==0 else 0])
        for name,parent,off in [('Thigh','Pelvis',[xs*.09,-.01,0]),('Thigh_Twist','Thigh',[0,-.22,0]),('Calf','Thigh',[0,-.42,0]),('Foot','Calf',[0,-.38,0]),('Ball','Foot',[0,-.08,.06]),('Toe','Ball',[0,0,.05]),('Blade_Array','Hand',[xs*.06,0,-.005])]:
            add(name+side,parent if parent=='Pelvis' else parent+side,off)
    tail=[-.04,-.05,-.06,-.06,-.05]
    assert 'let tail_offsets: &[f32] = &[-0.04, -0.05, -0.06, -0.06, -0.05]' in section
    for i,dy in enumerate(tail):add(f'Tail_0{i+1}','Pelvis' if i==0 else f'Tail_0{i}',[0,dy,-.02*(i+1)])
    assert 's.add_unchecked("Socket_Hand_R", Some("Hand_R"), [0.0, 0.0, 0.0]' in section
    assert 's.add_unchecked("Socket_Hip_L",  Some("Pelvis"), [-0.12, 0.0, 0.0]' in section
    add('Socket_Hand_R','Hand_R',[0,0,0]);add('Socket_Hip_L','Pelvis',[-.12,0,0])
    return joints
if __name__=='__main__':
    joints=build(SOURCE.read_text());OUT.write_text(json.dumps({'source':str(SOURCE.relative_to(Path(__file__).parent)),'joints':joints},indent=2)+'\n');print('Extracted joints:',len(joints));print('Root:',joints[0]['name']);print('Output:',OUT)
