$ErrorActionPreference = "Stop"
$base = "https://unpkg.com/three@0.160.0"
$files = @(
 "build/three.module.js",
 "examples/jsm/controls/OrbitControls.js",
 "examples/jsm/loaders/GLTFLoader.js",
 "examples/jsm/exporters/GLTFExporter.js",
 "examples/jsm/utils/BufferGeometryUtils.js"
)
foreach ($file in $files) {
 $dest = Join-Path "vendor" ($file -replace "^build/","" -replace "^examples/jsm/","addons/")
 New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
 Invoke-WebRequest -UseBasicParsing -Uri "$base/$file" -OutFile $dest
 Write-Host "Downloaded $dest"
}
# r160 GLTFExporter imports BufferGeometryUtils; all listed files are vendored.
Write-Host "Vendoring complete. Run: python server.py"
