# Gate 2 incremental browser fixture

RAN: Canonical Rust-source JSON from Gate 1 is now wired into the browser fixture.
WROTE, NOT RUN: Three.js rendering, GLB export and browser deformation behavior.

The browser now reads `canonical_rig.json` rather than the invented 66-joint table. This is a procedural skeletal test fixture, not Lena Hart. Existing October source remains untouched.

Run `./setup_vendor.ps1` once with internet to vendor Three.js, then `python server.py` and open http://127.0.0.1:8000. The server itself can run offline once dependencies are vendored.

Known limitations: no image-to-3D pipeline, no Blender runtime in this environment, no measured edge-stretch/volume harness yet, and no browser execution evidence. Exported animation and skin still need browser checks. The negative control corrupts a weight and must fail the harness.
