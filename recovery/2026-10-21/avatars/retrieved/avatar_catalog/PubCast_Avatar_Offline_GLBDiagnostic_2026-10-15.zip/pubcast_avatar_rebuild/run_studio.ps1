$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$required = @('vendor/three.module.js','vendor/addons/controls/OrbitControls.js','vendor/addons/loaders/GLTFLoader.js','vendor/addons/exporters/GLTFExporter.js','vendor/addons/utils/BufferGeometryUtils.js')
$missing = @($required | Where-Object { -not (Test-Path $_) })
if ($missing.Count -gt 0) {
 Write-Host 'Missing local Three.js dependencies. The studio cannot run offline yet:' -ForegroundColor Yellow
 $missing | ForEach-Object { Write-Host "  $_" }
 Write-Host 'With an internet connection, run .\setup_vendor.ps1 once, then run this launcher again.'
 exit 1
}
$python = Get-Command py -ErrorAction SilentlyContinue
if ($python) { & py -3 server.py } else { & python server.py }
