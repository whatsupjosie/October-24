"""Check whether the shipped browser application can start offline."""
from pathlib import Path
import json, unittest
BASE=Path(__file__).resolve().parent
class Distribution(unittest.TestCase):
    def test_html_references_present(self):
        html=(BASE/'index.html').read_text()
        for item in ('studio.js','canonical_rig.json'):
            self.assertTrue((BASE/item).is_file())
        self.assertIn('vendor/three.module.js',html)
    def test_vendor_complete(self):
        for item in ('three.module.js','addons/controls/OrbitControls.js','addons/loaders/GLTFLoader.js','addons/exporters/GLTFExporter.js','addons/utils/BufferGeometryUtils.js'):
            self.assertTrue((BASE/'vendor'/item).is_file(),f'MISSING browser dependency: vendor/{item}')
    def test_rig_has_nontrivial_hierarchy(self):
        joints=json.loads((BASE/'canonical_rig.json').read_text())['joints']
        self.assertEqual(len(joints),71)
        self.assertEqual(len(set(j['name'] for j in joints)),len(joints))
if __name__=='__main__':unittest.main()
