"""Read-only structural audit of GLB v2 JSON and binary chunks."""
import json,struct,sys
from pathlib import Path

def inspect(path):
    data=Path(path).read_bytes()
    if len(data)<20:raise ValueError('GLB too short')
    magic,version,length=struct.unpack_from('<4sII',data)
    if magic!=b'glTF' or version!=2 or length!=len(data):raise ValueError('invalid GLB header')
    offset=12;doc=None;bin_length=0
    while offset<len(data):
        if offset+8>len(data):raise ValueError('truncated chunk header')
        size,typ=struct.unpack_from('<I4s',data,offset);offset+=8
        if offset+size>len(data):raise ValueError('truncated chunk')
        if typ==b'JSON':
            if doc is not None:raise ValueError('multiple JSON chunks')
            doc=json.loads(data[offset:offset+size])
        if typ==b'BIN\0':bin_length=size
        offset+=size
    if doc is None:raise ValueError('no JSON chunk')
    nodes=doc.get('nodes',[]);skins=doc.get('skins',[])
    for skin in skins:
        for i in skin.get('joints',[]):
            if not isinstance(i,int) or i<0 or i>=len(nodes):raise ValueError('bad skin joint index')
    skinned_nodes=[n for n in nodes if 'skin' in n and 'mesh' in n]
    return {'file':Path(path).name,'glb_bytes':len(data),'binary_bytes':bin_length,
      'meshes':len(doc.get('meshes',[])),'skins':len(skins),'skinned_nodes':len(skinned_nodes),
      'joint_counts':[len(s['joints']) for s in skins],
      'joint_names':[[nodes[i].get('name','') for i in s['joints']] for s in skins],
      'animation_names':[a.get('name','') for a in doc.get('animations',[])]}
if __name__=='__main__':
    for f in sys.argv[1:]:
        try:print(json.dumps(inspect(f),indent=2))
        except Exception as e:print(f'{f}: {type(e).__name__}: {e}',file=sys.stderr);sys.exit(1)
