"""Generate a self-contained glTF 2.0 skinned, animated diagnostic fixture.
No external 3D engine or network dependencies. NOT a Lena character model.
"""
import json,struct,math
from pathlib import Path
import numpy as np
ROOT=Path(__file__).parent

def build(path=None):
    joints=json.loads((ROOT/'canonical_rig.json').read_text())['joints']
    names=[j['name'] for j in joints];lookup={n:i for i,n in enumerate(names)}
    world=[]
    for j in joints:
        t=np.array(j['offset'],dtype=np.float64)
        world.append(t+(world[lookup[j['parent']]] if j['parent'] else 0))
    buf=bytearray(); views=[];accessors=[]
    def add(data,component,typ,count=None,target=None,minmax=False):
        a=np.asarray(data);raw=a.tobytes();start=len(buf);buf.extend(raw);buf.extend(b'\0'*((-len(buf))%4))
        view={'buffer':0,'byteOffset':start,'byteLength':len(raw)}
        if target:view['target']=target
        views.append(view);acc={'bufferView':len(views)-1,'componentType':component,'count':len(a) if count is None else count,'type':typ}
        if minmax:
            arr=a.reshape((len(a),-1));acc['min']=arr.min(axis=0).tolist();acc['max']=arr.max(axis=0).tolist()
        accessors.append(acc);return len(accessors)-1
    vertices=[];normals=[];skin_ids=[];weights=[];indices=[]
    for i,j in enumerate(joints):
        if j['parent'] is None:continue
        parent=lookup[j['parent']];a=world[parent];b=world[i];axis=b-a;length=np.linalg.norm(axis)
        if length<1e-5:continue
        axis/=length;ref=np.array([0.,0.,1.]) if abs(axis[2])<.9 else np.array([1.,0.,0.]);u=np.cross(axis,ref);u/=np.linalg.norm(u);v=np.cross(axis,u)
        radius=min(.055,max(.012,length*.12));start=len(vertices)
        for ring in range(9):
            f=ring/8
            for side in range(9):
                theta=side*math.tau/9;n=u*math.cos(theta)+v*math.sin(theta)
                vertices.append((a+f*(b-a)+radius*n).tolist());normals.append(n.tolist())
                skin_ids.append([parent,i,0,0]);weights.append([1-f,f,0,0])
        for ring in range(8):
            for side in range(9):
                p=start+ring*9+side;q=start+ring*9+(side+1)%9;r=p+9;s=q+9
                indices.extend([p,q,r,q,s,r])
    pos=add(np.asarray(vertices,dtype='<f4'),5126,'VEC3',target=34962,minmax=True)
    norm=add(np.asarray(normals,dtype='<f4'),5126,'VEC3',target=34962)
    jid=add(np.asarray(skin_ids,dtype='<u2'),5123,'VEC4',target=34962)
    w=add(np.asarray(weights,dtype='<f4'),5126,'VEC4',target=34962)
    ind=add(np.asarray(indices,dtype='<u4'),5125,'SCALAR',target=34963)
    inv=np.asarray([np.linalg.inv(np.array([[1,0,0,p[0]],[0,1,0,p[1]],[0,0,1,p[2]],[0,0,0,1]],dtype=float)).T.flatten() for p in world],dtype='<f4')
    ibm=add(inv,5126,'MAT4')
    times=add(np.asarray([0,0.5,1,1.5,2],dtype='<f4'),5126,'SCALAR',minmax=True)
    angle=[0,.5,.75,.5,0]
    quat=add(np.asarray([[0,0,math.sin(x/2),math.cos(x/2)] for x in angle],dtype='<f4'),5126,'VEC4')
    nodes=[]
    for j in joints:
        nodes.append({'name':j['name'],'translation':j['offset'],'children':[]})
    for i,j in enumerate(joints):
        if j['parent']:nodes[lookup[j['parent']]]['children'].append(i)
    for n in nodes:
        if not n['children']:del n['children']
    meshnode=len(nodes);nodes.append({'name':'CanonicalRig_TestMesh','mesh':0,'skin':0})
    animation={'name':'Diagnostic_Left_Arm','samplers':[{'input':times,'output':quat,'interpolation':'LINEAR'}], 'channels':[{'sampler':0,'target':{'node':lookup['UpperArm_L'],'path':'rotation'}}]}
    gltf={'asset':{'version':'2.0','generator':'PubCast offline diagnostic generator'},'scene':0,'scenes':[{'nodes':[0,meshnode]}], 'nodes':nodes,
          'buffers':[{'byteLength':len(buf)}],'bufferViews':views,'accessors':accessors,
          'meshes':[{'name':'Diagnostic_segment_tubes_NOT_Lena','primitives':[{'attributes':{'POSITION':pos,'NORMAL':norm,'JOINTS_0':jid,'WEIGHTS_0':w},'indices':ind,'mode':4,'material':0}]}],
          'materials':[{'name':'Diagnostic_Blue','pbrMetallicRoughness':{'baseColorFactor':[.45,.65,.9,1],'metallicFactor':0,'roughnessFactor':.7},'doubleSided':True}],
          'skins':[{'name':'PubCast_Rust_Canonical_71','joints':list(range(len(joints))),'skeleton':0,'inverseBindMatrices':ibm}], 'animations':[animation]}
    js=json.dumps(gltf,separators=(',',':')).encode();js+=b' '*((-len(js))%4)
    payload=b'glTF'+struct.pack('<II',2,12+8+len(js)+8+len(buf))+struct.pack('<I4s',len(js),b'JSON')+js+struct.pack('<I4s',len(buf),b'BIN\0')+buf
    out=Path(path) if path else ROOT/'assets'/'pubcast_canonical_71_diagnostic.glb';out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(payload)
    return out
if __name__=='__main__':print(build())
