import json, math, unittest
from pathlib import Path
D=json.loads(Path(__file__).with_name('canonical_rig.json').read_text())['joints']
class CanonicalMetrics(unittest.TestCase):
 def test_finite_offsets(self):
  for j in D:self.assertEqual(len(j['offset']),3);self.assertTrue(all(math.isfinite(x) for x in j['offset']))
 def test_unique_names_and_topology(self):
  names=set();roots=[]
  for j in D:
   self.assertNotIn(j['name'],names)
   if j['parent'] is None:roots.append(j['name'])
   else:self.assertIn(j['parent'],names)
   names.add(j['name'])
  self.assertEqual(len(roots),1)
 def test_source_specific_joints(self):
  names={j['name'] for j in D}
  for name in ('Blade_Array_L','Blade_Array_R','Tail_05','Socket_Hand_R'):
   self.assertIn(name,names)
if __name__=='__main__':unittest.main()
