from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import argparse

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(Path(__file__).resolve().parent), **kwargs)
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

if __name__ == "__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--port",type=int,default=8000)
    p.add_argument("--host",default="127.0.0.1")
    a=p.parse_args()
    with ThreadingHTTPServer((a.host,a.port),Handler) as s:
        print(f"Studio: http://{a.host}:{a.port}",flush=True)
        try: s.serve_forever()
        except KeyboardInterrupt: pass
