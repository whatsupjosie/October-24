"""Pure-Python structural tests; no Blender/browser needed."""
import json, unittest
from pathlib import Path
from rig_pipeline import validate_definition
DATA=json.loads(Path(__file__).with_name("rig.json").read_text())
class RigTests(unittest.TestCase):
    def test_definition(self):
        joints=validate_definition(DATA)
        self.assertEqual(len(joints),66)
        self.assertEqual(DATA["expectedCanonicalCount"],67)
        self.assertEqual(DATA["status"],"PROVISIONAL_NOT_CANONICAL")
    def test_right_pinky_parent(self):
        joints={j["name"]:j for j in DATA["joints"]}
        self.assertEqual(joints["Pinky_02_R"]["parent"],"Pinky_01_R")
    def test_mirrored_finger_counts(self):
        for side in "LR":
            for finger in ["Thumb","Index","Middle","Ring","Pinky"]:
                for i in range(1,4):
                    self.assertIn(f"{finger}_0{i}_{side}",{j["name"] for j in DATA["joints"]})
    def test_invalid_parent_rejected(self):
        bad={"joints":[{"name":"A","parent":"missing","offset":[0,0,0]}]}
        with self.assertRaises(ValueError):validate_definition(bad)
if __name__=="__main__":unittest.main()
