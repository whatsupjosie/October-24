"""PubCast provisional rigging worker. Requires Blender 4.x; no canonical certification."""
from pathlib import Path
import argparse, subprocess, json, sys

def validate_definition(data):
    joints=data["joints"]; names=set()
    for j in joints:
        if j["name"] in names: raise ValueError("Duplicate joint "+j["name"])
        if j["parent"] is not None and j["parent"] not in names:
            raise ValueError("Parent missing or out of order: "+j["name"])
        names.add(j["name"])
    return joints

def run(input_model,output_glb,blender="blender"):
    source=Path(input_model).resolve()
    dest=Path(output_glb).resolve()
    if not source.is_file():raise FileNotFoundError(source)
    if source.suffix.lower() not in (".obj",".glb",".gltf"):
        raise ValueError("Only OBJ, GLB, GLTF supported")
    dest.parent.mkdir(parents=True,exist_ok=True)
    cmd=[blender,"--background","--factory-startup","--python",str(Path(__file__).with_name("blender_worker.py")),
         "--",str(source),str(dest),str(Path(__file__).with_name("rig.json"))]
    subprocess.run(cmd,check=True,timeout=600)
    if not dest.is_file() or dest.stat().st_size<100:raise RuntimeError("No usable output GLB")
    return dest

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("input_model")
    parser.add_argument("output_glb")
    parser.add_argument("--blender",default="blender")
    a=parser.parse_args()
    validate_definition(json.loads(Path(__file__).with_name("rig.json").read_text()))
    print(run(a.input_model,a.output_glb,a.blender))
