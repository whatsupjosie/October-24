# PubCast Avatar Studio — corrected prototype

**Status: source-corrected prototype, not production-ready and not canonical-certified.**

The pasted joint definition contains **66 joints**, although it claimed 67.
This package preserves those 66 joints, corrects the right-pinky hierarchy,
and labels all outputs **PROVISIONAL**. The missing canonical joint must be
resolved against the actual PubCast rig specification before compatibility can be claimed.

## Windows setup
1. Install Python 3 and, for Blender processing, Blender 4.x.
2. Open PowerShell in this folder and run `./setup_vendor.ps1`.
3. Run `python tests.py`.
4. Run `python server.py`.
5. Visit `http://127.0.0.1:8000`.

## Blender batch processing
`python rig_pipeline.py input.glb output.glb --blender blender`

Blender must be installed and discoverable in PATH, or supply the executable
path via `--blender`. Supports OBJ, GLB, GLTF meshes. Automatic skinning is
not guaranteed on arbitrary geometry: failures stop the process.

## What was repaired
- Joint local offsets are applied and parents are constructed correctly.
- Procedural mesh uses bone-segment tubes with blended two-bone weights.
- Browser validation checks joint names, hierarchy, skin indices and weight sums.
- Negative control intentionally corrupts a weight.
- Export reloads the generated GLB and checks skin, hierarchy, and clip names.
- External GLB import checks structure against the **provisional** definition.
- Blender imports all meshes, builds an armature and rejects unweighted vertices.
- No invented 67th joint or false canonical certification.

## Known limits
- Procedural tubes are a **test fixture**, not a sculpted humanoid body.
- Tube geometry is not a seamless production-quality character mesh.
- Browser and Blender have **not** been end-to-end tested in this environment.
- Automatic weights do not ensure visually good deformation.
- Blender output is not automatically re-imported; inspect it with the studio.
- Rig orientation, missing 67th joint, morph targets, facial performance,
  retargeting, mocap, material fidelity and full PubCast integration remain open.
- The local server only serves files; it does not execute Blender jobs from UI.
