"""Executed inside Blender 4.x, via rig_pipeline.py."""
import bpy, sys, json
from pathlib import Path
from mathutils import Vector

args=sys.argv[sys.argv.index("--")+1:]
source,out,definition=map(Path,args)
joints=json.loads(definition.read_text())["joints"]
bpy.ops.wm.read_factory_settings(use_empty=True)
if source.suffix.lower()==".obj":bpy.ops.wm.obj_import(filepath=str(source))
else:bpy.ops.import_scene.gltf(filepath=str(source))
meshes=[o for o in bpy.context.scene.objects if o.type=="MESH"]
if not meshes:raise RuntimeError("No mesh objects found")
# Existing armature modifiers must not conflict with the new armature.
for obj in meshes:
    for mod in list(obj.modifiers):
        if mod.type=="ARMATURE":obj.modifiers.remove(mod)
    for group in list(obj.vertex_groups):obj.vertex_groups.remove(group)
arm=bpy.data.armatures.new("PubCast_Provisional_Armature")
arm_obj=bpy.data.objects.new("PubCast_Provisional_Armature",arm)
bpy.context.collection.objects.link(arm_obj)
bpy.ops.object.select_all(action="DESELECT")
bpy.context.view_layer.objects.active=arm_obj
arm_obj.select_set(True)
bpy.ops.object.mode_set(mode="EDIT")
positions={}
for j in joints:
    offset=Vector(j["offset"])
    positions[j["name"]]=offset+(positions[j["parent"]] if j["parent"] else Vector((0,0,0)))
for j in joints:
    bone=arm.edit_bones.new(j["name"])
    bone.head=positions[j["name"]]
    # Blender requires nonzero bone length. Point toward first child where possible.
    child=next((c for c in joints if c["parent"]==j["name"]),None)
    direction=(Vector(child["offset"]) if child else Vector((0,.04,0)))
    if direction.length<.001:direction=Vector((0,.04,0))
    bone.tail=bone.head+direction.normalized()*max(.025,min(direction.length,.14))
for j in joints:
    if j["parent"]:arm.edit_bones[j["name"]].parent=arm.edit_bones[j["parent"]]
bpy.ops.object.mode_set(mode="OBJECT")
bpy.ops.object.select_all(action="DESELECT")
# Automatic weighting is Blender-dependent and may fail on nonmanifold or disconnected geometry.
# Parent each mesh individually, preserving multiple meshes rather than silently dropping them.
for obj in meshes:
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True);arm_obj.select_set(True)
    bpy.context.view_layer.objects.active=arm_obj
    bpy.ops.object.parent_set(type="ARMATURE_AUTO")
    if not any(m.type=="ARMATURE" and m.object==arm_obj for m in obj.modifiers):
        raise RuntimeError("Armature modifier missing on "+obj.name)
    # Ensure every vertex has usable normalized deform weights.
    valid={b.name for b in arm_obj.data.bones}
    for vert in obj.data.vertices:
        contributions=[]
        for membership in vert.groups:
            group=obj.vertex_groups[membership.group]
            if group.name in valid and membership.weight>0:
                contributions.append((group,membership.weight))
        if not contributions:
            raise RuntimeError(f"Unweighted vertex {vert.index} in {obj.name}; automatic skinning failed")
        contributions.sort(key=lambda x:x[1],reverse=True)
        total=sum(w for _,w in contributions[:4])
        for group,w in contributions[4:]:group.remove([vert.index])
        for group,w in contributions[:4]:group.add([vert.index],w/total,"REPLACE")
bpy.ops.object.select_all(action="DESELECT")
arm_obj.select_set(True)
for obj in meshes:obj.select_set(True)
bpy.context.view_layer.objects.active=arm_obj
bpy.ops.export_scene.gltf(filepath=str(out),export_format="GLB",use_selection=True,
    export_skins=True,export_animations=False)
# Blender-side structural checks before claiming success.
if len(arm_obj.data.bones)!=len(joints):raise RuntimeError("Joint count mismatch")
for j in joints:
    bone=arm_obj.data.bones.get(j["name"])
    if bone is None or (bone.parent.name if bone.parent else None)!=j["parent"]:
        raise RuntimeError("Hierarchy mismatch "+j["name"])
if not out.exists() or out.stat().st_size<100:raise RuntimeError("GLB not produced")
print("PROVISIONAL BLENDER EXPORT COMPLETED; browser round-trip validation still required:",out)
