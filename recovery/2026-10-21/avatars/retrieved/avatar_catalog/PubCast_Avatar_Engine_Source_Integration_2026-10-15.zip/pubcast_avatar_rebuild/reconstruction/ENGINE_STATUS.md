# Actual execution status

The current source contains a TRELLIS adapter and a tested, MIT-derived GLB unit normalizer from Hasasasaki/photo-to-mesh. The latter passed two tests including a GLB round-trip. This **is not** an image-to-3D reconstruction engine and must not be presented as one.

The source repository's working reconstruction backends use GPU model weights (Hunyuan3D) or a dense point map from VGGT plus Open3D Poisson reconstruction. Copying their Python scripts does not copy their learned model weights or CUDA runtime. Neither reconstruction backend has executed in this environment. There is no valid newly reconstructed Lena to deliver.

Upstream source: https://github.com/Hasasasaki/photo-to-mesh (MIT). The code copied/adapted here is limited to src/mesh_units.py; upstream LICENSE included.
