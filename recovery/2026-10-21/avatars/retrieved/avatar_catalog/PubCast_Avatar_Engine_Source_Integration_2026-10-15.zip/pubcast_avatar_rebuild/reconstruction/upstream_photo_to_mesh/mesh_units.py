"""Adapted from Hasasasaki/photo-to-mesh src/mesh_units.py, MIT licensed."""
TO_MM = {'mm': 1.0, 'cm': 10.0, 'in': 25.4}
FROM_MM = {'mm': 1.0, 'cm': 0.1, 'in': 1.0 / 25.4, 'm': 0.001}
AXIS_INDEX = {'X': 0, 'Y': 1, 'Z': 2}

def size_to_mm(value: float, unit: str) -> float:
    return float(value) * TO_MM[unit]

def scale_factor(extents, real_mm: float, axis: str = 'tallest'):
    if not real_mm or real_mm <= 0:
        return None
    ref = float(max(extents)) if axis == 'tallest' else float(extents[AXIS_INDEX[axis]])
    if ref <= 0:
        return None
    return float(real_mm) / ref

def echo_units(mm: float) -> str:
    return f'{mm:.1f} mm = {mm / 10.0:.2f} cm = {mm / 1000.0:.3f} m'
