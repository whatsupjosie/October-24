import tempfile
import unittest
from pathlib import Path
import trimesh
from mesh_scale import normalize_glb

class ScaleTests(unittest.TestCase):
    def test_normalizes_glb_height(self):
        with tempfile.TemporaryDirectory() as tmp:
            a,b=Path(tmp)/'a.glb',Path(tmp)/'b.glb'
            trimesh.creation.box(extents=(2,4,1)).export(a)
            self.assertAlmostEqual(normalize_glb(a,b,1.72),1.72,places=3)
            self.assertTrue(b.exists())
    def test_degenerate_geometry_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            a,b=Path(tmp)/'a.glb',Path(tmp)/'b.glb'
            trimesh.creation.box(extents=(1,0,1)).export(a)
            with self.assertRaises(ValueError):normalize_glb(a,b)
if __name__=='__main__':unittest.main()
