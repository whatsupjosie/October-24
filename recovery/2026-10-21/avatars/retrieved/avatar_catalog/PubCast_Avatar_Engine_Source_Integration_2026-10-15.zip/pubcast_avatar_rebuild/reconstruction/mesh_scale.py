"""Normalize reconstructed GLB to real-world metres using licensed upstream scaling."""
from pathlib import Path
import trimesh
from upstream_photo_to_mesh.mesh_units import scale_factor

def normalize_glb(source, output, target_height_m=1.7):
    scene = trimesh.load(str(source), force='scene')
    if not scene.geometry:
        raise ValueError('No geometry in reconstruction')
    bounds = scene.bounds
    if bounds is None:
        raise ValueError('No bounds in reconstruction')
    # glTF uses Y up. Explicit Y reference, never arbitrary max dimension.
    extents = bounds[1] - bounds[0]
    factor = scale_factor(extents, target_height_m * 1000, axis='Y')
    if factor is None:
        raise ValueError('Degenerate Y extent')
    scene.apply_scale(factor / 1000)
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    scene.export(str(output))
    check = trimesh.load(str(output), force='scene')
    actual = float(check.bounds[1][1] - check.bounds[0][1])
    if abs(actual - target_height_m) > 0.01:
        raise RuntimeError(f'Round-trip scale mismatch: {actual}')
    return actual
