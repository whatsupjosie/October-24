# Avatar Creator reconstruction utilities
These files belong to the standalone Avatar Creator, not the PubCast runtime.
The MIT-licensed mesh scaling utility was adapted from Hasasasaki/photo-to-mesh (see LICENSE).
`mesh_scale.py` rescales an EXISTING GLB; it does not reconstruct a mesh from images.
The original image-to-3D reconstruction backend is not integrated or runnable here.
Test: `cd reconstruction && python -m unittest test_mesh_scale -v`.
