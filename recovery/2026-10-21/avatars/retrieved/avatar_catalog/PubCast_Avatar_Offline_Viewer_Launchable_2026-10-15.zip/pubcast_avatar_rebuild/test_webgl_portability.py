import unittest
from pathlib import Path

SRC = (Path(__file__).parent / 'offline_viewer.js').read_text()

class WebGLPortability(unittest.TestCase):
    def test_skin_matrices_are_texture_backed(self):
        self.assertIn('uniform highp sampler2D boneTex', SRC)
        self.assertIn('gl.RGBA32F,4,skin.joints.length', SRC)
        self.assertIn('texelFetch(boneTex', SRC)
        self.assertNotIn('uniform mat4 bones[100]', SRC)
    def test_camera_matrix_column_major(self):
        self.assertIn('x[0],x[1],x[2],0,y[0],y[1],y[2],0,z[0],z[1],z[2]', SRC)
    def test_error_visible(self):
        self.assertIn("status.textContent='FAILED: '+e.message", SRC)

if __name__ == '__main__': unittest.main()
