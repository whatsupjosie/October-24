import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {GLTFExporter} from 'three/addons/exporters/GLTFExporter.js';

const $=id=>document.getElementById(id);
const report=msg=>{$('log').textContent+=msg+'\n';};
const scene=new THREE.Scene();scene.background=new THREE.Color(0x0b1020);
const view=$('viewport'),camera=new THREE.PerspectiveCamera(42,1,.01,100);
camera.position.set(2,1.6,3.7);
const renderer=new THREE.WebGLRenderer({antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));view.append(renderer.domElement);
const controls=new OrbitControls(camera,renderer.domElement);controls.target.set(0,1,0);controls.enableDamping=true;
scene.add(new THREE.HemisphereLight(0xffffff,0x293650,2));
const light=new THREE.DirectionalLight(0xffffff,2);light.position.set(2,4,3);scene.add(light);
scene.add(new THREE.GridHelper(5,20));
let current=null,mesh=null,helper=null,mixer=null,clips=[],rig=null,wire=false;
const loader=new GLTFLoader();
const boneWorld=(bone)=>bone.getWorldPosition(new THREE.Vector3());
function clear(){
  if(mixer){mixer.stopAllAction();mixer.uncacheRoot(current);}
  if(current)scene.remove(current);
  if(helper)scene.remove(helper);
  current=mesh=helper=mixer=null;clips=[];
}
function getPositions(joints){
 const map=new Map();
 for(const j of joints){
   const parent=j.parent?map.get(j.parent):null;
   if(j.parent&&!parent)throw Error('Missing or out-of-order parent '+j.parent);
   map.set(j.name,new THREE.Vector3(...j.offset).add(parent||new THREE.Vector3()));
 }
 return map;
}
function makeGeometry(joints,positions){
 // One tube per actual skeletal segment. Each vertex gets distance-based
 // blending to its segment endpoints, with a 2-joint transition.
 const verts=[],inds=[],weights=[],faces=[];
 const index=new Map(joints.map((j,i)=>[j.name,i]));
 const radial=9,steps=8;
 for(const j of joints){
   if(!j.parent)continue;
   const a=positions.get(j.parent),b=positions.get(j.name);
   const delta=new THREE.Vector3().subVectors(b,a),len=delta.length();
   if(len<1e-6)continue;
   const axis=delta.clone().normalize();
   const basis=new THREE.Vector3(0,0,1);
   if(Math.abs(axis.dot(basis))>.95)basis.set(1,0,0);
   const u=new THREE.Vector3().crossVectors(axis,basis).normalize();
   const v=new THREE.Vector3().crossVectors(axis,u).normalize();
   const start=verts.length/3;
   const radius=Math.min(.055,Math.max(.012,len*.12));
   for(let t=0;t<=steps;t++){
     const f=t/steps,center=a.clone().lerp(b,f);
     for(let k=0;k<radial;k++){
       const theta=k*2*Math.PI/radial;
       const point=center.clone().addScaledVector(u,Math.cos(theta)*radius).addScaledVector(v,Math.sin(theta)*radius);
       verts.push(point.x,point.y,point.z);
       const dA=point.distanceTo(a),dB=point.distanceTo(b);
       const sum=dA+dB;const wA=sum>0?dB/sum:1;
       inds.push(index.get(j.parent),index.get(j.name),0,0);
       weights.push(wA,1-wA,0,0);
     }
   }
   for(let t=0;t<steps;t++)for(let k=0;k<radial;k++){
     const p=start+t*radial+k,q=start+t*radial+(k+1)%radial;
     const r=p+radial,s=q+radial;
     faces.push(p,q,r,q,s,r);
   }
 }
 const geo=new THREE.BufferGeometry();
 geo.setAttribute('position',new THREE.Float32BufferAttribute(verts,3));
 geo.setAttribute('skinIndex',new THREE.Uint16BufferAttribute(inds,4));
 geo.setAttribute('skinWeight',new THREE.Float32BufferAttribute(weights,4));
 geo.setIndex(faces);geo.computeVertexNormals();return geo;
}
function validate(target,expected,negative=false){
 const errors=[],joints=target.skeleton.bones,geo=target.geometry;
 const byName=new Map(joints.map(b=>[b.name,b]));
 if(joints.length!==expected.length)errors.push(`joint count ${joints.length}, expected ${expected.length}`);
 for(const j of expected){
   const b=byName.get(j.name);
   if(!b){errors.push('missing '+j.name);continue;}
   const actual=b.parent?.isBone?b.parent.name:null;
   if(actual!==j.parent)errors.push(`parent ${j.name}: ${actual} != ${j.parent}`);
 }
 const si=geo.getAttribute('skinIndex'),sw=geo.getAttribute('skinWeight');
 if(!si||!sw)errors.push('missing skin attributes');
 else{
   let nonRoot=0;
   for(let i=0;i<sw.count;i++){
     const ws=[sw.getX(i),sw.getY(i),sw.getZ(i),sw.getW(i)];
     const ids=[si.getX(i),si.getY(i),si.getZ(i),si.getW(i)];
     const sum=ws.reduce((a,b)=>a+b,0);
     if(Math.abs(sum-1)>1e-4)errors.push(`weight sum at vertex ${i}: ${sum}`);
     if(ws.some(w=>w<0||!Number.isFinite(w)))errors.push('invalid weight '+i);
     for(let k=0;k<4;k++)if(ws[k]>0&&ids[k]>=joints.length)errors.push('invalid index '+i);
     if(ids.some((id,k)=>id!==0&&ws[k]>.01))nonRoot++;
     if(errors.length>25)break;
   }
   if(!nonRoot)errors.push('all vertices attached to root');
 }
 if(negative)errors.push('intentional negative-control failure');
 return errors;
}
function makeDemo(negative=false){
 clear();$('log').textContent='';
 const joints=rig.joints,positions=getPositions(joints),bones=[],byName=new Map();
 for(const j of joints){const b=new THREE.Bone();b.name=j.name;byName.set(j.name,b);bones.push(b);}
 for(const j of joints){
   const b=byName.get(j.name);
   b.position.set(...j.offset);
   if(j.parent)byName.get(j.parent).add(b);
 }
 const geometry=makeGeometry(joints,positions);
 if(negative){geometry.attributes.skinWeight.setX(0,.35);}
 mesh=new THREE.SkinnedMesh(geometry,new THREE.MeshStandardMaterial({color:0x99b5eb,roughness:.65,side:THREE.DoubleSide}));
 mesh.name='PubCast_Procedural_Demo';
 mesh.add(byName.get(joints[0].name));
 mesh.updateMatrixWorld(true);
 mesh.bind(new THREE.Skeleton(bones));
 current=new THREE.Group();current.add(mesh);scene.add(current);
 helper=new THREE.SkeletonHelper(mesh);scene.add(helper);
 const clip=new THREE.AnimationClip('Demo_Left_Arm',2,[
   new THREE.QuaternionKeyframeTrack('UpperArm_L.quaternion',[0,.5,1,1.5,2],
    [0,0,0,1,0,0,.259,.966,0,0,.383,.924,0,0,.259,.966,0,0,0,1])
 ]);
 clips=[clip];mixer=new THREE.AnimationMixer(mesh);mixer.clipAction(clip).play();
 const errors=validate(mesh,joints,negative);
 report(`Skeleton: ${bones.length} joints (Rust-derived source count ${rig.joints.length})`);
 report(`Mesh: ${geometry.getAttribute('position').count} vertices`);
 report(`Procedural test fixture: segment tubes with 2-joint weights`);
 report(`Internal validation: ${errors.length?'FAIL':'PASS'}`);
 for(const e of errors.slice(0,25))report(' - '+e);
 report('Canonical PubCast compatibility: NOT VERIFIED (missing authoritative joint)');
}
function validateImported(gltf){
 let imported=null;gltf.scene.traverse(n=>{if(n.isSkinnedMesh&&!imported)imported=n;});
 if(!imported)throw Error('No SkinnedMesh in GLB');
 return {imported,errors:validate(imported,rig.joints)};
}
$('rebuild').onclick=()=>makeDemo();
$('negative').onclick=()=>makeDemo(true);
$('skeleton').onclick=()=>{if(helper)helper.visible=!helper.visible;};
$('wire').onclick=()=>{wire=!wire;if(mesh){const mats=Array.isArray(mesh.material)?mesh.material:[mesh.material];for(const m of mats)m.wireframe=wire;}};
$('import').onchange=async e=>{
 const file=e.target.files[0];if(!file)return;
 try{
  const buf=await file.arrayBuffer(),gltf=await loader.parseAsync(buf,'');
  const {imported,errors}=validateImported(gltf);
  clear();current=gltf.scene;mesh=imported;clips=gltf.animations||[];
  scene.add(current);helper=new THREE.SkeletonHelper(mesh);scene.add(helper);
  if(clips.length){mixer=new THREE.AnimationMixer(current);mixer.clipAction(clips[0]).play();}
  $('log').textContent='';
  report(`Imported ${file.name}: ${mesh.skeleton.bones.length} bones, ${clips.length} clips`);
  report(`Against Rust-derived definition: ${errors.length?'FAIL':'PASS'}`);
  errors.slice(0,25).forEach(e=>report(' - '+e));
  report('Rust hierarchy comparison completed; character likeness NOT established');
 }catch(err){report('Import failed: '+err.message);}
 e.target.value='';
};
$('export').onclick=async()=>{
 if(!mesh)return;
 try{
  const wasPlaying=Boolean(mixer);
  if(mixer)mixer.stopAllAction();
  mesh.skeleton.pose();current.updateMatrixWorld(true);
  const exporter=new GLTFExporter();
  const buf=await exporter.parseAsync(current,{binary:true,animations:clips,onlyVisible:false});
  const reloaded=await loader.parseAsync(buf,'');
  const {imported,errors}=validateImported(reloaded);
  const clipNames=clips.map(c=>c.name);
  const exportedNames=reloaded.animations.map(c=>c.name);
  if(clipNames.some(n=>!exportedNames.includes(n)))errors.push('animation clips missing after round-trip');
  if(errors.length)throw Error(errors.slice(0,8).join('; '));
  report(`GLB round-trip: PASS (${imported.skeleton.bones.length} joints, ${exportedNames.length} clips)`);
  report('This checks exported structural parity only; no Lena likeness or deformation-quality certification.');
  const url=URL.createObjectURL(new Blob([buf],{type:'model/gltf-binary'}));
  const a=document.createElement('a');a.href=url;a.download='pubcast_rust_skeleton_procedural_demo.glb';a.click();
  setTimeout(()=>URL.revokeObjectURL(url),3000);
  if(wasPlaying&&clips.length)mixer.clipAction(clips[0]).reset().play();
 }catch(err){report('GLB export / verification FAILED: '+err.message);}
};
function resize(){const w=view.clientWidth,h=view.clientHeight;if(!w||!h)return;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h);}
new ResizeObserver(resize).observe(view);resize();
const clock=new THREE.Clock();
function animate(){requestAnimationFrame(animate);if(mixer)mixer.update(clock.getDelta());controls.update();renderer.render(scene,camera);}
animate();
try{
 const response=await fetch('./canonical_rig.json',{cache:'no-store'});
 if(!response.ok)throw Error('rig.json HTTP '+response.status);
 rig=await response.json();makeDemo();
}catch(err){report('Initialization FAILED: '+err.message);}

// CPU geometry deformation diagnostics: measured in the current pose.
// This function is intentionally independent of the status log and returns data.
function measureEdgeStretch(target) {
  if (!target?.isSkinnedMesh) throw new Error('A SkinnedMesh is required');
  const geometry=target.geometry, positions=geometry.getAttribute('position');
  const index=geometry.getIndex();
  if (!positions || !index) throw new Error('Indexed geometry and positions are required');
  if (typeof target.getVertexPosition!=='function') throw new Error('Three.js getVertexPosition unavailable');
  const rest=[],posed=[];
  const v=new THREE.Vector3();
  for(let i=0;i<positions.count;i++) {
    rest.push(new THREE.Vector3().fromBufferAttribute(positions,i));
    target.getVertexPosition(i,v);posed.push(v.clone());
  }
  const edges=new Set(),ratios=[];
  for(let i=0;i<index.count;i+=3) {
    const a=index.getX(i),b=index.getX(i+1),c=index.getX(i+2);
    for(const [u,w] of [[a,b],[b,c],[c,a]]) {
      const key=Math.min(u,w)+':'+Math.max(u,w);
      if(edges.has(key))continue;edges.add(key);
      const baseline=rest[u].distanceTo(rest[w]);
      if(baseline<=1e-9)continue;
      ratios.push(posed[u].distanceTo(posed[w])/baseline);
    }
  }
  if(!ratios.length)throw new Error('No measurable edges');
  ratios.sort((a,b)=>a-b);
  return {edgeCount:ratios.length,maxStretch:ratios.at(-1),p99Stretch:ratios[Math.floor((ratios.length-1)*.99)]};
}
window.pubcastDiagnostics={measureEdgeStretch};
