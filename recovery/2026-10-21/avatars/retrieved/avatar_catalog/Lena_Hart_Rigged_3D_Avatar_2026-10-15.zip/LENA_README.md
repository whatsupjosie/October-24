# Lena Hart — 3D avatar

Start with `START_OFFLINE_VIEWER.bat` on Windows with Python 3 installed, or run `python server.py --port 8765` and open http://127.0.0.1:8765/offline_viewer.html . No Three.js required for this viewer.

`assets/lena_hart_stylized_rigged.glb` is a genuine glTF 2.0 binary with a 71-joint PubCast skeleton, a skinned multi-material mesh, and an idle animation. It is a **stylized geometry approximation** of Lena's references, not a faithful sculpt or production-quality image-to-3D reconstruction. Mesh pieces are rigid-weighted to individual bones (articulated rather than smooth joint bending). Face expressions and hair simulation are not present. Browser rendering has not been executed in a graphics-capable browser in this session.
