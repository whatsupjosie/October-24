@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
  start "" "http://127.0.0.1:8765/offline_viewer.html"
  py -3 server.py --port 8765
  goto :end
)
where python >nul 2>&1
if not errorlevel 1 (
  start "" "http://127.0.0.1:8765/offline_viewer.html"
  python server.py --port 8765
  goto :end
)
echo Python 3 is required to run the local server.
pause
:end
