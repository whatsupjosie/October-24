"""Lena Hart stylized 3D rig, from reference colors and canonical PubCast joint source.
Generated geometry is an authored approximation, not photogrammetric reconstruction.
"""
import json, math, struct
from pathlib import Path
import numpy as np
import trimesh
ROOT=Path(__file__).parent
J=json.loads((ROOT/'canonical_rig.json').read_text())['joints']; names=[x['name'] for x in J]; ids={n:i for i,n in enumerate(names)}
world=[]
for j in J: world.append(np.array(j['offset'],float)+(world[ids[j['parent']]] if j['parent'] else 0))
parts=[]
def add(mesh,color,bone,name):
    parts.append((mesh,np.array(color,dtype=float)/255,ids[bone],name))
def ell(center,radii,color,bone,name,sub=2):
    m=trimesh.creation.icosphere(subdivisions=sub,radius=1);m.apply_scale(radii);m.apply_translation(center);add(m,color,bone,name)
def cyl(a,b,r1,r2,color,bone,name,n=14):
    a=np.array(a,float);b=np.array(b,float);axis=b-a;axis/=np.linalg.norm(axis);u=np.cross(axis,[0,0,1]) if abs(axis[2])<.9 else np.cross(axis,[0,1,0]);u/=np.linalg.norm(u);v=np.cross(axis,u)
    verts=[]
    for c,r in [(a,r1),(b,r2)]:
        for i in range(n):verts.append(c+r*(u*math.cos(2*math.pi*i/n)+v*math.sin(2*math.pi*i/n)))
    faces=[]
    for i in range(n): k=(i+1)%n;faces.extend([[i,k,n+i],[k,n+k,n+i]])
    faces.extend([[0,k,i] for i,k in [(i,(i+1)%n) for i in range(1,n-1)]])
    faces.extend([[n,n+i,n+i+1] for i in range(1,n-1)])
    add(trimesh.Trimesh(vertices=verts,faces=faces,process=False),color,bone,name)
def box(center,scale,color,bone,name):
    m=trimesh.creation.box(extents=scale);m.apply_translation(center);add(m,color,bone,name)
SKIN=[232,171,134];HAIR=[223,81,117];HAIR_DARK=[157,42,76];BLACK=[28,29,28];JACKET=[35,35,33];JACKET_LIGHT=[58,56,51];JEAN=[49,89,108];JEAN_LIGHT=[69,109,128];BOOT=[24,23,22];GOLD=[189,145,76];WHITE=[245,238,219];IRIS=[39,122,118]
# Anatomical scale follows canonical 1.4m rig, head 0.19m high.
ell([0,1.155,0],[.185,.205,.09],BLACK,'Spine_02','Black fitted top',3)
ell([0,1.04,0],[.165,.105,.105],JEAN,'Pelvis','Jeans waist',2)
ell([0,1.22,-.025],[.22,.21,.125],JACKET,'Spine_03','Leather jacket torso',3)
# Shirt visible at front of open jacket (+Z is front).
ell([0,1.235,.106],[.105,.14,.021],BLACK,'Spine_03','Open jacket shirt',2)
for s,side in [(1,'L'),(-1,'R')]:
    x=s*.11
    cyl([x,1.04,0],[s*.12,.72,0],.086,.069,JEAN,'Thigh_'+side,'Jeans thigh '+side)
    cyl([s*.12,.72,0],[s*.12,.35,0],.064,.046,JEAN,'Calf_'+side,'Jeans calf '+side)
    cyl([s*.12,.35,0],[s*.12,.13,0],.062,.072,BOOT,'Foot_'+side,'Laced black boot '+side)
    ell([s*.12,.12,.066],[.083,.07,.13],BOOT,'Foot_'+side,'Boot toe '+side)
    box([s*.12,.265,.002],[.147,.055,.15],JACKET_LIGHT,'Foot_'+side,'Boot cuff '+side)
    box([s*.12,.08,.025],[.17,.03,.24],BLACK,'Foot_'+side,'Boot sole '+side)
    for y in np.linspace(.17,.31,6):
        box([s*.12,y,.072],[.08,.007,.008],GOLD,'Foot_'+side,'Boot lace eyelet '+side)
    shoulder=[s*.20,1.36,0];elbow=[s*.47,1.36,0];wrist=[s*.74,1.36,0]
    cyl(shoulder,elbow,.084,.064,JACKET,'UpperArm_'+side,'Leather upper sleeve '+side)
    cyl(elbow,wrist,.063,.045,JACKET,'LowerArm_'+side,'Leather lower sleeve '+side)
    box([s*.74,1.36,0],[.07,.12,.12],JACKET_LIGHT,'Hand_'+side,'Sleeve cuff '+side)
    ell([s*.81,1.36,0],[.085,.04,.05],SKIN,'Hand_'+side,'Hand '+side)
    for f in ['Index','Middle','Ring','Pinky']:
        n='{}_01_{}'.format(f,side)
        if n in ids:ell(world[ids[n]]+[0,.002,.004],[.035,.015,.015],SKIN,n,f+' finger '+side,1)
    # lapels are angular leather overlays
    cyl([s*.105,1.39,.095],[s*.145,1.19,.126],.036,.025,JACKET_LIGHT,'Spine_03','Jacket lapel '+side)
    for y in [1.19,1.29,1.36]:ell([s*.15,y,.135],[.009,.009,.008],GOLD,'Spine_03','Brass jacket stud',1)
# Belt
box([0,1.036,.104],[.31,.032,.025],BLACK,'Pelvis','Black belt')
box([0,1.036,.124],[.067,.044,.009],GOLD,'Pelvis','Belt buckle')
box([0,1.036,.131],[.043,.026,.01],BLACK,'Pelvis','Belt buckle inset')
# neck, head, facial features
c=world[ids['Head']]
cyl([0,1.43,0],[0,1.53,0],.052,.045,SKIN,'Neck_01','Neck')
ell(c+[0,.075,.005],[.112,.145,.095],SKIN,'Head','Face and cranium',3)
ell(c+[0,-.045,.028],[.08,.052,.074],SKIN,'Jaw','Chin and jaw',2)
# face forward +Z
for s in [-1,1]:
    ell(c+[s*.048,.102,.087],[.026,.014,.009],WHITE,'Head','Eye white',2)
    ell(c+[s*.048,.102,.097],[.012,.012,.006],IRIS,'Head','Green eye',2)
    ell(c+[s*.048,.102,.104],[.006,.008,.003],BLACK,'Head','Pupil',2)
    box(c+[s*.048,.139,.087],[.057,.008,.01],HAIR_DARK,'Head','Eyebrow')
    ell(c+[s*.102,.065,.015],[.017,.03,.02],SKIN,'Head','Ear',2)
ell(c+[0,.065,.099],[.018,.031,.019],SKIN,'Head','Nose',2)
ell(c+[0,.016,.096],[.035,.006,.007],[147,65,75],'Head','Lips',2)
# sculpted short pink bob: volume and discrete swooping locks
ell(c+[0,.18,-.018],[.127,.095,.118],HAIR,'Head','Pink bob crown',3)
for s in [-1,1]:
    ell(c+[s*.103,.076,-.017],[.045,.105,.096],HAIR,'Head','Pink bob side '+str(s),2)
    for k in range(4):
        x=s*(.035+k*.024)
        cyl(c+[x,.236,-.005],c+[x+s*.02,.17,.091],.024,.012,HAIR if k%2 else HAIR_DARK,'Head','Side swept pink fringe',10)
    for k in range(4):
        x=s*(.06+k*.018)
        cyl(c+[x,.11,-.085],c+[x+s*.02,-.025,-.055],.021,.009,HAIR,'Head','Pink bob rear strand',9)
# Material-per-part meshes, bound rigidly to canonical joint nodes; articulated at joints.
buf=bytearray();views=[];accessors=[]
def acc(arr,component,typ,target=None,minmax=False):
    a=np.ascontiguousarray(arr);offset=len(buf);raw=a.tobytes();buf.extend(raw);buf.extend(b'\0'*((-len(buf))%4));v={'buffer':0,'byteOffset':offset,'byteLength':len(raw)}
    if target:v['target']=target
    views.append(v);o={'bufferView':len(views)-1,'componentType':component,'count':len(a),'type':typ}
    if minmax:o.update(min=a.min(axis=0).tolist() if a.ndim>1 else [float(a.min())],max=a.max(axis=0).tolist() if a.ndim>1 else [float(a.max())])
    accessors.append(o);return len(accessors)-1
v=[];norm=[];jids=[];weights=[];tri=[];materials=[];material_map={};groups={}
for mesh,col,jid,label in parts:
    k=tuple(col.tolist());m=material_map.get(k)
    if m is None:
        m=len(materials);material_map[k]=m;materials.append({'name':'Lena color '+str(m),'pbrMetallicRoughness':{'baseColorFactor':list(k)+[1.0],'metallicFactor':0.05 if k!=tuple(GOLD) else .65,'roughnessFactor':.72},'doubleSided':True})
    start=len(v);v.extend(mesh.vertices.tolist());norm.extend(mesh.vertex_normals.tolist());jids.extend([[jid,0,0,0]]*len(mesh.vertices));weights.extend([[1,0,0,0]]*len(mesh.vertices));groups.setdefault(m,[]).extend((mesh.faces+start).flatten().tolist())
pos=acc(np.array(v,dtype='<f4'),5126,'VEC3',34962,True);no=acc(np.array(norm,dtype='<f4'),5126,'VEC3',34962);ji=acc(np.array(jids,dtype='<u2'),5123,'VEC4',34962);we=acc(np.array(weights,dtype='<f4'),5126,'VEC4',34962)
prims=[]
for mat,faces in groups.items():
    idx=acc(np.array(faces,dtype='<u4'),5125,'SCALAR',34963)
    prims.append({'attributes':{'POSITION':pos,'NORMAL':no,'JOINTS_0':ji,'WEIGHTS_0':we},'indices':idx,'material':mat})
inv=[]
for p in world:
    a=np.eye(4);a[:3,3]=-p;inv.append(a.T.flatten())
ibm=acc(np.array(inv,dtype='<f4'),5126,'MAT4')
nodes=[{'name':j['name'],'translation':j['offset'],'children':[]} for j in J]
for i,j in enumerate(J):
    if j['parent']:nodes[ids[j['parent']]]['children'].append(i)
for n in nodes:
    if not n['children']:n.pop('children')
nodes.append({'name':'Lena_Hart_Skinned','mesh':0,'skin':0})
times=acc(np.array([0,.5,1,1.5,2],dtype='<f4'),5126,'SCALAR',minmax=True)
channels=[];samplers=[]
for bone,axis,angles in [('UpperArm_L','z',[0,-.15,-.35,-.15,0]),('UpperArm_R','z',[0,.15,.35,.15,0]),('Head','y',[0,.13,0,-.13,0]),('Thigh_L','x',[0,.13,0,-.13,0]),('Thigh_R','x',[0,-.13,0,.13,0])]:
    q=[]
    for a in angles:
        half=a/2;q.append([math.sin(half) if axis=='x' else 0,math.sin(half) if axis=='y' else 0,math.sin(half) if axis=='z' else 0,math.cos(half)])
    qa=acc(np.array(q,dtype='<f4'),5126,'VEC4');samplers.append({'input':times,'output':qa,'interpolation':'LINEAR'});channels.append({'sampler':len(samplers)-1,'target':{'node':ids[bone],'path':'rotation'}})
gltf={'asset':{'version':'2.0','generator':'PubCast Lena Hart offline character authoring'},'scene':0,'scenes':[{'nodes':[0,len(nodes)-1]}],'nodes':nodes,'buffers':[{'byteLength':len(buf)}],'bufferViews':views,'accessors':accessors,'meshes':[{'name':'Lena Hart - stylized pink hair leather jacket jeans boots','primitives':prims}],'materials':materials,'skins':[{'name':'PubCast canonical Rust 71','joints':list(range(len(J))),'skeleton':0,'inverseBindMatrices':ibm}],'animations':[{'name':'Lena idle head and limbs','channels':channels,'samplers':samplers}]}
js=json.dumps(gltf,separators=(',',':')).encode();js+=b' '*((-len(js))%4)
blob=b'glTF'+struct.pack('<II',2,12+8+len(js)+8+len(buf))+struct.pack('<I4s',len(js),b'JSON')+js+struct.pack('<I4s',len(buf),b'BIN\0')+buf
out=ROOT/'assets'/'lena_hart_stylized_rigged.glb';out.write_bytes(blob)
print('Wrote',out,'vertices',len(v),'triangles',sum(len(x) for x in groups.values())//3,'bones',len(J),'animations',len(channels))
